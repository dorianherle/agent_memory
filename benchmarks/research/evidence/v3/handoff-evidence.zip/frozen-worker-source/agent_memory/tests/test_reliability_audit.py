"""Regressions for failures found in the private source review."""
import unittest
import numpy as np

from agent_memory.catalog import vector_bytes
from agent_memory.tests.helpers import MemoryTestCase


class EmbeddingValidationTests(unittest.TestCase):
    def test_nonfinite_embeddings_are_rejected(self):
        for vector in ([float('nan'), 1], [float('inf'), 1], [1, -float('inf')]):
            with self.subTest(vector=vector), self.assertRaises(ValueError):
                vector_bytes(vector)

    def test_embedding_must_be_one_dimensional(self):
        with self.assertRaises(ValueError):
            vector_bytes([[1, 2], [3, 4]])

    def test_large_valid_embedding_keeps_unit_norm(self):
        dimensions, raw = vector_bytes([1e30, -1e30])
        vector = np.frombuffer(raw, dtype=np.float32)
        self.assertEqual(dimensions, 2)
        self.assertTrue(np.isfinite(vector).all())
        self.assertAlmostEqual(float(np.linalg.norm(vector)), 1, places=6)


class EvidenceRecoveryAuditTests(MemoryTestCase):
    def test_fts_filter_does_not_lose_low_ranked_explicit_id(self):
        target = self.memory.save('needle ' + 'ordinary context ' * 100)
        for index in range(24):
            self.memory.save(f'needle needle needle {index}')
        self.assertEqual([item.id for item in self.memory.find('needle', ids=target, k=1)], [target])

    def test_other_branch_hits_do_not_hide_current_branch_evidence(self):
        target = self.memory.save('needle ' + 'ordinary context ' * 100)
        for index in range(24):
            self.memory.save(f'needle needle needle {index}')
        self.memory.branch(target, 'audit-side', summary='Leave the first branch.')
        self.assertEqual([item.id for item in self.memory.find('needle', k=1)], [target])

    def test_previously_missing_dependency_becomes_stale_when_created(self):
        target = self.memory.save('Calibration file is missing.\nNext: obtain calibration.',
                                  {'files': ['calibration.json'], 'handoff': True})
        (self.path / 'calibration.json').write_text('{"rate": 12}')
        self.assertIn(f'[{target[:8]}] [stale]', self.memory.render_packet('calibration'))
