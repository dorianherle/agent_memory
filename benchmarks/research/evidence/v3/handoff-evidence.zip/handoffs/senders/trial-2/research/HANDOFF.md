# Sensor calibration: stage 0 handoff

## Status and next action

The stage 0 implementation is complete. All six local tests passed. The basic interface check passed. No stage 0 work remains open. Read the next supplied task before you make a change. Preserve the stage 0 rules unless that task explicitly changes them. Rerun the local tests and the basic interface check after each change.

## API and input contract

`solution.py` exports `solve(payload: dict) -> dict`. Use only the Python standard library and NumPy. `solve` must not read files, print, use a network, or change the input. Return native JSON values and finite numbers.

The input has aligned arrays `x`, `y`, `sigma`, and `include`. It also has `covariance` and `policy`. The model is `y = offset + gain*x + error`. `sigma` contains the known standard deviation of each measurement of `y`. It is not a residual estimate. Stage 0 uses independent errors. `covariance` is null and reserved for a later change. The current solver does not use that field.

Use only rows for which `include` is true. All rows in the supplied stage 0 sample are included. All valid test inputs have at least three included rows, a full-rank design, positive sigma, and finite data. The policy has `min_gain`, `max_reduced_chi2`, and `z_one_sided`.

Return exactly this envelope:

```python
{"schema_version": 1, "result": {
    "offset": float, "gain": float, "gain_se": float,
    "gain_lower": float, "chi2": float, "dof": int,
    "reduced_chi2": float, "accepted": bool, "reason": str
}}
```

The result has exactly the nine fields above. Do not add a covariance field to the result. The null covariance field belongs to the input.

## Method and formulas

Fit an intercept and a gain by weighted least squares. For included rows, let:

```text
w_i = 1 / sigma_i^2
W = sum(w_i)
x_bar = sum(w_i*x_i) / W
y_bar = sum(w_i*y_i) / W
Sxx = sum(w_i*(x_i - x_bar)^2)
Sxy = sum(w_i*(x_i - x_bar)*(y_i - y_bar))
gain = Sxy / Sxx
offset = y_bar - gain*x_bar
gain_se = sqrt(1 / Sxx)
residual_i = y_i - offset - gain*x_i
chi2 = sum((residual_i / sigma_i)^2)
dof = number_of_included_rows - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided*gain_se
```

These centered sums are the implemented method. They give the weighted least-squares intercept and slope. With design columns `[1, x]`, the parameter covariance is `(A.T W A)^(-1)`. Its gain variance is `1 / Sxx`. For reference, its offset variance is `1 / W + x_bar^2 / Sxx`, and its offset-gain covariance is `-x_bar / Sxx`. Only the gain standard error is returned.

Use the supplied measurement uncertainty directly. Do not multiply parameter covariance or standard error by reduced chi-square. Use a one-sided lower gain limit. Do not replace the supplied `z_one_sided` with a two-sided quantile or a Student t quantile.

The gain gate passes when `gain_lower >= min_gain`. The fit gate passes when `reduced_chi2 <= max_reduced_chi2`. Equality passes at both gates. Accept only when both gates pass. Return `reason = "ok"` when both pass, `"gain"` when only the gain gate fails, `"fit"` when only the fit gate fails, and `"gain+fit"` when both fail.

## Completed work and checks

The implementation selects included rows, computes centered weighted sums, applies both policy gates, and converts all returned numerical scalars to native Python types. All state is local to one call.

Runtime:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python
```

Run these commands from this research directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both commands passed. `-B` prevents bytecode-file writes. The interface check is a basic API check. It does not prove scientific correctness.

`test_local.py` has six tests. They check an exact line and its known gain uncertainty; unequal measurement uncertainties against an independent matrix calculation; exclusion of an outlier; unchanged gain uncertainty when residual size changes; all four gate reasons with equality at each threshold; native JSON types and input preservation.

The supplied sample returned:

```text
offset = 0.9359999999999999
gain = 1.0370000000000001
gain_se = 0.03794733192202056
gain_lower = 0.9745821934549332
chi2 = 0.8131944444444449
dof = 3
reduced_chi2 = 0.271064814814815
accepted = true
reason = ok
```

## Rejected approaches and limits

These methods were excluded by the task rules: an unweighted fit, a fit without an intercept, use of excluded rows, uncertainty estimated from residuals, covariance scaled by reduced chi-square, a two-sided gain interval, and strict inequalities at the acceptance thresholds. They were not failed implementation attempts.

Correlated-error covariance is outside stage 0. No later-stage behavior was inferred or implemented. Invalid input validation is outside the supplied contract. The current arithmetic was checked on the sample and local tests. Extreme floating-point ranges were not tested.

Only `solution.py`, `test_local.py`, and this handoff note were created or changed. No parent task files, future steering, other trials, library implementation, graders, references, or other agents were inspected. No network or model calls were used.
