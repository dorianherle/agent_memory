"""Weighted sensor calibration with known independent measurement errors."""

import numpy as np


def solve(payload: dict) -> dict:
    include = np.asarray(payload["include"], dtype=bool)
    x = np.asarray(payload["x"], dtype=float)[include]
    y = np.asarray(payload["y"], dtype=float)[include]
    sigma = np.asarray(payload["sigma"], dtype=float)[include]
    weights = 1.0 / np.square(sigma)
    weight_sum = float(np.sum(weights))
    x_mean = float(np.dot(weights, x) / weight_sum)
    y_mean = float(np.dot(weights, y) / weight_sum)
    x_centered = x - x_mean
    sxx = float(np.dot(weights, np.square(x_centered)))
    gain = float(np.dot(weights * x_centered, y - y_mean) / sxx)
    offset = float(y_mean - gain * x_mean)
    gain_se = float(np.sqrt(1.0 / sxx))
    residual = y - (offset + gain * x)
    chi2 = float(np.dot(residual / sigma, residual / sigma))
    dof = int(x.size - 2)
    reduced_chi2 = float(chi2 / dof)
    policy = payload["policy"]
    gain_lower = float(gain - policy["z_one_sided"] * gain_se)
    gain_ok = gain_lower >= policy["min_gain"]
    fit_ok = reduced_chi2 <= policy["max_reduced_chi2"]
    reason = "ok" if gain_ok and fit_ok else (
        "gain+fit" if not gain_ok and not fit_ok else "gain" if not gain_ok else "fit"
    )
    return {"schema_version": 1, "result": {
        "offset": offset,
        "gain": gain,
        "gain_se": gain_se,
        "gain_lower": gain_lower,
        "chi2": chi2,
        "dof": dof,
        "reduced_chi2": reduced_chi2,
        "accepted": bool(gain_ok and fit_ok),
        "reason": reason,
    }}
