import copy
import json
import unittest

from solution import solve


def run(events, stock=10):
    return solve({"stock": stock, "policy": {"expire": False,
                 "reject_key_conflict": False, "allow_amend": False},
                  "events": [dict(event, time=i) for i, event in enumerate(events)]})["result"]


class LedgerTests(unittest.TestCase):
    def test_sample_cache_snapshot(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H1", "qty": 4, "ttl": 5},
            {"request_id": "b", "op": "buy", "qty": 3},
            {"request_id": "a", "op": "buy", "qty": 100},
            {"request_id": "c", "op": "release", "hold_id": "H1"},
        ])
        self.assertEqual([r["available"] for r in result["responses"]], [6, 3, 6, 7])
        self.assertEqual(result["responses"][0], result["responses"][2])
        self.assertEqual(result["purchased"], 3)
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [])

    def test_hold_ids_never_reused_and_duplicate_priority(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H", "qty": 10},
            {"request_id": "b", "op": "reserve", "hold_id": "H", "qty": 20},
            {"request_id": "c", "op": "release", "hold_id": "H"},
            {"request_id": "d", "op": "reserve", "hold_id": "H", "qty": 1},
            {"request_id": "e", "op": "release", "hold_id": "H"},
        ])
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "duplicate_hold", "ok", "duplicate_hold", "missing_hold"])
        self.assertEqual(result["available"], 10)

    def test_failed_reserve_does_not_use_hold_but_response_is_cached(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H", "qty": 11},
            {"request_id": "b", "op": "reserve", "hold_id": "H", "qty": 3},
            {"request_id": "a", "op": "release", "hold_id": "H"},
        ])
        self.assertEqual([r["code"] for r in result["responses"]], ["insufficient", "ok", "insufficient"])
        self.assertEqual(result["responses"][0], result["responses"][2])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 3, "expires_at": None}])

    def test_failed_buy_and_missing_release_cached(self):
        result = run([
            {"request_id": "a", "op": "buy", "qty": 11},
            {"request_id": "b", "op": "release", "hold_id": "H"},
            {"request_id": "c", "op": "reserve", "hold_id": "H", "qty": 2},
            {"request_id": "b", "op": "release", "hold_id": "H"},
            {"request_id": "a", "op": "buy", "qty": 1},
        ])
        self.assertEqual(result["available"], 8)
        self.assertEqual(result["purchased"], 0)
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["insufficient", "missing_hold", "ok", "missing_hold", "insufficient"])

    def test_ttl_ignored_sorted_holds_and_conservation(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "Z", "qty": 2, "ttl": 1},
            {"request_id": "b", "op": "reserve", "hold_id": "A", "qty": 3, "ttl": 1},
            {"request_id": "c", "op": "buy", "qty": 5},
        ])
        self.assertEqual(result["available"], 0)
        self.assertEqual([h["hold_id"] for h in result["holds"]], ["A", "Z"])
        self.assertTrue(all(h["expires_at"] is None for h in result["holds"]))
        self.assertEqual(10, result["available"] + result["purchased"] +
                         sum(h["qty"] for h in result["holds"]))

    def test_empty_and_native_json_input_unchanged(self):
        self.assertEqual(run([]), {"responses": [], "available": 10, "purchased": 0, "holds": []})
        payload = {"stock": 1, "policy": {}, "events": [
            {"request_id": "a", "time": 0, "op": "buy", "qty": 1}]}
        original = copy.deepcopy(payload)
        output = solve(payload)
        self.assertEqual(original, payload)
        json.dumps(output, allow_nan=False)
        self.assertEqual(set(output), {"schema_version", "result"})
        self.assertEqual(set(output["result"]), {"responses", "available", "purchased", "holds"})
        self.assertEqual(set(output["result"]["responses"][0]), {"request_id", "code", "available"})


if __name__ == "__main__":
    unittest.main()
