# Inventory ledger: stage 0 handoff

## Status and next action

The stage 0 implementation is complete. All six local tests passed. The basic interface check passed. No stage 0 work remains open. Read the next supplied task before you make a change. Preserve the stage 0 rules unless that task explicitly changes them. Rerun the local tests and the basic interface check after each change.

## API and input contract

`solution.py` exports `solve(payload: dict) -> dict`. Use only the Python standard library and NumPy. This implementation needs only the standard library. `solve` must not read files, print, use a network, or change the input. Return native JSON values and finite numbers.

The input has initial `stock`, a `policy` object, and an ordered `events` list. Each event has `request_id`, nondecreasing integer `time`, and `op`. Request IDs can repeat. All events are structurally valid. `qty` and `ttl` are positive integers when present. Unknown operations are outside scope.

In stage 0, `policy.expire`, `policy.reject_key_conflict`, and `policy.allow_amend` are false. `ttl` is ignored. Time does not cause expiry. The current implementation does not use the policy flags or event time.

Return exactly this envelope:

```python
{"schema_version": 1, "result": {
    "responses": [
        {"request_id": request_id, "code": code, "available": int}
    ],
    "available": int,
    "purchased": int,
    "holds": [
        {"hold_id": hold_id, "qty": int, "expires_at": None}
    ]
}}
```

The result has exactly `responses`, `available`, `purchased`, and `holds`. Each response and hold entry has exactly the three fields shown. Keep responses in input event order. Sort final holds by `hold_id`. `expires_at` is always null in stage 0. `purchased` is the total quantity from successful purchases.

## State and formulas

Each call starts with:

```text
available = initial stock
purchased = 0
active holds = empty mapping from hold_id to qty
used hold IDs = empty set
request cache = empty mapping from request_id to response
responses = empty list
```

The stock identity is:

```text
available = initial stock - purchased - sum(active hold quantities)
```

Process events in their supplied order. Do not reorder equal-time events.

First check the request cache. If the request ID is cached, append the cached response value and skip all operations. Do this even if the repeated event has a different operation, hold ID, quantity, time, or TTL. Do not update its cached `available` snapshot to the current stock. The cache stores every first response, including failed requests.

For a first request, apply these rules:

1. `reserve`: Check whether the hold ID was used by any successful reserve. If it was used, return `duplicate_hold` with no state change. This check comes before the stock check. Otherwise, if `qty > available`, return `insufficient` with no state change. Otherwise, add the active hold, mark its ID as used, subtract its quantity from available stock, and return `ok`.
2. `buy`: If `qty > available`, return `insufficient` with no state change. Otherwise, subtract its quantity from available stock, add that quantity to purchased stock, and return `ok`.
3. `release`: If the hold is active, remove it, restore its quantity to available stock, and return `ok`. Otherwise return `missing_hold` with no state change. Do not remove the ID from the used-ID set.

Hold IDs can never be reused after a successful reserve, including after release. A failed reserve does not consume its hold ID. A later request with a new request ID can reserve that hold ID successfully.

After each first request, create and cache a response with the request ID, code, and stock after that operation. Append its value to the response list. The implementation copies response dictionaries when it appends them. Repeated responses have exactly the same JSON content as the cached response.

## Completed work and checks

The implementation tracks stock, purchases, active holds, all successfully used hold IDs, and cached responses in separate local containers. It builds sorted hold records at the end. A defensive `ValueError` handles an unsupported operation; unsupported operations are outside the valid input contract.

Runtime:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python
```

Run these commands from this software directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both commands passed. `-B` prevents bytecode-file writes. The interface check is a basic API check. It does not prove ledger correctness.

`test_local.py` has six tests. They check changed-payload request replay and old stock snapshots; active and released hold-ID reuse with duplicate priority; a failed reserve that does not consume an ID but does cache its response; cached failed purchases and missing releases; ignored TTL, sorted holds, exact-stock purchases, and stock conservation; an empty event list, native JSON output, exact result keys, and input preservation.

For the supplied input, all response codes are `ok`. The ordered stock snapshots are `[6, 3, 6, 7]`. The final available stock is `7`, purchased stock is `3`, and the holds list is empty. The third response repeats request `a` and retains the first response's stock snapshot of `6`.

## Rejected approaches and limits

These methods were excluded by the task rules: reapplying repeated requests, comparing repeat payloads for conflicts, returning current stock on a repeat, caching only successful requests, using a hold ID after release, consuming a hold ID on failed reserve, applying TTL expiry, allowing amendments, and sorting the input events. They were not failed implementation attempts.

Expiry, key-conflict rejection, and amendments are outside stage 0. No later-stage behavior was inferred or implemented. Positive quantity and structural validity are input guarantees. Additional input validation is outside the supplied contract.

Only `solution.py`, `test_local.py`, and this handoff note were created or changed. No parent task files, future steering, other trials, library implementation, graders, references, or other agents were inspected. No network or model calls were used.
