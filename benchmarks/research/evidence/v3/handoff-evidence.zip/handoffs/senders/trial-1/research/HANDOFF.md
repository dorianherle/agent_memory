# Sensor fit: stage 0 handoff

## Status and files

Stage 0 is complete. `solution.py` exports `solve(payload: dict) -> dict`.
`test_solution.py` contains seven local unit tests. All tests passed.
The basic interface check passed for the supplied `input.json`.
No later task, reference implementation, or grader was inspected.

## API and input contract

Use only the Python standard library and NumPy. In `solve`, do not read files,
print, use a network, or change the input. Return native JSON values and finite
numbers. The output is `{"schema_version": 1, "result": {...}}`.
Later stages must preserve the behavior of earlier stages.

Input arrays are `x`, `y`, `sigma`, and `include`. Select only rows with
`include == true`. The supplied stage 0 input includes every row. Each valid
test input has at least three selected observations, a full-rank design,
positive `sigma`, and finite data. `sigma` is the known standard deviation of
each measured `y`. It is not a standard deviation estimated from residuals.
The input field `covariance` is null at stage 0. It is reserved for a later
change. Stage 0 uses independent errors.

The policy supplies `min_gain`, `max_reduced_chi2`, and `z_one_sided`.
Use those supplied values. Do not insert a fixed confidence coefficient.

The result contains exactly these nine fields:

- `offset`: float.
- `gain`: float.
- `gain_se`: float.
- `gain_lower`: float.
- `chi2`: float.
- `dof`: integer.
- `reduced_chi2`: float.
- `accepted`: Boolean.
- `reason`: `ok`, `gain`, `fit`, or `gain+fit`.

Do not add an output `covariance` field. The task reserves the input field.

## Scientific method and formulas

The measurement model is `y_i = offset + gain * x_i + error_i`.
Fit an intercept and a gain with weighted least squares.
For the selected rows, let `X_i = [1, x_i]` and `W_ii = 1 / sigma_i**2`.

```text
beta = [offset, gain]
beta_hat = inverse(X.T W X) X.T W y
Cov(beta_hat) = inverse(X.T W X)
gain_se = sqrt(Cov(beta_hat)[1, 1])
residual_i = y_i - offset - gain * x_i
chi2 = sum((residual_i / sigma_i)**2)
dof = n_selected - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided * gain_se
```

Do not multiply parameter covariance by reduced chi-square. The measurement
uncertainty is known. The gain lower limit is one-sided.

The implementation uses a centered and scaled QR calculation. This reduces
numerical conditioning problems and avoids a direct normal-matrix inverse.
Let `s = min(sigma)`, `a_i = s / sigma_i`, and `w_i = a_i**2`.
Calculate `c = sum(w_i * x_i) / sum(w_i)` and `h = max(abs(x_i - c))`.
The full-rank assumption makes `h` positive in ordinary floating-point use.
Define `D_i = [1, (x_i - c) / h]` and `A_i = a_i * D_i`.
Factor `A = Q R` with reduced QR. Solve `R theta = Q.T (a * y)`.

```text
gain = theta[1] / h
offset = theta[0] - gain * c
Cov(theta) = s**2 * inverse(R) inverse(R).T
gain_se = s * norm(row_1(inverse(R))) / h
J = [[1, -c / h], [0, 1 / h]]
Cov(beta) = J Cov(theta) J.T
```

The code computes residuals as `y - D @ theta`. This is the same fitted model,
with less cancellation than a reconstructed intercept for large `x` values.
The code obtains only the covariance quantity needed for `gain_se`.

## Acceptance rules

The gain test passes if `gain_lower >= min_gain`.
The fit test passes if `reduced_chi2 <= max_reduced_chi2`.
Equality passes. Both tests must pass for acceptance.
The code uses strict failure comparisons, without an added tolerance.

| Gain test | Fit test | accepted | reason |
|---|---|---|---|
| Pass | Pass | true | ok |
| Fail | Pass | false | gain |
| Pass | Fail | false | fit |
| Fail | Fail | false | gain+fit |

## Completed checks

Runtime: `/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python`.
Run these commands from this research directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

The seven unit tests check these items:

- An exact line and the analytic gain standard error `sqrt(1/2)`.
- Uncertainty scaling: fitted parameters stay fixed, standard error scales
  with sigma, and chi-square scales with inverse sigma squared.
- Changes in residual size do not rescale parameter covariance.
- Excluded rows do not affect the fit or degrees of freedom.
- All four reason values and equality at both limits.
- Forty deterministic random fits with unequal uncertainties, compared with
  independent scalar weighted-fit formulas.
- Exact output keys, native integer and Boolean types, JSON serialization,
  and input preservation.

The supplied input returned approximately:

```text
offset = 0.936
gain = 1.037
gain_se = 0.03794733192202055
gain_lower = 0.9745821934549335
chi2 = 0.8131944444444473
dof = 3
reduced_chi2 = 0.27106481481481576
accepted = true
reason = ok
```

The basic interface check does not establish scientific correctness.
The local analytic and random checks provide the scientific checks recorded
here. Extreme floating-point scales were not tested.

## Rejected methods

These are design decisions. They are not failed numerical experiments.

- Unweighted regression would ignore the supplied measurement uncertainty.
- A fit without an intercept would change the required model.
- Residual scaling of covariance would violate the known-uncertainty rule.
- A two-sided limit or a fixed coefficient would change the supplied policy.
- Accepting when only one test passes would violate the joint rule.
- Adding output fields would violate the exact result schema.

## Next action and open work

No stage 0 work remains. Keep these tests and the current API.
When a new task is provided, read that task and its input. Implement only its
specified changes. Preserve stage 0 behavior and rerun both checks.
Do not infer later covariance behavior from the reserved field alone.
