# Reservation ledger: stage 0 handoff

## Status and files

Stage 0 is complete. `solution.py` exports `solve(payload: dict) -> dict`.
`test_solution.py` contains eight local unit tests. All tests passed.
The basic interface check passed for the supplied `input.json`.
No later task, reference implementation, or grader was inspected.

## API and input contract

Use only the Python standard library and NumPy. This solution needs only the
standard library. In `solve`, do not read files, print, use a network, or change
the input. Return native JSON values and finite numbers.
The output is `{"schema_version": 1, "result": {...}}`.
Later stages must preserve the behavior of earlier stages.

Input contains initial `stock`, `policy`, and an ordered `events` list.
Each event has `request_id`, nondecreasing integer `time`, and `op`.
Request IDs can be unique or repeated. Events are structurally valid.
When present, `qty` and `ttl` are positive integers.
Unknown operations are outside the task scope.

The stage 0 policy flags are false:

- `expire`.
- `reject_key_conflict`.
- `allow_amend`.

Stage 0 ignores `ttl` and does not expire holds. Time does not change state.
The implementation does not add behavior for true policy flags.

The result contains exactly `responses`, `available`, `purchased`, and `holds`.
Each response contains exactly `request_id`, `code`, and `available`.
Responses stay in event order. The response's `available` value is the stock
snapshot for that request, which can differ from final available stock.
Each hold entry contains exactly `hold_id`, `qty`, and `expires_at`.
Sort the holds list by `hold_id`. Every stage 0 `expires_at` is null.
`purchased` is the total quantity of successful purchases.

## State and invariant

Each call starts with fresh local state:

- `available = stock`.
- `purchased = 0`.
- `holds`: map of active hold IDs to quantities.
- `used_hold_ids`: set of all successfully reserved hold IDs.
- `request_cache`: map of first request IDs to their responses.
- `responses`: list in event order.

```text
available = initial stock - purchased - sum(active hold quantities)
```

A released hold leaves `holds` but stays in `used_hold_ids`.
Only a successful reservation adds its ID to `used_hold_ids`.
Each failed operation leaves inventory state unchanged.
The cache and state are local to `solve`. No state persists between calls.

## Event processing rules

First check `request_cache`. If the request ID exists, append a copy of its
cached response and perform no operation. Return that exact response even
when the new event has a different operation, quantity, hold ID, time, or TTL.
Do not replace the cached stock snapshot with current stock.

For a first request, process the operation:

### reserve

Require an unused `hold_id` and enough available stock for positive `qty`.
Check the used ID first. This defines code priority if both conditions fail.

- If the ID was previously used, return `duplicate_hold`.
- Otherwise, if `qty > available`, return `insufficient`.
- Otherwise, store the hold, mark the ID as used, subtract its quantity from
  available stock, and return `ok`.

An unsuccessful reservation does not consume its hold ID.
A later first request can successfully reserve that ID.
A successful hold ID can never be used again, including after release.

### buy

- If `qty > available`, return `insufficient`.
- Otherwise, subtract the quantity from available stock, add it to purchased
  quantity, and return `ok`.

### release

- If the hold ID is not active, return `missing_hold`.
- Otherwise, remove the active hold, restore its quantity to available stock,
  and return `ok`.

After every first request, create and cache its response, including failures.
Append a separate dictionary copy to the response list. The code raises
`ValueError` for unknown operations; those inputs are outside the contract.

## Completed checks

Runtime: `/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python`.
Run these commands from this software directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

The eight unit tests check these items:

- The original event sequence, including the old cached stock snapshot.
- A repeated key with changed event content returns the first response.
- A failed reservation is cached but does not consume its hold ID.
- A released hold ID cannot be reused. Duplicate ID takes priority over
  insufficient stock. Release of an inactive hold returns `missing_hold`.
- Failed buys and releases are cached even after inventory state changes.
- TTL is ignored over large time intervals. Holds are sorted. The inventory
  conservation formula holds after purchases and reservations.
- An empty event list and a purchase equal to all available stock.
- Exact output and response keys, JSON serialization, and input preservation.

The supplied input returned:

```text
responses:
  a: code ok, available 6
  b: code ok, available 3
  a: code ok, available 6
  c: code ok, available 7
available = 7
purchased = 3
holds = []
```

The basic interface check does not establish ledger correctness.
The local state-transition and response checks provide the correctness checks
recorded here.

## Rejected methods

These are design decisions. They are not failed execution experiments.

- Caching only successful requests would cause failed requests to run again.
- Replaying duplicate requests would purchase or reserve twice.
- Replacing cached available stock with current stock would change a response.
- Rejecting changed request content would violate stage 0 cache behavior.
- Using only active holds to detect duplicate IDs would allow reuse after release.
- Marking an unsuccessful hold ID as used would block a valid later reservation.
- Applying TTL expiration would change stage 0 behavior.
- Returning unsorted holds or extra fields would violate the output contract.

## Next action and open work

No stage 0 work remains. Keep these tests and the current API.
When a new task is provided, read that task and its input. Implement only its
specified changes. Preserve stage 0 behavior and rerun both checks.
Do not infer rules for expiration, conflicts, or amendment from policy names.
