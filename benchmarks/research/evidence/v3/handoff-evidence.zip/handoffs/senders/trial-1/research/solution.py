"""Weighted linear fit with known independent measurement errors."""

import numpy as np


def solve(payload: dict) -> dict:
    included = np.asarray(payload["include"], dtype=bool)
    x = np.asarray(payload["x"], dtype=float)[included]
    y = np.asarray(payload["y"], dtype=float)[included]
    sigma = np.asarray(payload["sigma"], dtype=float)[included]

    # Center and scale x before QR to reduce numerical conditioning problems.
    # A common uncertainty scale does not change the fitted parameters.
    sigma_scale = float(np.min(sigma))
    row_scale = sigma_scale / sigma
    weights = row_scale * row_scale
    x_center = float(np.dot(weights, x) / np.sum(weights))
    dx = x - x_center
    x_scale = float(np.max(np.abs(dx)))
    design = np.column_stack((np.ones(x.size), dx / x_scale))
    q, r = np.linalg.qr(design * row_scale[:, None], mode="reduced")
    coefficients = np.linalg.solve(r, q.T @ (y * row_scale))
    gain = float(coefficients[1] / x_scale)
    offset = float(coefficients[0] - gain * x_center)

    # Known errors: do not rescale this covariance by residual chi-square.
    r_inverse = np.linalg.solve(r, np.eye(2))
    gain_se = float(sigma_scale * np.linalg.norm(r_inverse[1]) / x_scale)
    residuals = y - design @ coefficients
    normalized_residuals = residuals / sigma
    chi2 = float(np.dot(normalized_residuals, normalized_residuals))
    dof = int(x.size - 2)
    reduced_chi2 = float(chi2 / dof)

    policy = payload["policy"]
    gain_lower = float(gain - policy["z_one_sided"] * gain_se)
    gain_failed = gain_lower < policy["min_gain"]
    fit_failed = reduced_chi2 > policy["max_reduced_chi2"]
    reason = "gain+fit" if gain_failed and fit_failed else (
        "gain" if gain_failed else "fit" if fit_failed else "ok"
    )
    return {"schema_version": 1, "result": {
        "offset": offset,
        "gain": gain,
        "gain_se": gain_se,
        "gain_lower": gain_lower,
        "chi2": chi2,
        "dof": dof,
        "reduced_chi2": reduced_chi2,
        "accepted": bool(not gain_failed and not fit_failed),
        "reason": reason,
    }}
