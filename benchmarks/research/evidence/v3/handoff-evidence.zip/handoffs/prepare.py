import hashlib,json,os,shutil,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
APP=ROOT.parent.parent
PACK=APP/'handoff-author-pack'/'public'
LIB=APP/'agent-memory-v3'
sys.path.insert(0,str(LIB))
from agent_memory import Memory
for name in ('GEMINI_API_KEY','AGENT_MEMORY_PROVIDER'):os.environ.pop(name,None)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prepare(trial,condition,stage):
    out=ROOT/f'stage-{stage}'/f'{condition}-trial-{trial}'
    out.mkdir(parents=True,exist_ok=False)
    for name in ('API.md','check_interface.py','apply_change.py'):shutil.copy2(PACK/name,out/name)
    details={}
    for task in ('research','software'):
        src=ROOT/'senders'/f'trial-{trial}'/task if stage==1 else ROOT/f'stage-{stage-1}'/f'{condition}-trial-{trial}'/task
        dest=out/task;dest.mkdir()
        for p in src.glob('*.py'):shutil.copy2(p,dest/p.name)
        shutil.copy2(src/'input.json',dest/'input.json')
        change=json.loads((PACK/task/f'CHANGE{stage}.json').read_text());data=json.loads((dest/'input.json').read_text());data.update(change['set']);(dest/'input.json').write_text(json.dumps(data,indent=2)+'\n')
        shutil.copy2(PACK/task/f'STEERING{stage}.md',dest/'STEERING.md')
        shutil.copy2(PACK/task/f'CHANGE{stage}.json',dest/'CHANGE.json')
        notes=[]
        goal=(PACK/task/'TASK0.md').read_text()
        notes.append({'text':goal,'payload':{'user':True,'goal':True},'kind':'goal'})
        if stage==2:
            prev=json.loads((src/'store.json').read_text())
            notes=json.loads((src/'stored-texts.json').read_text())
        notes.append({'text':(src/'HANDOFF.md').read_text(),'payload':{'handoff':True},'kind':'handoff'})
        steering=(dest/'STEERING.md').read_text()
        notes.append({'text':steering,'payload':{'user':True},'kind':'steering'})
        store=dest/'notes';store.mkdir()
        ids=[]
        if condition=='memory':
            m=Memory(store)
            for note in notes:ids.append(m.save(note['text'],note['payload'],agent='sender'))
            packet=m.render_packet(max_chars=1200);m._catalog.close()
        else:
            conn=sqlite3.connect(store/'index.sqlite3');conn.execute('CREATE VIRTUAL TABLE notes USING fts5(id UNINDEXED,text,ordinal UNINDEXED)')
            for i,note in enumerate(notes):
                nid=f'n-{i}';ids.append(nid);(store/f'{nid}.md').write_text(note['text']);conn.execute('INSERT INTO notes VALUES (?,?,?)',(nid,note['text'],i))
            conn.commit();conn.close()
            packet=('Goal: '+goal.splitlines()[0]+'\nCurrent steering ['+ids[-1]+']:\n'+steering[:550]+'\nLatest handoff ['+ids[-2]+']:\n'+notes[-2]['text'])[:1200]
        (dest/'INITIAL_PACKET.md').write_text(packet)
        (dest/'stored-texts.json').write_text(json.dumps(notes,indent=2)+'\n')
        (dest/'store.json').write_text(json.dumps({'condition':condition,'library':str(LIB),'ids':ids},indent=2)+'\n')
        shutil.copy2(ROOT/'read_notes_template.py',dest/'read_notes.py')
        (dest/'TASK.md').write_text('Continue this working solution. Read ../API.md, STEERING.md, input.json, and INITIAL_PACKET.md. The input already includes CHANGE.json. Recover earlier rules from the assigned note store with `python read_notes.py --all`, `--query TEXT`, or `--id ID`. All prior rules remain in force. Update solution.py, local tests, and write a complete HANDOFF.md. Do not modify input, interface, store, helper, or task files. Do not read outside this receiver workspace except the supplied Python runtime. Do not inspect the helper source or library source. Do not use a network, other agents, hidden graders, reference code, or other conditions. You may run the helper. Test the numerical or state behavior, not only the interface. The time target is about five minutes; it is not a hard limit.\n')
        details[task]={'source_code_sha256':digest(src/'solution.py'),'stored_note_sha256':[hashlib.sha256(n['text'].encode()).hexdigest() for n in notes],'initial_packet_chars':len(packet),'initial_packet_sha256':digest(dest/'INITIAL_PACKET.md')}
    (out/'preparation.json').write_text(json.dumps(details,indent=2)+'\n')
    return out
if __name__=='__main__':print(prepare(int(sys.argv[1]),sys.argv[2],int(sys.argv[3])))
