"""Audit frozen grader, paired inputs, and immutable receiver files."""
import hashlib,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parent;APP=R.parent.parent
subprocess.run([sys.executable,str(APP/'handoff-author-pack'/'verify_freeze.py')],check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checked=0
for manifest in ('run-freeze.json','stage-2-freeze.json'):
 frozen=json.loads((R/manifest).read_text())['sha256']
 for name,expected in frozen.items():
  p=R/name
  if p.name in ('solution.py','HANDOFF.md') or p.name.startswith('test'):continue
  assert sha(p)==expected,name
  checked+=1
for trial in (1,2):
 a=json.loads((R/'stage-1'/f'memory-trial-{trial}'/'preparation.json').read_text());b=json.loads((R/'stage-1'/f'notebook-trial-{trial}'/'preparation.json').read_text())
 for task in ('research','software'):
  assert a[task]['source_code_sha256']==b[task]['source_code_sha256']
  assert a[task]['stored_note_sha256']==b[task]['stored_note_sha256']
trace=[]
for stage in (1,2):
 for condition in ('memory','notebook'):
  for trial in (1,2):
   for task in ('research','software'):
    p=R/f'stage-{stage}'/f'{condition}-trial-{trial}'/task/'reads.jsonl'
    rows=[json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
    trace.append({'stage':stage,'condition':condition,'trial':trial,'task':task,'helper_reads':len(rows),'helper_returned_chars':sum(x['returned_chars'] for x in rows),'limit':'Helper output only. Excludes source, packet, and other tool reads. Not native model tokens or cost.'})
result={'passed':True,'immutable_files_checked':checked,'paired_stage1_code_and_note_hashes_match':True,'stage2_is_sequential_arm_continuation':True,'no_hidden_grader_feedback_to_workers':True,'isolation':'Instruction-scoped. No OS read barrier is claimed.','traces':trace}
(R/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='traces'},indent=2))
