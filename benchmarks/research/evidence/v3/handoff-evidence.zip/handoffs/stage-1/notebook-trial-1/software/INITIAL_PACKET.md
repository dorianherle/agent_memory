Goal: # Inventory reservation ledger, stage 0
Current steering [n-2]:
Enable expiring holds when `policy.expire` is true. A successful reserve expires at event.time + event.ttl.
Before EVERY event, including a repeated request, expire holds for which expires_at <= event.time. Restore their stock, but keep their IDs marked used.
After this expiry step, a repeated request still returns its original cached response. Thus its stock snapshot can differ from current stock. Do not recompute cached responses. No expiry occurs beyond the final event time.
Apply CHANGE1.json. Preserve behavior when expire is false. Update 
Latest handoff [n-1]:
# Reservation ledger: stage 0 handoff

## Status and files

Stage 0 is complete. `solution.py` exports `solve(payload: dict) -> dict`.
`test_solution.py` contains eight local unit tests. All tests passed.
The basic interface check passed for the supplied `input.json`.
No later task, reference implementation, or grader was inspected.

## API and input contract

Use only the Python standard library and NumPy. This solution needs only the
standard library. In `solve`, do not read files, print, use a network, or change
the input. Return native JSON values