# Reservation ledger: stage 1 handoff

## Status
Stage 1 is complete. Expiring holds are supported when policy.expire is true.
Behavior with expire false is preserved. The input already contained the change.
All earlier rules were recovered with `read_notes.py --all` (notes n-0 to n-2).
Only the solution, local tests, and this handoff were changed.

## API and data
Export `solve(payload: dict) -> dict`. Use standard library and NumPy only.
This solution needs only the standard library. Do not read files, print,
use a network, or change the input in solve. Return native JSON values.
The output is `{"schema_version": 1, "result": {...}}`.
The result has exactly responses, available, purchased, and holds.
Each response has exactly request_id, code, and available.
Responses stay in event order. Each available value is that response's stock
snapshot. It can differ from current or final available stock.
Each hold has exactly hold_id, qty, and expires_at. Sort holds by hold_id.
expires_at is an integer if expiry is enabled, otherwise null.

The input has stock, policy, and an ordered events list. Each event has
request_id, nondecreasing integer time, and op. Events are structurally valid.
Quantities and TTL values are positive integers when present.
Unknown operations are outside scope. reject_key_conflict and allow_amend
have no specified enabled behavior at this stage. Do not infer new rules.
The implementation uses a false default for absent policy.expire.

## State and conservation
Each call starts with fresh local state. No state persists between calls.
Maintain available stock, purchased quantity, active holds, used hold IDs,
a request response cache, and ordered responses.
Active holds store qty and expires_at.

```text
available = initial stock - purchased - sum(active hold quantities)
```

Only a successful reserve marks a hold ID used. Release and expiry remove
the active hold but keep its ID used. A successful hold ID can never be reused.
Failed operations do not change inventory state, after any required expiry.

## Event order and expiry
Before EVERY event, first process expiry if policy.expire is true.
Remove each active hold with expires_at <= event.time and restore its quantity.
Keep its ID in the used ID set. Equality causes expiry.
Do this before the cache lookup, including for repeated requests.
Do not expire holds after the final event. A final repeated request can cause
expiry even though it performs no operation.
With expire false, ignore TTL and time. Holds have expires_at null.

After expiry, check the request cache. A repeated request returns an exact
copy of its first response, even if its operation, quantity, hold ID, time,
or TTL differs. Do not run its operation again. Do not recompute its stock
snapshot. Cache every first response, including failed requests.

## Operations for first requests
reserve: Check the used hold ID first. If used, return duplicate_hold.
Otherwise, if qty > available, return insufficient. Otherwise, subtract qty,
store the hold, mark its ID used, and return ok. If expiry is enabled, set
expires_at = event.time + event.ttl. Otherwise set it to null.
A failed reserve does not consume a hold ID.

buy: If qty > available, return insufficient. Otherwise subtract qty,
add qty to purchased, and return ok. Purchases are permanent.

release: If the hold is inactive, return missing_hold. Otherwise remove it,
restore its quantity, and return ok. Its ID stays used.

After the operation, cache the response and append a separate dictionary copy.
The code raises ValueError for unknown operations, which are outside scope.

## Implementation
Expiry uses a list of expired IDs from active holds, then removes those holds.
This avoids changing the map while iterating. Each event scans active holds
when expiry is enabled. No performance target was supplied.
The cache lookup stays after expiry and before operation dispatch.
The result copies hold fields into output dictionaries.

## Checks
Run from this directory with the supplied runtime:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All 12 tests passed. The interface check passed.
Eight prior tests cover the original sequence, changed repeated requests,
failed request caching, failed reserve ID reuse, released ID rejection,
error priority, ignored TTL with expiry false, sorted holds, conservation,
empty events, exact stock purchase, output fields, JSON, and unchanged input.
Four new tests cover expiry before repeated requests, cached failed responses,
expiry at equality, no expiry before the deadline, permanent used IDs,
release before expiry without a second stock restoration, multiple expiries,
events at the same time, no expiry after the final event, and conservation.

The supplied input returns these responses:

```text
a: ok, available 4
b: insufficient, available 4
a: ok, available 4  (cached)
b: insufficient, available 4  (cached)
c: ok, available 5
final available = 5
purchased = 5
holds = []
```

## Limits and next work
No requested work remains. Preserve all cache, used ID, expiry, and stock
rules when a later task arrives. The interface check alone does not prove
state correctness; the tests above provide the recorded state checks.
No network, helper source, library source, grader, or reference code was used.
