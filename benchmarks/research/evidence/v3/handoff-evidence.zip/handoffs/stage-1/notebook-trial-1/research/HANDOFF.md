# Sensor fit: stage 1 handoff

## Status
Stage 1 is complete. The solution supports independent and correlated errors.
The input already contained the change. Input files were not changed.
All earlier rules were recovered with `read_notes.py --all` (notes n-0 to n-2).
Only the solution, local tests, and this handoff were changed.

## API and data
Export `solve(payload: dict) -> dict`. Use standard library and NumPy only.
Do not read files, print, use a network, or change the input in solve.
Return native JSON values and finite numbers.
The output is `{"schema_version": 1, "result": {...}}`.
The result has exactly these fields: offset, gain, gain_se, gain_lower,
chi2, dof, reduced_chi2, accepted, reason. Numeric values are floats,
except dof, which is an integer. accepted is Boolean.
reason is ok, gain, fit, or gain+fit.

The input has x, y, sigma, include, covariance, and policy.
Use only included rows. Tests have at least three included rows,
a full-rank design, positive sigma, and finite data.
A supplied covariance matrix is symmetric positive definite. It is the full
covariance of y and overrides sigma. Select its principal submatrix for the
included rows. Do not select a submatrix of its inverse.
If covariance is null or absent, use independent errors with variance sigma**2.
Do not return an extra covariance field.

## Method
The model is y = offset + gain*x + error, with an intercept.
Let X have columns 1 and x. Let C be the selected covariance, or diag(sigma**2).

```text
beta = inverse(X.T @ inverse(C) @ X) @ X.T @ inverse(C) @ y
Cov(beta) = inverse(X.T @ inverse(C) @ X)
gain_se = sqrt(Cov(beta)[1, 1])
residual = y - X @ beta
chi2 = residual.T @ inverse(C) @ residual
dof = number of included rows - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided * gain_se
```

Parameter covariance uses known measurement errors. Never multiply it by
residual error or reduced chi-square.
The implementation centers and scales x, then uses QR on a whitened design.
For independent errors, s=min(sigma), row factors=s/sigma, and the center
is the weighted mean. This preserves the earlier calculation.
For correlated errors, s=sqrt(min(diag(C))) and L=Cholesky(C/s**2).
The center is mean(x). h=max(abs(x-center)). D=[1,(x-center)/h].
Solve L A=D and L b=y. Factor A=Q R and solve R theta=Q.T b.
Then gain=theta[1]/h and offset=theta[0]-gain*center.
For both paths, gain_se=s*norm(row 1 of inverse(R))/h.
For correlated errors, chi2=norm(solve(L,y-D theta)/s)**2.
These solves avoid a direct covariance inverse in the implementation.

## Gates
Use the supplied policy values. Do not use a fixed confidence coefficient.
Gain passes if gain_lower >= min_gain. Fit passes if reduced_chi2 <=
max_reduced_chi2. Equality passes. Both gates must pass for acceptance.
Use strict failure comparisons without an added tolerance.
Return ok for no failed gates, gain for gain failure, fit for fit failure,
and gain+fit for both failures.

## Checks
Run from this directory with the supplied runtime:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All 10 tests passed. The interface check passed.
Seven prior tests cover exact lines, uncertainty scaling, no residual scaling,
excluded rows, all gate reasons and equality, 40 scalar weighted-fit comparisons,
output fields, JSON types, and unchanged input.
Three new tests cover analytic compound covariance, sigma override,
30 random GLS fits with excluded rows against direct matrix formulas,
diagonal covariance parity, covariance scaling, and unchanged input.
The supplied input gives offset about 1.018, gain about 1.0,
gain_se about 0.02828427124746, gain_lower about 0.95347651385293,
chi2 about 1.91, dof 3, reduced_chi2 about 0.63666666666667,
accepted true, reason ok.

## Limits and next work
No requested work remains. Extreme floating-point scales were not tested.
The interface check alone does not prove scientific correctness; numerical
tests provide the checks above. Preserve both error paths and these rules
when a later task arrives. Do not infer new behavior from unused fields.
No network, helper source, library source, grader, or reference code was used.
