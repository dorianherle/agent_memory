Goal: # Linear sensor experiment, stage 0
Current steering [n-2]:
The laboratory now supplies correlated measurement errors. Update the same API.
If `covariance` is a matrix, use it as the full covariance of `y`. It overrides `sigma`. Use generalized least squares: minimize residual-transpose times covariance-inverse times residual.
Use `(X^T C^-1 X)^-1` for parameter covariance. Do not scale it by residual error.
The one-sided gain gate and fit gate remain as specified. The supplied covariance is symmetric positive definite.
Apply CHANGE1.json to input.json. Preserve independent-error support. Update HANDOFF
Latest handoff [n-1]:
# Sensor fit: stage 0 handoff

## Status and files

Stage 0 is complete. `solution.py` exports `solve(payload: dict) -> dict`.
`test_solution.py` contains seven local unit tests. All tests passed.
The basic interface check passed for the supplied `input.json`.
No later task, reference implementation, or grader was inspected.

## API and input contract

Use only the Python standard library and NumPy. In `solve`, do not read files,
print, use a network, or change the input. Return native JSON values and finite
numbers. The output is `{"schema_version": 1, "