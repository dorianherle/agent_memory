# Inventory ledger: stage 1 handoff

## Status

Stage 1 is complete. The software task was completed before the research task.
All 10 local tests passed. The basic interface check passed. No required work is open.
Read the next task before you make a change. Keep the rules below unless the next task changes them.

## API and input

`solution.py` exports `solve(payload: dict) -> dict`.
Use only the Python standard library and NumPy. This solver uses only the standard library.
The solver must not read files, print, use a network, or change its input.
Return native JSON values and finite numbers.

The input contains initial `stock`, a `policy` object, and an ordered `events` list.
Each event has `request_id`, nondecreasing integer `time`, and `op`.
Request IDs can repeat. Process equal-time events in their supplied order.
All events are structurally valid. Quantities and TTL values are positive integers when present.
Unknown operations are outside scope.

Return exactly this envelope:

```python
{"schema_version": 1, "result": {
    "responses": [{"request_id": request_id, "code": code, "available": int}],
    "available": int,
    "purchased": int,
    "holds": [{"hold_id": hold_id, "qty": int, "expires_at": int_or_None}]
}}
```

The result has exactly four fields. Each response and hold has exactly three fields.
Responses stay in event order. Sort final holds by `hold_id`.
`purchased` is the total quantity from successful purchases.

## Rules and state

Each call starts with initial available stock, zero purchases, and empty state containers.
The solver tracks active hold quantities, expiry times, used hold IDs, and cached responses.
The stock identity is:

```text
available = initial stock - purchased - sum(active hold quantities)
```

Before every event, if `policy.expire` is true, remove all active holds with
`expires_at <= event.time`. Restore their quantities to available stock.
Keep their IDs in the used-ID set. This step also occurs before a repeated request.
No expiry step occurs after the last event. Do not advance time to clear final holds.

After expiry, check the request cache. A repeated ID returns its original response.
Do this even if its operation, quantity, hold ID, time, or TTL changed.
Do not apply the operation again. Do not replace its stock snapshot with current stock.
Cache every first response, including failures. Copy each response when appending it.

For each first request:

1. `reserve`: If the hold ID was used, return `duplicate_hold`. Check this before stock.
   Otherwise, if `qty > available`, return `insufficient`. A failed reserve does not use its hold ID.
   Otherwise, add the active hold, mark its ID used, subtract its quantity, and return `ok`.
   With expiry enabled, set `expires_at = event.time + event.ttl`.
   With expiry disabled, set `expires_at = None` and ignore TTL.
2. `buy`: If `qty > available`, return `insufficient` without a state change.
   Otherwise, subtract quantity, add it to purchased stock, and return `ok`.
3. `release`: If the hold is active, remove its quantity and expiry record, restore stock,
   and return `ok`. Otherwise return `missing_hold`. Keep its ID marked used.

Hold IDs cannot be reused after a successful reserve, including after release or expiry.
First responses contain stock after the operation. Repeated responses contain the original stock snapshot.
Expiry can therefore change current stock while a repeated response shows older stock.

## Implementation and checks

The expiry step precedes the request-cache branch. Separate maps store quantities and expiry times.
Release and expiry remove both active records. The used-ID set survives both operations.
When the expire flag is false or absent, the stage 0 rules still apply.
The flags `reject_key_conflict` and `allow_amend` remain outside this stage.
Do not infer later behavior from their presence in the policy.

Run these commands from this software directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both commands passed. The interface check checks only the API.
The six prior tests remain. They check repeated changed-payload requests, cached failures,
used-ID priority, failed reserve ID reuse, ignored TTL, sorted holds, conservation,
empty events, native JSON output, exact keys, and input preservation.
Four new tests check expiry before a repeat, a cached failed buy after expiry,
the exact expiry boundary, permanent used IDs, simultaneous expiry, final active holds,
equal-time order, release before expiry, and stock conservation.

The supplied input returned:

```text
response codes = [ok, insufficient, ok, insufficient, ok]
response available snapshots = [4, 4, 4, 4, 5]
final available = 5
purchased = 5
holds = []
```

## Limits and next action

No stage 1 work remains. Invalid input validation is outside the contract.
Expiry currently scans active holds before each event. No large-load performance check was required.
Do not expire only on first requests, refresh cached responses, reuse expired IDs,
or expire beyond the last event. These approaches conflict with the task rules.

Earlier rules were recovered with `read_notes.py --all`.
Only solution code, local tests, and handoff notes were deliberately changed.
No network, other agents, helper source, library source, graders, or reference solutions were used.
