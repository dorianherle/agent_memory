Goal: # Linear sensor experiment, stage 0
Current steering [n-2]:
The laboratory now supplies correlated measurement errors. Update the same API.
If `covariance` is a matrix, use it as the full covariance of `y`. It overrides `sigma`. Use generalized least squares: minimize residual-transpose times covariance-inverse times residual.
Use `(X^T C^-1 X)^-1` for parameter covariance. Do not scale it by residual error.
The one-sided gain gate and fit gate remain as specified. The supplied covariance is symmetric positive definite.
Apply CHANGE1.json to input.json. Preserve independent-error support. Update HANDOFF
Latest handoff [n-1]:
# Sensor calibration: stage 0 handoff

## Status and next action

The stage 0 implementation is complete. All six local tests passed. The basic interface check passed. No stage 0 work remains open. Read the next supplied task before you make a change. Preserve the stage 0 rules unless that task explicitly changes them. Rerun the local tests and the basic interface check after each change.

## API and input contract

`solution.py` exports `solve(payload: dict) -> dict`. Use only the Python standard library and NumPy. `solve` must not read files, print, use