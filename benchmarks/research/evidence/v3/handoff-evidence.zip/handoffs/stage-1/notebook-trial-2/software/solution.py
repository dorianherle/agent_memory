"""Replay the inventory ledger with optional expiry and cached responses."""


def solve(payload: dict) -> dict:
    available = payload["stock"]
    purchased = 0
    holds = {}
    expires_at = {}
    expire = payload.get("policy", {}).get("expire", False)
    used_hold_ids = set()
    cached = {}
    responses = []
    for event in payload["events"]:
        if expire:
            expired = [hold_id for hold_id in holds
                       if expires_at[hold_id] <= event["time"]]
            for hold_id in expired:
                available += holds.pop(hold_id)
                del expires_at[hold_id]
        request_id = event["request_id"]
        if request_id in cached:
            responses.append(dict(cached[request_id]))
            continue
        op = event["op"]
        if op == "reserve":
            hold_id = event["hold_id"]
            qty = event["qty"]
            if hold_id in used_hold_ids:
                code = "duplicate_hold"
            elif qty > available:
                code = "insufficient"
            else:
                holds[hold_id] = qty
                expires_at[hold_id] = event["time"] + event["ttl"] if expire else None
                used_hold_ids.add(hold_id)
                available -= qty
                code = "ok"
        elif op == "buy":
            qty = event["qty"]
            if qty > available:
                code = "insufficient"
            else:
                available -= qty
                purchased += qty
                code = "ok"
        elif op == "release":
            hold_id = event["hold_id"]
            if hold_id in holds:
                available += holds.pop(hold_id)
                del expires_at[hold_id]
                code = "ok"
            else:
                code = "missing_hold"
        else:
            raise ValueError("Unsupported operation")
        response = {"request_id": request_id, "code": code, "available": available}
        cached[request_id] = response
        responses.append(dict(response))
    return {"schema_version": 1, "result": {
        "responses": responses,
        "available": available,
        "purchased": purchased,
        "holds": [{"hold_id": hold_id, "qty": holds[hold_id], "expires_at": expires_at[hold_id]}
                  for hold_id in sorted(holds)],
    }}
