Goal: # Inventory reservation ledger, stage 0
Current steering [n-2]:
Enable expiring holds when `policy.expire` is true. A successful reserve expires at event.time + event.ttl.
Before EVERY event, including a repeated request, expire holds for which expires_at <= event.time. Restore their stock, but keep their IDs marked used.
After this expiry step, a repeated request still returns its original cached response. Thus its stock snapshot can differ from current stock. Do not recompute cached responses. No expiry occurs beyond the final event time.
Apply CHANGE1.json. Preserve behavior when expire is false. Update 
Latest handoff [n-1]:
# Inventory ledger: stage 0 handoff

## Status and next action

The stage 0 implementation is complete. All six local tests passed. The basic interface check passed. No stage 0 work remains open. Read the next supplied task before you make a change. Preserve the stage 0 rules unless that task explicitly changes them. Rerun the local tests and the basic interface check after each change.

## API and input contract

`solution.py` exports `solve(payload: dict) -> dict`. Use only the Python standard library and NumPy. This implementation needs only the st