# Sensor calibration: stage 1 handoff

## Status

Stage 1 is complete. All nine local tests passed. The basic interface check passed.
No required work is open. Read the next task before you make a change.
Keep the rules below unless the next task changes them.

## API and input

`solution.py` exports `solve(payload: dict) -> dict`.
Use only the Python standard library and NumPy. The solver uses NumPy.
It must not read files, print, use a network, or change its input.
Return native JSON values and finite numbers.

The input contains aligned arrays `x`, `y`, `sigma`, and `include`, plus `covariance` and `policy`.
The model is `y = offset + gain*x + error`. Use only rows with `include = true`.
Valid inputs have at least three included observations, full-rank design, positive sigma,
and finite data. A supplied covariance matrix is symmetric positive definite.

If covariance is null or absent, use independent measurement errors with standard deviations `sigma`.
If covariance is a matrix, use it as the full observation covariance. It overrides sigma completely.
Select the included rows and columns of that matrix before any factorization or inversion.
Do not select a submatrix from the inverse of the full covariance.

Return exactly this envelope:

```python
{"schema_version": 1, "result": {
    "offset": float, "gain": float, "gain_se": float,
    "gain_lower": float, "chi2": float, "dof": int,
    "reduced_chi2": float, "accepted": bool, "reason": str
}}
```

The result has exactly these nine fields. Do not return a parameter covariance field.

## Scientific method

For included observations, use design columns `[1, x]` and observation covariance `C`.
Minimize `residual.T @ inverse(C) @ residual`.

```text
beta = inverse(X.T @ inverse(C) @ X) @ X.T @ inverse(C) @ y
parameter_covariance = inverse(X.T @ inverse(C) @ X)
offset = beta[0]
gain = beta[1]
gain_se = sqrt(parameter_covariance[1, 1])
residual = y - X @ beta
chi2 = residual.T @ inverse(C) @ residual
dof = included observation count - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided * gain_se
```

The covariance represents known measurement uncertainty. Do not scale parameter covariance
or gain standard error by residual size or reduced chi-square.
Use the supplied one-sided z value. Do not substitute a two-sided or Student t value.

The gain gate passes when `gain_lower >= min_gain`.
The fit gate passes when `reduced_chi2 <= max_reduced_chi2`.
Equality passes. Accept only when both gates pass.
Return `ok` for both passing gates, `gain` for gain failure only,
`fit` for fit failure only, and `gain+fit` for both failures.

## Numerical implementation

The independent-error branch retains the stage 0 centered weighted sums:

```text
w_i = 1 / sigma_i^2
W = sum(w_i)
x_bar = sum(w_i*x_i) / W
y_bar = sum(w_i*y_i) / W
Sxx = sum(w_i*(x_i-x_bar)^2)
gain = sum(w_i*(x_i-x_bar)*(y_i-y_bar)) / Sxx
offset = y_bar - gain*x_bar
gain_se = sqrt(1 / Sxx)
chi2 = sum((residual_i / sigma_i)^2)
```

The correlated branch uses Cholesky whitening and reduced QR decomposition.
This avoids forming the full observation precision matrix.
Let `L @ L.T = C`. Center x at its ordinary mean and use columns `[1, x-x_origin]`.
Solve `L @ A = centered_design` and `L @ b = y`.
Compute `A = Q @ R`, then solve `R @ beta_centered = Q.T @ b`.
Compute centered parameter covariance as `inverse(R) @ inverse(R).T`.
The gain variance is unchanged by x centering. Return the original intercept as
`beta_centered[0] - gain*x_origin`.
Compute chi-square from the squared norm of the whitened residual.
All output scalars are converted to native Python types.

## Checks and supplied result

Run these commands from this research directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both commands passed. The interface check checks only the API.
The six prior tests remain. They check an exact line and known uncertainty,
unequal sigma values against a matrix calculation, excluded observations,
uncertainty independent of residual size, all gate reasons and equality,
native output types, exact keys, and input preservation.

Three new tests check correlated fits against a direct matrix calculation,
noncontiguous exclusion with covariance row and column selection, sigma override,
diagonal covariance parity with independent errors, known gain uncertainty,
unscaled covariance with changing residuals, and all gate outcomes with equality.
The correlated matrix test uses a fixed random seed of 217 and positive definite matrices.

The supplied input returned:

```text
offset = 1.0179999999999998
gain = 1.0
gain_se = 0.0282842712474619
gain_lower = 0.9534765138529331
chi2 = 1.9100000000000024
dof = 3
reduced_chi2 = 0.6366666666666675
accepted = true
reason = ok
```

## Limits and next action

No stage 1 work remains. Invalid input validation is outside the contract.
Extreme numerical ranges and nearly singular covariance matrices were not tested.
Do not discard correlations, combine sigma with a supplied covariance,
scale covariance by fit error, use excluded rows, omit the intercept,
or change the acceptance inequalities. These approaches conflict with the task rules.

Earlier rules were recovered with `read_notes.py --all`.
Only solution code, local tests, and handoff notes were deliberately changed.
The input already contained the supplied change and was left unchanged.
No network, other agents, helper source, library source, graders, or reference solutions were used.
