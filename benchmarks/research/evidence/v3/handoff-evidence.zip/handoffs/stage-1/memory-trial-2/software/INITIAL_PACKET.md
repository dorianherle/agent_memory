## Goal
[29bade17] # Inventory reservation ledger, stage 0
Cache the response of every first request, including failed requests. Repeated request IDs return the exact cached response. At stage 0 they return that response even if the event payload differs. … [more]

## Steering
[739c5e2d] Enable expiring holds when `policy.expire` is true. A successful reserve expires at event.time + eve…
Apply CHANGE1.json. Preserve behavior when expire is false. Update HANDOFF.md after your checks. … [more]

## Handoff
[2528e6d3] # Inventory ledger: stage 0 handoff
"responses": [
After each first request, create and cache a response with the request ID, code, and stock after that operation. Append its value to the response list. The implementation copies response dictionaries when it appends them. Repeated responses have exactly the same JSON content as the cached response. … [more]