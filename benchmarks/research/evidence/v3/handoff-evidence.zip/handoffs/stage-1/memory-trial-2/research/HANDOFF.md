# Sensor calibration: stage 1 handoff

## Status

Stage 1 is complete. Eleven local tests passed. The basic interface check passed. No work is open for this stage. Read the next task before you change the code. Preserve these rules unless a later task changes them.

## Sources and scope

I read TASK.md, STEERING.md, INITIAL_PACKET.md, input.json, and ../API.md. I recovered all prior notes with the supplied read_notes.py --all command. The input already contained the change. I did not change it.

Only solution.py, test_local.py, and this HANDOFF.md were changed in this task. No network, other agents, reference solutions, hidden tests, helper source, or library source were used. All file access stayed in this receiver workspace, except execution of the supplied Python runtime.

## API and input

Export solve(payload: dict) -> dict. Use only the Python standard library and NumPy. Do not read files, print, use a network, or change the input in solve. Return native JSON values and finite numbers.

The input has aligned x, y, sigma, and include arrays. It also has covariance and policy. The sensor model is y = offset + gain*x + error. Use only observations where include is true. Valid inputs have at least three included observations, full-rank design, positive sigma, and finite data. A supplied covariance matrix is symmetric positive definite.

Return exactly:

```python
{"schema_version": 1, "result": {
    "offset": float, "gain": float, "gain_se": float,
    "gain_lower": float, "chi2": float, "dof": int,
    "reduced_chi2": float, "accepted": bool, "reason": str
}}
```

Do not add parameter covariance to the output. The covariance field is an input field.

## Independent errors

When covariance is null or absent, use the prior centered weighted fit. Each sigma is the known standard deviation of y. It is not an estimated residual deviation.

For included rows:

```text
w = 1 / sigma^2
W = sum(w)
x_bar = sum(w*x) / W
y_bar = sum(w*y) / W
Sxx = sum(w*(x-x_bar)^2)
Sxy = sum(w*(x-x_bar)*(y-y_bar))
gain = Sxy / Sxx
offset = y_bar - gain*x_bar
gain_se = sqrt(1 / Sxx)
residual = y - offset - gain*x
chi2 = sum((residual/sigma)^2)
```

The prior independent path was retained to preserve its numerical behavior.

## Correlated errors

When covariance is a matrix, it gives the full covariance of y. It overrides sigma. Select included rows of x and y. Select those same rows AND columns of covariance. Use the covariance submatrix, not a submatrix of the full precision matrix.

Let X have columns [1, x], and let C be the selected covariance. Fit generalized least squares:

```text
beta = (X.T C^-1 X)^-1 X.T C^-1 y
parameter_covariance = (X.T C^-1 X)^-1
residual = y - X beta
chi2 = residual.T C^-1 residual
gain_se = sqrt(parameter_covariance[1, 1])
```

The implementation avoids explicit inversion of C. It uses a Cholesky factor L with C = L L.T. It solves L A = X and L b = y. A reduced QR factorization gives A = Q R. It solves R beta = Q.T b. Parameter covariance is R^-1 R^-T. It computes chi2 as the squared norm of L^-1 residual. Offset and gain are the first and second elements of beta.

Do not multiply parameter covariance or gain_se by residual error or reduced chi-square. Known measurement uncertainty determines the standard error in both modes.

## Scientific decisions and gates

The following rules apply in both modes:

```text
dof = number of included observations - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided*gain_se
gain_pass = gain_lower >= policy.min_gain
fit_pass = reduced_chi2 <= policy.max_reduced_chi2
accepted = gain_pass AND fit_pass
```

Equality passes at both gates. Use the supplied one-sided z value. Do not replace it with a two-sided value or a Student t value.

Return reason ok when both gates pass. Return gain when only the gain gate fails. Return fit when only the fit gate fails. Return gain+fit when both fail. Return native Python floats, integer dof, and Boolean accepted.

## Checks and sample result

Run from this research directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both commands passed. -B prevents bytecode writes. The interface check alone does not establish scientific correctness.

The six prior tests still pass. They cover an exact line, known gain uncertainty, unequal sigma against a matrix calculation, observation exclusion, unchanged uncertainty when residuals change, all four gate reasons, threshold equality, native JSON, exact keys, and input preservation.

Five added tests cover a dense correlated covariance against a separate inverse-based matrix calculation; sigma override; exclusion on both covariance axes; diagonal covariance agreement with independent errors; parameter uncertainty unchanged by residual changes; correlated input preservation; finite JSON output; and all gate reasons with equality.

For input.json, the result is approximately:

```text
offset = 1.018
gain = 1.0000000000000004
gain_se = 0.028284271247461905
gain_lower = 0.9534765138529335
chi2 = 1.910000000000003
dof = 3
reduced_chi2 = 0.6366666666666677
accepted = true
reason = ok
```

Small floating-point differences are allowed by the common API.

## Limits and next action

No stage 1 work remains. Invalid-input validation is outside the supplied contract. Extreme floating-point ranges and nearly singular matrices were not tested. The supplied matrices are positive definite and the design is full rank. Do not replace known covariance with residual estimates. Run all prior and added tests after each later change.
