# Inventory ledger: stage 1 handoff

## Status

Stage 1 is complete. Ten local tests passed. The basic interface check passed. No work is open for this stage. Read the next task before you change the code. Preserve these rules unless a later task changes them.

## Sources and scope

I read TASK.md, STEERING.md, INITIAL_PACKET.md, input.json, CHANGE.json, and ../API.md. I recovered all prior notes with the supplied read_notes.py --all command. The input already contained the change. I did not change it.

Only solution.py, test_local.py, and this HANDOFF.md were changed in this task. No network, other agents, reference solutions, hidden tests, helper source, or library source were used. All file access stayed in this receiver workspace, except execution of the supplied Python runtime.

## API and input

Export solve(payload: dict) -> dict. Use only the Python standard library and NumPy. This solver needs only the standard library. Do not read files, print, use a network, or change the input in solve. Return native JSON values and finite numbers.

The input contains stock, policy, and events. Events have request_id, integer time, and op. Times are nondecreasing. Keep the given event order, including equal-time events. Quantities and TTL values are positive integers when present. Inputs are structurally valid. Unknown operations are outside scope.

The output envelope is:

```python
{"schema_version": 1, "result": {
    "responses": [{"request_id": str, "code": str, "available": int}],
    "available": int,
    "purchased": int,
    "holds": [{"hold_id": str, "qty": int, "expires_at": int_or_null}]
}}
```

Each object has exactly the shown keys. Keep responses in event order. Sort final holds by hold_id. Purchased is the sum of quantities from successful purchases.

## Rules and processing order

Each call starts with initial available stock, zero purchases, empty active holds, empty used hold IDs, and an empty request cache.

Before EVERY event, if policy.expire is true, remove all holds with expires_at <= event.time. Add their quantities to available stock. Keep their IDs in the used-ID set. Do this before the request-cache check, including on repeated requests. Do not run expiry after the final event.

After the expiry step, check the request cache. A repeated request ID returns its exact original response value. Ignore changed payload fields on a repeat. Do not apply its operation again. Do not change its stock snapshot to the current stock. Cache every first response, including failures.

For a first request:

1. reserve: Check used hold IDs first. Return duplicate_hold if the ID was used by a successful reserve. Otherwise return insufficient if qty > available. Otherwise subtract qty, add the active hold, mark the ID used, and return ok. If expiry is enabled, set expires_at = time + ttl.
2. buy: Return insufficient if qty > available. Otherwise subtract qty, add qty to purchased, and return ok.
3. release: If the hold is active, remove it, add its quantity to available stock, remove its expiry entry, and return ok. Otherwise return missing_hold.

Cache the response after the operation. Its available field is the stock after that event's expiry and operation. Copy response dictionaries into the output list.

A failed reserve does not use its hold ID. A successful reserve uses its ID forever. Release and expiry never free that ID for reuse. Duplicate-hold checking takes priority over insufficient stock.

When policy.expire is false, ignore time and TTL for expiry. Return expires_at as null. The policy may be empty; missing expire defaults to false. Key-conflict rejection and amendments remain outside this stage. Do not infer behavior from the reserved policy flags.

The stock identity is:

```text
available + purchased + sum(active hold quantities) = initial stock
```

## Implementation decisions

holds maps active IDs to quantities. expirations maps active IDs to expiry times only when expiry is enabled. used_hold_ids keeps all successful reserve IDs. cached maps request IDs to response values. All containers are local to a call.

The expiry scan first collects due IDs, then removes them. This prevents mutation during iteration. Release removes its expiry entry to prevent a later second stock restoration. Expiry leaves the request cache intact. No extra output fields were added.

## Checks and sample result

Run from this software directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both commands passed. -B prevents bytecode writes. The interface check alone does not establish ledger correctness.

The six prior tests still pass. They cover changed request payloads, cached stock snapshots, failed request caching, permanently used hold IDs, duplicate priority, failed reserve IDs, ignored TTL, sorted holds, stock conservation, empty inputs, exact output keys, native JSON, and input preservation.

Four added tests cover expiry before a repeated request; cached failures after stock restoration; expiry at the exact deadline; used IDs after expiry; missing release after expiry; no expiry after the last event; sorted active expiry times; explicit release before expiry; and simultaneous expiry of several holds.

For input.json, response codes are [ok, insufficient, ok, insufficient, ok]. Stock snapshots are [4, 4, 4, 4, 5]. Final available is 5. Purchased is 5. Holds is empty. The repeated requests retain old snapshots even after expiry restores stock.

## Limits and next action

No stage 1 work remains. Input validation and unknown operations are outside the contract. Extreme event-list sizes were not benchmarked. Expiry uses a linear scan of active holds per event. Do not add conflict rejection or amendments without a later task. Run the prior and added tests after each later change.
