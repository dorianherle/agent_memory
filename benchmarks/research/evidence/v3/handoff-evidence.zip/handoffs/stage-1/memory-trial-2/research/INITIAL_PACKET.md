## Goal
[52260a15] # Linear sensor experiment, stage 0
Stage 0 has independent errors. Each `sigma` is a known standard deviation of `y`, not an estimated residual deviation. Use weighted least squares with an intercept.
Scientific decisions are fixed: … [more]

## Steering
[7a6b4a8d] The laboratory now supplies correlated measurement errors. Update the same API.
Use `(X^T C^-1 X)^-1` for parameter covariance. Do not scale it by residual error. … [more]

## Handoff
[9d3cbebc] # Sensor calibration: stage 0 handoff
## API and input contract
```python
}}
gain = Sxy / Sxx
Use the supplied measurement uncertainty directly. Do not multiply parameter covariance or standard error by reduced chi-square. Use a one-sided lower gain limit. Do not replace the supplied `z_one_sided` with a two-sided quantile or a Student t quantile. … [more]