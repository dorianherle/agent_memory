# Reservation ledger: stage 1 handoff

Stage 1 is complete. Fourteen local tests and the basic interface check
passed. Earlier rules were recovered with `read_notes.py --all`. The input
already contained the change. No input, store, helper, or task files changed.

## API and input

`solution.py` exports `solve(payload: dict) -> dict`. Use only the standard
library and NumPy; this solution needs only the standard library. The function
does not read files, print, use a network, or change its input. Return native
JSON values and finite numbers. Each call starts with fresh local state.
The output is `{"schema_version": 1, "result": {...}}`.

Input contains initial `stock`, `policy`, and an ordered `events` list.
Each event has `request_id`, nondecreasing integer `time`, and `op`.
Request IDs can repeat. Events are structurally valid. Quantities and TTLs
are positive integers when present. Unknown operations are outside scope.

Policy `expire` controls expiry. If absent, the implementation uses false
for earlier input compatibility. `reject_key_conflict` and `allow_amend`
have no new behavior in this stage. Do not infer rules from their names.
Changed request content still returns the original cached response.

The result has exactly `responses`, `available`, `purchased`, and `holds`.
Responses stay in event order. Each response has exactly `request_id`,
`code`, and `available`. Available in a response is its original stock
snapshot. It can differ from current or final available stock.
Holds are sorted by hold ID. Each entry has exactly `hold_id`, `qty`, and
`expires_at`. Purchased is the total quantity of successful purchases.

## State and invariant

Local state contains available stock, purchased quantity, active holds,
their expiry times, all used hold IDs, request cache, and response list.

```text
available = initial stock - purchased - sum(active hold quantities)
```

Only a successful reserve marks a hold ID as used. A release or expiry
removes an active hold, but never removes its ID from the used set.
Each failed operation leaves inventory state unchanged, after any required
expiry. The request cache contains every first response, including failures.

## Order of event processing

1. If expiry is enabled, remove every active hold with
   `expires_at <= event.time`. Add its quantity to available stock. Keep its
   ID marked used. This step occurs before every event, including repeated
   requests and failed operations.
2. Check the request cache. If the request ID exists, append a copy of the
   original response. Do not perform the operation or update that response.
   Changed operation, quantity, hold ID, time, or TTL does not change it.
3. For a first request, perform its operation. Create and cache the response,
   including a failure, then append a separate dictionary copy.

No expiry occurs after the final event time. An empty event list changes
no state. Expiry uses event time, with no wall clock or background activity.

## Operations

Reserve checks the used hold ID before it checks stock. If the ID was used,
the code is `duplicate_hold`, even if stock is also insufficient. Otherwise,
if qty exceeds available stock, the code is `insufficient`. This failure does
not mark the ID used. On success, store qty, mark the ID used, subtract qty
from available stock, and return `ok`. With expiry enabled, store
`expires_at = event.time + event.ttl`. With expiry disabled, store null and
ignore TTL. A used hold ID cannot be reused after release or expiry.

Buy returns `insufficient` if qty exceeds available stock. Otherwise,
subtract qty from available, add qty to purchased, and return `ok`.

Release returns `missing_hold` if the hold is not active. Otherwise, remove
the hold and its expiry record, restore qty to stock, and return `ok`.
A release at the expiry time fails because expiry occurs first.
Removing the expiry record on release prevents stock from being restored
twice. The implementation raises ValueError for unknown operations.

## Decisions to preserve

Do not cache only successes, replay repeated operations, replace cached
snapshots with current stock, reject changed duplicate content, or allow
hold ID reuse. Do not mark failed reserve IDs used. Do not expire when the
policy is false. Do not expire beyond the last event. Keep exact output
fields and sorted holds. The expiry scan is linear in active hold count
per event; no larger-scale performance requirement was supplied.

## Checks

From this software directory, run:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All fourteen tests passed. Eight earlier tests cover cached stock snapshots,
changed duplicates, cached failures, failed reserve ID availability, released
ID reuse rejection, code priority, ignored TTL, sorted holds, conservation,
empty events, exact stock purchase, exact schema, and input preservation.
Six new tests cover expiry before repeated requests, unchanged failure cache,
expiry boundary releases, permanent used IDs, recorded expiry times, no future
expiry, simultaneous expiries before buy, early release without double stock
restoration, and changed duplicates with input preservation.

The supplied input returned these responses in order:

```text
a: ok, available 4
b: insufficient, available 4
a: ok, available 4
b: insufficient, available 4
c: ok, available 5
final available: 5
purchased: 5
holds: []
```

The interface check alone does not verify ledger behavior. The local state
tests provide the recorded behavior checks. No open stage 1 work remains.
Read any later task before adding new policy behavior. Keep the prior tests
and these rules when the next change is supplied.
