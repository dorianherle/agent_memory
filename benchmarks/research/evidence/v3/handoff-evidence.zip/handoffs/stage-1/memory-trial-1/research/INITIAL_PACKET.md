## Goal
[26e0899f] # Linear sensor experiment, stage 0
Stage 0 has independent errors. Each `sigma` is a known standard deviation of `y`, not an estimated residual deviation. Use weighted least squares with an intercept.
Scientific decisions are fixed: … [more]

## Steering
[4bdd74ba] The laboratory now supplies correlated measurement errors. Update the same API.
Use `(X^T C^-1 X)^-1` for parameter covariance. Do not scale it by residual error. … [more]

## Handoff
[e54078ae] # Sensor fit: stage 0 handoff
Do not add an output `covariance` field. The task reserves the input field.
beta_hat = inverse(X.T W X) X.T W y
Do not multiply parameter covariance by reduced chi-square. The measurement
- Changes in residual size do not rescale parameter covariance.
Do not infer later covariance behavior from the reserved field alone. … [more]