import copy
import json
import math
import unittest

import numpy as np

from solution import solve


def payload(x=(0, 1, 2), y=(0, 1, 2), sigma=(1, 1, 1)):
    return {"x": list(x), "y": list(y), "sigma": list(sigma),
            "include": [True] * len(x), "covariance": None,
            "policy": {"min_gain": -100.0, "max_reduced_chi2": 100.0,
                       "z_one_sided": 1.6448536269514722}}


class SensorTests(unittest.TestCase):
    def test_correlated_fit_and_selected_covariance(self):
        rng = np.random.default_rng(391)
        for _ in range(30):
            x = rng.normal(size=8)
            y = rng.normal(size=8)
            a = rng.normal(size=(8, 8))
            c = a @ a.T + np.eye(8) * 0.2
            data = payload(x, y, np.full(8, 0.001))
            data["covariance"] = c.tolist()
            data["include"] = [True, False, True, True, False, True, True, True]
            original = copy.deepcopy(data)
            mask = np.asarray(data["include"])
            selected_c = c[np.ix_(mask, mask)]
            design = np.column_stack((np.ones(mask.sum()), x[mask]))
            precision_design = np.linalg.solve(selected_c, design)
            parameter_c = np.linalg.inv(design.T @ precision_design)
            beta = parameter_c @ precision_design.T @ y[mask]
            residual = y[mask] - design @ beta
            result = solve(data)["result"]
            self.assertEqual(data, original)
            self.assertAlmostEqual(result["offset"], beta[0], places=10)
            self.assertAlmostEqual(result["gain"], beta[1], places=10)
            self.assertAlmostEqual(result["gain_se"], np.sqrt(parameter_c[1, 1]), places=10)
            self.assertAlmostEqual(result["chi2"], residual @ np.linalg.solve(selected_c, residual), places=10)
            self.assertEqual(result["dof"], int(mask.sum()) - 2)
            data["sigma"] = [1000] * 8
            self.assertEqual(result, solve(data)["result"])

    def test_diagonal_covariance_and_covariance_scale(self):
        data = payload(x=(0, 1, 2, 3), y=(1, 2, 4, 3), sigma=(1, 2, 0.5, 1))
        independent = solve(data)["result"]
        data["covariance"] = np.diag(np.asarray(data["sigma"])**2).tolist()
        correlated = solve(data)["result"]
        for field in ("offset", "gain", "gain_se", "chi2", "gain_lower"):
            self.assertAlmostEqual(independent[field], correlated[field])
        data["covariance"] = (9 * np.asarray(data["covariance"])).tolist()
        scaled = solve(data)["result"]
        self.assertAlmostEqual(scaled["gain"], correlated["gain"])
        self.assertAlmostEqual(scaled["gain_se"], 3 * correlated["gain_se"])
        self.assertAlmostEqual(scaled["chi2"], correlated["chi2"] / 9)

    def test_exact_line_known_uncertainty(self):
        result = solve(payload())["result"]
        self.assertAlmostEqual(result["offset"], 0.0)
        self.assertAlmostEqual(result["gain"], 1.0)
        self.assertAlmostEqual(result["gain_se"], math.sqrt(0.5))
        self.assertAlmostEqual(result["chi2"], 0.0)
        self.assertEqual(result["dof"], 1)

    def test_sigma_scale_changes_uncertainty_and_chi2(self):
        data = payload(y=(0, 2, 2))
        first = solve(data)["result"]
        data["sigma"] = [3, 3, 3]
        second = solve(data)["result"]
        self.assertAlmostEqual(first["gain"], second["gain"])
        self.assertAlmostEqual(first["offset"], second["offset"])
        self.assertAlmostEqual(second["gain_se"], 3 * first["gain_se"])
        self.assertAlmostEqual(second["chi2"], first["chi2"] / 9)

    def test_residual_variance_does_not_scale_parameter_covariance(self):
        first = solve(payload())["result"]
        second = solve(payload(y=(100, -100, 100)))["result"]
        self.assertAlmostEqual(first["gain_se"], second["gain_se"])

    def test_excluded_rows_do_not_change_fit(self):
        data = payload()
        baseline = solve(data)["result"]
        data["x"].append(100)
        data["y"].append(-500)
        data["sigma"].append(0.001)
        data["include"].append(False)
        self.assertEqual(baseline, solve(data)["result"])

    def test_reason_and_equality(self):
        data = payload(y=(0, 0, 0))
        data["policy"]["z_one_sided"] = 0.0
        data["policy"]["min_gain"] = 0.0
        data["policy"]["max_reduced_chi2"] = 0.0
        result = solve(data)["result"]
        self.assertTrue(result["accepted"])
        self.assertEqual(result["reason"], "ok")
        data["policy"]["min_gain"] = 1.0
        self.assertEqual(solve(data)["result"]["reason"], "gain")
        data["y"] = [1, -2, 1]
        self.assertEqual(solve(data)["result"]["reason"], "gain+fit")
        data["policy"]["min_gain"] = -100.0
        self.assertEqual(solve(data)["result"]["reason"], "fit")

    def test_random_weighted_fits_against_scalar_formulas(self):
        rng = np.random.default_rng(1701)
        for _ in range(40):
            x = rng.uniform(-5, 5, 8)
            y = rng.normal(size=8)
            sigma = rng.uniform(0.2, 3, 8)
            data = payload(x, y, sigma)
            result = solve(data)["result"]
            w = 1 / sigma**2
            mean_x = np.sum(w * x) / np.sum(w)
            mean_y = np.sum(w * y) / np.sum(w)
            spread = np.sum(w * (x - mean_x)**2)
            gain = np.sum(w * (x - mean_x) * (y - mean_y)) / spread
            offset = mean_y - gain * mean_x
            chi2 = np.sum(((y - offset - gain * x) / sigma)**2)
            self.assertAlmostEqual(result["gain"], gain, places=11)
            self.assertAlmostEqual(result["offset"], offset, places=11)
            self.assertAlmostEqual(result["gain_se"], math.sqrt(1 / spread), places=11)
            self.assertAlmostEqual(result["chi2"], chi2, places=10)
            self.assertAlmostEqual(result["gain_lower"], gain - data["policy"]["z_one_sided"] / math.sqrt(spread), places=11)

    def test_interface_and_input_preservation(self):
        data = payload()
        original = copy.deepcopy(data)
        output = solve(data)
        self.assertEqual(data, original)
        self.assertEqual(output["schema_version"], 1)
        self.assertEqual(set(output["result"]), {"offset", "gain", "gain_se", "gain_lower", "chi2", "dof", "reduced_chi2", "accepted", "reason"})
        json.dumps(output, allow_nan=False)
        self.assertIs(type(output["result"]["dof"]), int)
        self.assertIs(type(output["result"]["accepted"]), bool)


if __name__ == "__main__":
    unittest.main()
