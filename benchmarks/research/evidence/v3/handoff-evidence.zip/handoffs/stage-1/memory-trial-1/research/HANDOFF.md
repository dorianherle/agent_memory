# Sensor fit: stage 1 handoff

Stage 1 is complete. Nine local tests and the basic interface check passed.
The input already contained the change. No input or task files were changed.
Earlier rules were recovered with `read_notes.py --all`.

## API and input

`solution.py` exports `solve(payload: dict) -> dict`. Use only the standard
library and NumPy. The function does not read files, print, use a network,
or change its input. All output values are native JSON values and finite.
The output is `{"schema_version": 1, "result": {...}}`.

Input arrays are `x`, `y`, `sigma`, and `include`. Select only included rows.
Tests supply at least three included observations, full-rank design, positive
sigma, and finite data. The policy supplies `min_gain`, `max_reduced_chi2`,
and `z_one_sided`. Do not replace these values with fixed constants.

If `covariance` is null, sigma gives known independent standard deviations.
If `covariance` is a matrix, it is the full covariance of y and overrides
sigma. The supplied matrix is symmetric positive definite. Select its
principal submatrix for the included rows before the fit. Do not use the
principal submatrix of the full precision matrix.

The result has exactly these fields: `offset`, `gain`, `gain_se`,
`gain_lower`, `chi2`, `dof`, `reduced_chi2`, `accepted`, `reason`.
Numerical values are floats except integer dof. Accepted is Boolean.
Reason is `ok`, `gain`, `fit`, or `gain+fit`. There is no output covariance.

## Method

The model is `y = offset + gain*x + error`. The design has an intercept.
For selected rows, `X = [1, x]`. Independent errors use
`C = diag(sigma**2)`. Correlated errors use the selected covariance.

```text
beta = inverse(X.T C^-1 X) X.T C^-1 y
Cov(beta) = inverse(X.T C^-1 X)
gain_se = sqrt(Cov(beta)[1, 1])
residual = y - X beta
chi2 = residual.T C^-1 residual
dof = number of included observations - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided * gain_se
```

Do not scale parameter covariance by residual error or reduced chi-square.
Known measurement errors set the uncertainty.

The implementation centers and scales x, then uses reduced QR. The existing
independent branch is retained. Set `s = min(sigma)`, `a = s/sigma`,
`w = a**2`, `c = sum(w*x)/sum(w)`, and `h = max(abs(x-c))`.
The design is `D = [1, (x-c)/h]`. QR uses `a*D` and `a*y`.
Solve `R theta = Q.T (a*y)`. Gain is `theta[1]/h`; offset is
`theta[0] - gain*c`. Gain SE is `s*norm(row_1(R^-1))/h`.

For correlated errors, set c to mean(x), h as above, and factor `C = L L.T`
with Cholesky. QR uses `solve(L,D)` and `solve(L,y)`. Gain SE is
`norm(row_1(R^-1))/h`. Residuals use `y-D theta` to limit cancellation.
Chi-square is the squared norm of `solve(L,residual)` in the correlated
branch, or `residual/sigma` in the independent branch. This avoids an
explicit covariance inverse in the implementation.

## Decisions

The gain gate passes when `gain_lower >= min_gain`. The fit gate passes
when `reduced_chi2 <= max_reduced_chi2`. Equality passes. Acceptance requires
both gates. Strict failure comparisons have no added tolerance. Reason is
`gain+fit` if both fail, `gain` or `fit` if one fails, and `ok` otherwise.
Excluded rows do not affect any calculation or the degrees of freedom.

Do not use unweighted regression, remove the intercept, rescale uncertainty
from residuals, use a two-sided limit, or add result fields.

## Checks

From this research directory, run:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All nine tests passed. The seven prior tests cover exact-line uncertainty,
sigma scaling, residual-independent uncertainty, excluded rows, all reasons,
gate equality, 40 random weighted fits, exact output types, JSON, and input
preservation. New tests cover 30 random positive definite covariance fits,
excluded covariance rows, independent normal-equation comparisons, sigma
override, diagonal covariance equivalence, and covariance scaling.

The supplied input returned offset 1.018, gain 1.0, gain SE
0.0282842712474619, gain lower 0.9534765138529331, chi-square 1.91,
dof 3, reduced chi-square 0.6366666666666675, accepted true, reason `ok`.
The interface check alone is not a scientific check. The numerical tests
provide the recorded scientific checks. Extreme floating-point scales were
not tested. No open stage 1 work remains. Preserve these rules and tests
when a later change is supplied.
