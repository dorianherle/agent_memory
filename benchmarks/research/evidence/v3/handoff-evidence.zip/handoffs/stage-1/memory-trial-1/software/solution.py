"""Replay stock purchases and reservations with request response caching."""


def solve(payload: dict) -> dict:
    available = payload["stock"]
    purchased = 0
    holds = {}
    expirations = {}
    expire = payload.get("policy", {}).get("expire", False)
    used_hold_ids = set()
    request_cache = {}
    responses = []

    for event in payload["events"]:
        if expire:
            expired = [hold_id for hold_id in holds
                       if expirations[hold_id] <= event["time"]]
            for hold_id in expired:
                available += holds.pop(hold_id)
                expirations.pop(hold_id)
        request_id = event["request_id"]
        if request_id in request_cache:
            responses.append(dict(request_cache[request_id]))
            continue

        operation = event["op"]
        if operation == "reserve":
            hold_id = event["hold_id"]
            qty = event["qty"]
            if hold_id in used_hold_ids:
                code = "duplicate_hold"
            elif qty > available:
                code = "insufficient"
            else:
                holds[hold_id] = qty
                expirations[hold_id] = event["time"] + event["ttl"] if expire else None
                used_hold_ids.add(hold_id)
                available -= qty
                code = "ok"
        elif operation == "buy":
            qty = event["qty"]
            if qty > available:
                code = "insufficient"
            else:
                purchased += qty
                available -= qty
                code = "ok"
        elif operation == "release":
            hold_id = event["hold_id"]
            if hold_id not in holds:
                code = "missing_hold"
            else:
                available += holds.pop(hold_id)
                expirations.pop(hold_id)
                code = "ok"
        else:
            raise ValueError("Unsupported operation")

        response = {"request_id": request_id, "code": code, "available": available}
        request_cache[request_id] = response
        responses.append(dict(response))

    return {"schema_version": 1, "result": {
        "responses": responses,
        "available": available,
        "purchased": purchased,
        "holds": [
            {"hold_id": hold_id, "qty": holds[hold_id], "expires_at": expirations[hold_id]}
            for hold_id in sorted(holds)
        ],
    }}
