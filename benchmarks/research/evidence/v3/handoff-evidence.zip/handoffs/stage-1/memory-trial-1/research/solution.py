"""Linear fit with known independent or correlated measurement errors."""

import numpy as np


def solve(payload: dict) -> dict:
    included = np.asarray(payload["include"], dtype=bool)
    x = np.asarray(payload["x"], dtype=float)[included]
    y = np.asarray(payload["y"], dtype=float)[included]
    # Center and scale x before QR to reduce numerical conditioning problems.
    # A common uncertainty scale does not change the fitted parameters.
    covariance = payload.get("covariance")
    if covariance is None:
        sigma = np.asarray(payload["sigma"], dtype=float)[included]
        sigma_scale = float(np.min(sigma))
        row_scale = sigma_scale / sigma
        weights = row_scale * row_scale
        x_center = float(np.dot(weights, x) / np.sum(weights))
    else:
        selected = np.flatnonzero(included)
        covariance = np.asarray(covariance, dtype=float)[np.ix_(selected, selected)]
        cholesky = np.linalg.cholesky(covariance)
        sigma_scale = 1.0
        x_center = float(np.mean(x))
    dx = x - x_center
    x_scale = float(np.max(np.abs(dx)))
    design = np.column_stack((np.ones(x.size), dx / x_scale))
    if covariance is None:
        whitened_design = design * row_scale[:, None]
        whitened_y = y * row_scale
    else:
        whitened_design = np.linalg.solve(cholesky, design)
        whitened_y = np.linalg.solve(cholesky, y)
    q, r = np.linalg.qr(whitened_design, mode="reduced")
    coefficients = np.linalg.solve(r, q.T @ whitened_y)
    gain = float(coefficients[1] / x_scale)
    offset = float(coefficients[0] - gain * x_center)

    # Known errors: do not rescale this covariance by residual chi-square.
    r_inverse = np.linalg.solve(r, np.eye(2))
    gain_se = float(sigma_scale * np.linalg.norm(r_inverse[1]) / x_scale)
    residuals = y - design @ coefficients
    normalized_residuals = (residuals / sigma if covariance is None
                            else np.linalg.solve(cholesky, residuals))
    chi2 = float(np.dot(normalized_residuals, normalized_residuals))
    dof = int(x.size - 2)
    reduced_chi2 = float(chi2 / dof)

    policy = payload["policy"]
    gain_lower = float(gain - policy["z_one_sided"] * gain_se)
    gain_failed = gain_lower < policy["min_gain"]
    fit_failed = reduced_chi2 > policy["max_reduced_chi2"]
    reason = "gain+fit" if gain_failed and fit_failed else (
        "gain" if gain_failed else "fit" if fit_failed else "ok"
    )
    return {"schema_version": 1, "result": {
        "offset": offset,
        "gain": gain,
        "gain_se": gain_se,
        "gain_lower": gain_lower,
        "chi2": chi2,
        "dof": dof,
        "reduced_chi2": reduced_chi2,
        "accepted": bool(not gain_failed and not fit_failed),
        "reason": reason,
    }}
