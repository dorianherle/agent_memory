## Goal
[e5d9e229] # Inventory reservation ledger, stage 0
Cache the response of every first request, including failed requests. Repeated request IDs return the exact cached response. At stage 0 they return that response even if the event payload differs. … [more]

## Steering
[f7ef3acb] Enable expiring holds when `policy.expire` is true. A successful reserve expires at event.time + eve…
Apply CHANGE1.json. Preserve behavior when expire is false. Update HANDOFF.md after your checks. … [more]

## Handoff
[89c5053e] # Reservation ledger: stage 0 handoff
- `expire`.
snapshot for that request, which can differ from final available stock.
Do not replace the cached stock snapshot with current stock.
### reserve
After every first request, create and cache its response, including failures.
Do not infer rules for expiration, conflicts, or amendment from policy names. … [more]