import importlib.util,json
from pathlib import Path
R=Path(__file__).resolve().parent;APP=R.parent.parent
case=next(x for x in json.loads((APP/'handoff-author-pack/private/research_cases.json').read_text()) if x['name']=='equality_pass')
rows=[]
for stage in (0,1,2):
 conditions=['sender'] if stage==0 else ['memory','notebook']
 for condition in conditions:
  path=R/'senders/trial-1/research/solution.py' if stage==0 else R/f'stage-{stage}'/f'{condition}-trial-1/research/solution.py'
  spec=importlib.util.spec_from_file_location(f'candidate_{stage}_{condition}',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  result=module.solve(case['input'])['result']
  rows.append({'stage':stage,'condition':condition,'result':result})
report={'case':'equality_pass','policy':case['input']['policy'],'expected':case['expected'],'rows':rows,'interpretation':'The gate is at zero residual error. Small floating-point residuals can produce a failed Boolean decision although numeric values pass tolerance. The same defect exists in the common sender. Grader results are retained without post-hoc repair.'}
(R/'boundary-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
