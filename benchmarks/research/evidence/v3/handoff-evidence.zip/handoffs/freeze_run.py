import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
for trial in (1,2):
    a=json.loads((R/'stage-1'/f'memory-trial-{trial}'/'preparation.json').read_text())
    b=json.loads((R/'stage-1'/f'notebook-trial-{trial}'/'preparation.json').read_text())
    for task in ('research','software'):
        assert a[task]['source_code_sha256']==b[task]['source_code_sha256']
        assert a[task]['stored_note_sha256']==b[task]['stored_note_sha256']
        assert a[task]['initial_packet_chars']<=1200 and b[task]['initial_packet_chars']<=1200
files=list(R.glob('*.py'))+[R/'protocol.json']
for p in (R/'stage-1').rglob('*'):
    if p.is_file() and '.agent_memory' not in p.parts and p.suffix in ('.md','.py','.json'):files.append(p)
frozen={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(R/'run-freeze.json').write_text(json.dumps({'before_receiver_runs':True,'sha256':frozen},indent=2)+'\n')
print('Stage 1 paired source and note hashes match. All packets fit 1200 characters.')
