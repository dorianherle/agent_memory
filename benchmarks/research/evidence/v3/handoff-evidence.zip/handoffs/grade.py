"""Grade completed handoff stages without sending feedback to workers."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parent;APP=R.parent.parent;PACK=APP/'handoff-author-pack'
p=argparse.ArgumentParser();p.add_argument('--stage',type=int,required=True);a=p.parse_args()
subprocess.run([sys.executable,str(PACK/'verify_freeze.py')],check=True)
rows=[]
conditions=['sender'] if a.stage==0 else ['memory','notebook']
for trial in (1,2):
 for condition in conditions:
  base=R/'senders'/f'trial-{trial}' if a.stage==0 else R/f'stage-{a.stage}'/f'{condition}-trial-{trial}'
  for task in ('research','software'):
   folder=base/task;solution=folder/'solution.py';assert (folder/'HANDOFF.md').exists()
   run=subprocess.run([sys.executable,str(PACK/'private'/'grader.py'),task,str(solution),'--stage',str(a.stage)],capture_output=True,text=True,check=True)
   grade=json.loads(run.stdout)
   result={'trial':trial,'condition':condition,'stage':a.stage,'task':task,'source_sha256':hashlib.sha256(solution.read_bytes()).hexdigest(),'grade':grade}
   (R/f'stage-{a.stage}-{condition}-trial-{trial}-{task}-grade.json').write_text(json.dumps(result,indent=2)+'\n')
   rows.append(result)
summary={}
for condition in conditions:
 subset=[row for row in rows if row['condition']==condition]
 summary[condition]={'complete_tasks':sum(x['grade']['full_passes']==x['grade']['cases'] for x in subset),'attempted_tasks':len(subset),'full_case_passes':sum(x['grade']['full_passes'] for x in subset),'cases':sum(x['grade']['cases'] for x in subset),'mean_partial_score':sum(x['grade']['score'] for x in subset)/len(subset)}
result={'stage':a.stage,'summary':summary,'rows':rows}
(R/f'stage-{a.stage}-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'stage':a.stage,'summary':summary},indent=2))
