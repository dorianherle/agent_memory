"""Read the assigned note store. Log returned text; no grading information."""
import argparse,json,sqlite3,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
config=json.loads((BASE/'store.json').read_text())
p=argparse.ArgumentParser();p.add_argument('--query');p.add_argument('--id');p.add_argument('--all',action='store_true');args=p.parse_args()
tick=time.perf_counter()
if config['condition']=='memory':
    sys.path.insert(0,config['library'])
    from agent_memory import Memory
    m=Memory(BASE/'notes')
    if args.id: items=m.find(ids=[args.id],k=100,dedupe=False)
    elif args.query: items=m.find(query=args.query,k=100,dedupe=False)
    else: items=m.state()
    rows=[{'id':x.id,'text':x.message} for x in items]
    m._catalog.close()
else:
    conn=sqlite3.connect(BASE/'notes'/'index.sqlite3')
    if args.id: hits=conn.execute('SELECT id,text FROM notes WHERE id=?',(args.id,)).fetchall()
    elif args.query:
        expr=' OR '.join('"'+x+'"' for x in args.query.replace('"',' ').split() if x)
        hits=conn.execute('SELECT id,text FROM notes WHERE notes MATCH ? ORDER BY bm25(notes),CAST(ordinal AS INTEGER) DESC',(expr,)).fetchall()
    else: hits=conn.execute('SELECT id,text FROM notes ORDER BY CAST(ordinal AS INTEGER)').fetchall()
    rows=[{'id':x[0],'text':x[1]} for x in hits];conn.close()
text=json.dumps(rows,ensure_ascii=False,indent=2)
with (BASE/'reads.jsonl').open('a') as f:f.write(json.dumps({'query':args.query,'id':args.id,'all':args.all,'returned_chars':len(text),'elapsed_ms':(time.perf_counter()-tick)*1000,'text':text})+'\n')
print(text)
