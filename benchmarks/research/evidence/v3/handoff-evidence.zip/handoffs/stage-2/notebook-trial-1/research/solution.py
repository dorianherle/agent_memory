"""Linear fit with known independent or correlated measurement errors."""

import numpy as np


def solve(payload: dict) -> dict:
    included = np.asarray(payload["include"], dtype=bool)
    x = np.asarray(payload["x"], dtype=float)[included]
    y = np.asarray(payload["y"], dtype=float)[included]
    covariance = payload.get("covariance")
    if covariance is None:
        sigma = np.asarray(payload["sigma"], dtype=float)[included]
        sigma_scale = float(np.min(sigma))
        row_scale = sigma_scale / sigma
        weights = row_scale * row_scale
        x_center = float(np.dot(weights, x) / np.sum(weights))
    else:
        # Apply the same declared mask to both axes before whitening.
        # Keep all included rows, even when a fitted residual is large.
        covariance = np.asarray(covariance, dtype=float)[np.ix_(included, included)]
        sigma_scale = float(np.sqrt(np.min(np.diag(covariance))))
        cholesky = np.linalg.cholesky(covariance / sigma_scale**2)
        x_center = float(np.mean(x))

    # Center and scale the design before whitening and QR.
    dx = x - x_center
    x_scale = float(np.max(np.abs(dx)))
    design = np.column_stack((np.ones(x.size), dx / x_scale))
    if covariance is None:
        whitened_design = design * row_scale[:, None]
        whitened_y = y * row_scale
    else:
        whitened_design = np.linalg.solve(cholesky, design)
        whitened_y = np.linalg.solve(cholesky, y)
    q, r = np.linalg.qr(whitened_design, mode="reduced")
    coefficients = np.linalg.solve(r, q.T @ whitened_y)
    gain = float(coefficients[1] / x_scale)
    offset = float(coefficients[0] - gain * x_center)

    # Known errors: do not scale parameter covariance by residual error.
    r_inverse = np.linalg.solve(r, np.eye(2))
    gain_se = float(sigma_scale * np.linalg.norm(r_inverse[1]) / x_scale)
    residuals = y - design @ coefficients
    if covariance is None:
        normalized_residuals = residuals / sigma
    else:
        normalized_residuals = np.linalg.solve(cholesky, residuals) / sigma_scale
    chi2 = float(np.dot(normalized_residuals, normalized_residuals))
    dof = int(x.size - 2)
    reduced_chi2 = float(chi2 / dof)

    policy = payload["policy"]
    gain_lower = float(gain - policy["z_one_sided"] * gain_se)
    gain_failed = gain_lower < policy["min_gain"]
    fit_failed = reduced_chi2 > policy["max_reduced_chi2"]
    reason = "gain+fit" if gain_failed and fit_failed else (
        "gain" if gain_failed else "fit" if fit_failed else "ok"
    )
    return {"schema_version": 1, "result": {
        "offset": offset,
        "gain": gain,
        "gain_se": gain_se,
        "gain_lower": gain_lower,
        "chi2": chi2,
        "dof": dof,
        "reduced_chi2": reduced_chi2,
        "accepted": bool(not gain_failed and not fit_failed),
        "reason": reason,
    }}
