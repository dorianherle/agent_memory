# Sensor fit: stage 2 handoff

## Status

Stage 2 is complete. The existing numerical method already selects both
covariance axes with the declared include mask. It already retains every
included row. No numerical change was needed. The solution comment now states
these rules. New tests verify the changed sample and covariance selection.
The sample fails the stricter fit test. This is the required scientific result.
The input already contained the change. Do not apply it again.

Read TASK.md, STEERING.md, INITIAL_PACKET.md, and ../API.md. Recover prior
rules with `read_notes.py --all`. This run recovered notes n-0 through n-4.
Only solution.py, test_solution.py, and this handoff were changed.

## Interface and input

Export `solve(payload: dict) -> dict`. Use standard library and NumPy only.
Do not read files, print, use a network, or change the input in solve.
Return native JSON values and finite numbers. No state persists between calls.
Output is `{"schema_version": 1, "result": {...}}`.
The result has exactly offset, gain, gain_se, gain_lower, chi2, dof,
reduced_chi2, accepted, and reason. Numeric values are floats except dof,
which is an integer. accepted is Boolean. reason is ok, gain, fit, or gain+fit.
Do not add an output covariance field.

Input has x, y, sigma, include, covariance, and policy. Valid inputs have at
least three included observations, a full-rank design, positive sigma, and
finite data. A supplied covariance matrix is symmetric positive definite.
Select x and y with the include mask. Select covariance rows AND columns with
that same mask before whitening or inversion. Use the principal covariance
submatrix; do not select the corresponding submatrix of the full inverse.
This uses the marginal errors of the included observations.

If covariance is null or absent, use independent errors with variance sigma**2.
If covariance is a matrix, it overrides sigma completely. It is the known
full covariance of measured y. The include mask is predeclared by the protocol.
Keep every included row, including rows with large residuals. Do not clip
data, use robust regression, or rescale measurement uncertainty to pass a test.

## Model, formulas, and method

The model is y = offset + gain*x + error. Fit both offset and gain.
Let X have columns 1 and x for included rows. Let C be the selected covariance,
or diag(sigma**2) for independent errors.

```text
beta = [offset, gain]
beta_hat = inverse(X.T C^-1 X) X.T C^-1 y
Cov(beta_hat) = inverse(X.T C^-1 X)
gain_se = sqrt(Cov(beta_hat)[1,1])
residual = y - X beta_hat
chi2 = residual.T C^-1 residual
dof = number of included observations - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided * gain_se
```

Use known measurement uncertainty. Never multiply parameter covariance by
residual error or reduced chi-square. The lower gain limit is one-sided.

The code avoids a direct inverse of C or the normal matrix. It centers and
scales x, whitens the design, and uses reduced QR.
For independent errors, s=min(sigma), row factors=s/sigma, and the center is
the mean of x weighted by the squared row factors. For correlated errors,
s=sqrt(min(diag(C))), L=Cholesky(C/s**2), and the center is mean(x).
Set h=max(abs(x-center)) and D=[1,(x-center)/h].
For independent errors, A=D*row_factors and b=y*row_factors.
For correlated errors, solve L A=D and L b=y.
Factor A=Q R and solve R theta=Q.T b.

```text
gain = theta[1] / h
offset = theta[0] - gain*center
gain_se = s * norm(row 1 of inverse(R)) / h
residual = y - D theta
```

For independent errors, normalized residual = residual/sigma.
For correlated errors, normalized residual = solve(L,residual)/s.
chi2 is the sum of squared normalized residuals. These calculations preserve
the earlier independent and correlated error methods.

## Acceptance rules

Use the supplied policy values. Gain passes if gain_lower >= min_gain.
Fit passes if reduced_chi2 <= max_reduced_chi2. Equality passes.
Both tests must pass for accepted true. Use strict failure comparisons
without an added tolerance. Return ok for no failed tests, gain for gain
failure alone, fit for fit failure alone, and gain+fit for both failures.
Do not insert a fixed confidence coefficient or a different fit limit.

## Checks and result

Run from this directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All 12 tests passed. The interface check passed. All 10 earlier tests pass.
They check analytic uncertainty, uncertainty scaling, no residual scaling,
exclusions, all reason values and equality, 40 independent weighted fits,
30 correlated fits with exclusions, sigma override, diagonal covariance
agreement, covariance scaling, output fields, JSON, and unchanged input.

The two new tests check the changed sample against scalar formulas for its
compound covariance, retained included residuals, excluded-data independence,
included degrees of freedom, unchanged parameter uncertainty with residual
change, policy use, and principal covariance selection before inversion.
An unequal-correlation fixture also shows a measurable difference from the
rejected submatrix-of-inverse method.

For the changed sample, included x values are 0, 1, 3, 4, 5. The record at
x=2 is excluded. The y=5.7 record at x=4 remains included.
The covariance is 0.006*I + 0.004*ones for the selected rows.

```text
offset = 0.9918604651162775
gain = 1.0569767441860467
gain_se = 0.01867718419094071
gain_lower = 1.0262555100283373
chi2 = 56.02713178294579
dof = 3
reduced_chi2 = 18.675710594315262
accepted = false
reason = fit
```

Gain lower limit exceeds min_gain=0.85. Reduced chi-square exceeds the fit
limit of 1.5. Do not report this failed experiment as accepted.

## Limits and next work

No requested work remains. Extreme floating-point scales were not tested.
The interface check alone does not prove scientific correctness. The analytic
and numerical tests above provide the recorded checks. Preserve both error
methods, all included rows, known uncertainty, gates, and output fields.
No network, helper source, library source, grader, or reference code was used.
