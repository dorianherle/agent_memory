import copy
import json
import math
import unittest

import numpy as np

from solution import solve


def payload(x=(0, 1, 2), y=(0, 1, 2), sigma=(1, 1, 1)):
    return {"x": list(x), "y": list(y), "sigma": list(sigma),
            "include": [True] * len(x), "covariance": None,
            "policy": {"min_gain": -100.0, "max_reduced_chi2": 100.0,
                       "z_one_sided": 1.6448536269514722}}


class SensorTests(unittest.TestCase):
    def test_stage_two_sample_retains_included_residual(self):
        with open("input.json") as source:
            data = json.load(source)
        original = copy.deepcopy(data)
        result = solve(data)["result"]
        self.assertEqual(data, original)
        x = np.array([0., 1., 3., 4., 5.])
        y = np.array([1., 2., 4., 5.7, 6.])
        spread = float(np.sum((x - x.mean())**2))
        gain = float(np.dot(x - x.mean(), y - y.mean()) / spread)
        offset = float(y.mean() - gain * x.mean())
        chi2 = float(np.sum((y - offset - gain * x)**2) / 0.006)
        self.assertAlmostEqual(result["gain"], gain, places=12)
        self.assertAlmostEqual(result["offset"], offset, places=12)
        self.assertAlmostEqual(result["gain_se"], math.sqrt(0.006 / spread), places=12)
        self.assertAlmostEqual(result["chi2"], chi2, places=10)
        self.assertEqual(result["dof"], 3)
        self.assertAlmostEqual(result["reduced_chi2"], chi2 / 3, places=10)
        self.assertFalse(result["accepted"])
        self.assertEqual(result["reason"], "fit")
        data["y"][2] = -1e9
        self.assertEqual(result, solve(data)["result"])
        data["y"][4] = 5.
        perfect = solve(data)["result"]
        self.assertAlmostEqual(result["gain_se"], perfect["gain_se"], places=12)
        self.assertTrue(perfect["accepted"])
        data = copy.deepcopy(original)
        data["policy"]["max_reduced_chi2"] = 20.
        self.assertTrue(solve(data)["result"]["accepted"])

    def test_exclusion_uses_covariance_before_inverse(self):
        data = payload(x=(0, 1, 2, 3), y=(1, 30, 2.5, 4.2))
        c = np.array([[2., 0.8, 0.2, 0.1], [0.8, 3., 0.6, 0.4],
                      [0.2, 0.6, 1., 0.2], [0.1, 0.4, 0.2, 1.5]])
        data["include"] = [True, False, True, True]
        data["covariance"] = c.tolist()
        result = solve(data)["result"]
        mask = np.array(data["include"])
        selected = c[np.ix_(mask, mask)]
        design = np.column_stack((np.ones(3), np.array(data["x"])[mask]))
        cov_beta = np.linalg.inv(design.T @ np.linalg.solve(selected, design))
        beta = cov_beta @ design.T @ np.linalg.solve(selected, np.array(data["y"])[mask])
        self.assertAlmostEqual(result["gain"], beta[1], places=12)
        self.assertAlmostEqual(result["gain_se"], math.sqrt(cov_beta[1, 1]), places=12)
        wrong_cov = np.linalg.inv(design.T @ np.linalg.inv(c)[np.ix_(mask, mask)] @ design)
        self.assertGreater(abs(result["gain_se"] - math.sqrt(wrong_cov[1, 1])), 1e-3)

    def test_exact_line_known_uncertainty(self):
        result = solve(payload())["result"]
        self.assertAlmostEqual(result["offset"], 0.0)
        self.assertAlmostEqual(result["gain"], 1.0)
        self.assertAlmostEqual(result["gain_se"], math.sqrt(0.5))
        self.assertAlmostEqual(result["chi2"], 0.0)
        self.assertEqual(result["dof"], 1)

    def test_sigma_scale_changes_uncertainty_and_chi2(self):
        data = payload(y=(0, 2, 2))
        first = solve(data)["result"]
        data["sigma"] = [3, 3, 3]
        second = solve(data)["result"]
        self.assertAlmostEqual(first["gain"], second["gain"])
        self.assertAlmostEqual(first["offset"], second["offset"])
        self.assertAlmostEqual(second["gain_se"], 3 * first["gain_se"])
        self.assertAlmostEqual(second["chi2"], first["chi2"] / 9)

    def test_residual_variance_does_not_scale_parameter_covariance(self):
        first = solve(payload())["result"]
        second = solve(payload(y=(100, -100, 100)))["result"]
        self.assertAlmostEqual(first["gain_se"], second["gain_se"])

    def test_excluded_rows_do_not_change_fit(self):
        data = payload()
        baseline = solve(data)["result"]
        data["x"].append(100)
        data["y"].append(-500)
        data["sigma"].append(0.001)
        data["include"].append(False)
        self.assertEqual(baseline, solve(data)["result"])

    def test_reason_and_equality(self):
        data = payload(y=(0, 0, 0))
        data["policy"]["z_one_sided"] = 0.0
        data["policy"]["min_gain"] = 0.0
        data["policy"]["max_reduced_chi2"] = 0.0
        result = solve(data)["result"]
        self.assertTrue(result["accepted"])
        self.assertEqual(result["reason"], "ok")
        data["policy"]["min_gain"] = 1.0
        self.assertEqual(solve(data)["result"]["reason"], "gain")
        data["y"] = [1, -2, 1]
        self.assertEqual(solve(data)["result"]["reason"], "gain+fit")
        data["policy"]["min_gain"] = -100.0
        self.assertEqual(solve(data)["result"]["reason"], "fit")

    def test_random_weighted_fits_against_scalar_formulas(self):
        rng = np.random.default_rng(1701)
        for _ in range(40):
            x = rng.uniform(-5, 5, 8)
            y = rng.normal(size=8)
            sigma = rng.uniform(0.2, 3, 8)
            data = payload(x, y, sigma)
            result = solve(data)["result"]
            w = 1 / sigma**2
            mean_x = np.sum(w * x) / np.sum(w)
            mean_y = np.sum(w * y) / np.sum(w)
            spread = np.sum(w * (x - mean_x)**2)
            gain = np.sum(w * (x - mean_x) * (y - mean_y)) / spread
            offset = mean_y - gain * mean_x
            chi2 = np.sum(((y - offset - gain * x) / sigma)**2)
            self.assertAlmostEqual(result["gain"], gain, places=11)
            self.assertAlmostEqual(result["offset"], offset, places=11)
            self.assertAlmostEqual(result["gain_se"], math.sqrt(1 / spread), places=11)
            self.assertAlmostEqual(result["chi2"], chi2, places=10)
            self.assertAlmostEqual(result["gain_lower"], gain - data["policy"]["z_one_sided"] / math.sqrt(spread), places=11)

    def test_compound_covariance_and_sigma_override(self):
        data = payload(x=(0, 1, 2, 3, 4), y=(1, 2, 3, 4, 5))
        data["covariance"] = (0.008 * np.eye(5) + 0.032 * np.ones((5, 5))).tolist()
        data["sigma"] = [0.001] * 5
        result = solve(data)["result"]
        self.assertAlmostEqual(result["gain"], 1)
        self.assertAlmostEqual(result["offset"], 1)
        self.assertAlmostEqual(result["gain_se"], math.sqrt(0.008 / 10))
        data["sigma"] = [200] * 5
        self.assertEqual(result, solve(data)["result"])

    def test_random_gls_with_exclusions(self):
        rng = np.random.default_rng(920)
        for _ in range(30):
            x = rng.uniform(-4, 4, 8)
            y = rng.normal(size=8)
            a = rng.normal(size=(8, 8))
            c = a @ a.T + np.eye(8) * 0.2
            data = payload(x, y)
            data["covariance"] = c.tolist()
            data["include"] = [True, False, True, True, False, True, True, True]
            original = copy.deepcopy(data)
            result = solve(data)["result"]
            mask = np.asarray(data["include"])
            c = c[np.ix_(mask, mask)]
            xx = np.column_stack((np.ones(sum(mask)), x[mask]))
            precision_x = np.linalg.solve(c, xx)
            cov_beta = np.linalg.inv(xx.T @ precision_x)
            beta = cov_beta @ xx.T @ np.linalg.solve(c, y[mask])
            residual = y[mask] - xx @ beta
            self.assertAlmostEqual(result["offset"], beta[0], places=10)
            self.assertAlmostEqual(result["gain"], beta[1], places=10)
            self.assertAlmostEqual(result["gain_se"], math.sqrt(cov_beta[1, 1]), places=10)
            self.assertAlmostEqual(result["chi2"], residual @ np.linalg.solve(c, residual), places=10)
            self.assertEqual(result["dof"], sum(mask) - 2)
            self.assertEqual(data, original)

    def test_diagonal_covariance_and_scale(self):
        data = payload(x=(0, 1, 2, 3), y=(1, 3, 2, 6), sigma=(0.2, 0.4, 1, 0.3))
        baseline = solve(data)["result"]
        c = np.diag(np.asarray(data["sigma"])**2)
        data["covariance"] = c.tolist()
        result = solve(data)["result"]
        for key in ("offset", "gain", "gain_se", "chi2"):
            self.assertAlmostEqual(result[key], baseline[key], places=10)
        data["covariance"] = (c * 9).tolist()
        scaled = solve(data)["result"]
        self.assertAlmostEqual(scaled["gain"], result["gain"])
        self.assertAlmostEqual(scaled["gain_se"], result["gain_se"] * 3)
        self.assertAlmostEqual(scaled["chi2"], result["chi2"] / 9)

    def test_interface_and_input_preservation(self):
        data = payload()
        original = copy.deepcopy(data)
        output = solve(data)
        self.assertEqual(data, original)
        self.assertEqual(output["schema_version"], 1)
        self.assertEqual(set(output["result"]), {"offset", "gain", "gain_se", "gain_lower", "chi2", "dof", "reduced_chi2", "accepted", "reason"})
        json.dumps(output, allow_nan=False)
        self.assertIs(type(output["result"]["dof"]), int)
        self.assertIs(type(output["result"]["accepted"]), bool)


if __name__ == "__main__":
    unittest.main()
