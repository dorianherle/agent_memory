Goal: # Linear sensor experiment, stage 0
Current steering [n-4]:
One measurement can now be excluded by a predeclared protocol. Select both rows AND columns of covariance with the same `include` mask. Use only included rows for degrees of freedom.
The changed sample has a known excluded record and a large residual on an included record. Keep every included record. Automatic clipping, robust regression, and rescaling uncertainty are rejected approaches: they change the experiment's scientific acceptance rule.
The policy now uses a stricter fit gate. Apply CHANGE2.json to the current input.json. Preserve prior
Latest handoff [n-3]:
# Sensor fit: stage 1 handoff

## Status
Stage 1 is complete. The solution supports independent and correlated errors.
The input already contained the change. Input files were not changed.
All earlier rules were recovered with `read_notes.py --all` (notes n-0 to n-2).
Only the solution, local tests, and this handoff were changed.

## API and data
Export `solve(payload: dict) -> dict`. Use standard library and NumPy only.
Do not read files, print, use a network, or change the input in solve.
Return native JSON values and finite numbers.
The output is `{"sc