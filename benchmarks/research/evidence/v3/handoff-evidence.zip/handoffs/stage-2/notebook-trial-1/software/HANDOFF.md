# Reservation ledger: stage 2 handoff

## Status

Stage 2 is complete. Atomic amendment and request conflict checks are enabled
by their policy flags. All prior behavior is preserved. The input already
contained the change. Do not apply it again.
Read TASK.md, STEERING.md, INITIAL_PACKET.md, and ../API.md. Recover all rules
with `read_notes.py --all`. This run recovered notes n-0 through n-4.
Only solution.py, test_solution.py, and this handoff were changed.

## Interface and input

Export `solve(payload: dict) -> dict`. Use the standard library and NumPy only.
This solution needs only the standard library. Do not read files, print, use
a network, or change the input in solve. Return native JSON values and finite
numbers. Each call starts with fresh state.

Input contains stock, policy, and events in order. Each event contains
request_id, nondecreasing integer time, and op. Events are structurally valid.
Quantities and TTL values are positive integers when present. Unknown
operations are outside scope. An amend event requires allow_amend true.
The implementation raises ValueError for unsupported operations.
All three policy flags default to false when absent.

Output is `{"schema_version": 1, "result": {...}}`.
The result has exactly responses, available, purchased, and holds.
Each response has exactly request_id, code, and available. Responses stay
in event order. available is the stock snapshot for that response.
Each hold has exactly hold_id, qty, and expires_at. Sort holds by hold_id.
expires_at is null when expiry is disabled, otherwise an integer deadline.

## State and event order

Maintain available, purchased, active holds, permanently used hold IDs,
first-response cache, first-event fingerprints, and responses in order.

```text
available = initial stock - purchased - sum(active hold quantities)
```

Before every event, including repeated requests, process expiry when expire
is true. Remove holds with expires_at <= event.time. Restore their quantity.
Keep their IDs marked used. Do not process expiry after the final event.
When expire is false, ignore TTL and time. Never expire these holds.

After expiry, check the request cache. With reject_key_conflict false,
every repeated request returns the original response, even with changed data.
With reject_key_conflict true, compare the ordered fingerprint:

```text
(op, hold_id or null, qty or null, ttl or null)
```

Time is excluded. Missing fields map to null. An exact match returns the
original response, including its original available snapshot. A changed
fingerprint returns conflict with current available stock. Do not execute
the operation or replace the original response or fingerprint.
Cache every first request, including failures. Return separate response
dictionary copies. Conflict responses do not replace cached data.

## Operations for first requests

reserve: Check the used ID first. Return duplicate_hold if it was used.
Otherwise return insufficient if qty exceeds available. On success subtract
qty, store the hold, mark its ID used, and return ok. With expiry enabled,
expires_at = event.time + event.ttl. Otherwise expires_at is null.
Failed reservations do not mark their IDs used. Successfully reserved IDs
can never be reused, including after release or expiry.

buy: Return insufficient if qty exceeds available. Otherwise subtract qty,
add it to purchased, and return ok. Purchases are permanent.

release: Return missing_hold if the hold is not active. Otherwise remove it,
restore its quantity, and return ok. Keep its ID used.

amend, when allow_amend is true: Return missing_hold if the hold is not active.
Check new qty against available + old qty. Return insufficient if it does
not fit. Keep the old quantity and deadline exactly on failure. On success,
set available = available + old qty - new qty and replace only the quantity.
Keep the original expires_at and used ID. Return ok. This also permits a
smaller quantity or the same quantity. Do not release and reserve again.

Failed operations preserve inventory state after the required expiry step.

## Checks

Run from this directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All 17 tests passed. The interface check passed. The prior 12 tests still pass.
They check earlier cache rules, failed request caching, used IDs, code priority,
stock conservation, sorting, expiry order and boundary, ignored TTL, no expiry
after the final event, output fields, JSON values, and input preservation.
Five new tests check failed atomic amendment, expansion to the stock limit,
contraction, preserved deadline, missing expired holds, nonexpiring amendment,
every fingerprint field, failed-request conflicts, original cache preservation,
and exact replay after expiry. The changed sample is also checked.

The changed sample returns:

```text
codes:       ok, ok, insufficient, ok, conflict, ok
snapshots:   4,  1,  1,            0,  0,        0
available = 7
purchased = 0
holds = [{hold_id: H2, qty: 3, expires_at: 11}]
```

The final request expires H1, then returns the cached amendment response.
Its snapshot is 0 while final available stock is 7.

## Limits and next work

No requested work remains. The interface check alone does not prove state
correctness. The local tests provide the checks above. Expiry scans active
holds before each event; no performance target was supplied.
Preserve all rules, output fields, and tests when a later task arrives.
No network, helper source, library source, grader, or reference code was used.
