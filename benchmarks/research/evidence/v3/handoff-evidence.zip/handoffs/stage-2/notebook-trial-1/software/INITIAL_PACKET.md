Goal: # Inventory reservation ledger, stage 0
Current steering [n-4]:
Enable atomic `amend` when `policy.allow_amend` is true. It replaces an active hold quantity with positive `qty`. Credit that hold's old quantity when checking stock. If the new quantity does not fit, return `insufficient` and preserve the old hold exactly. If absent, return `missing_hold`. On success keep the original expires_at.
A release-then-reserve implementation is rejected: an unsuccessful amendment must not lose the original hold or deadline.
When `policy.reject_key_conflict` is true, a repeated request ID is a replay only if its finger
Latest handoff [n-3]:
# Reservation ledger: stage 1 handoff

## Status
Stage 1 is complete. Expiring holds are supported when policy.expire is true.
Behavior with expire false is preserved. The input already contained the change.
All earlier rules were recovered with `read_notes.py --all` (notes n-0 to n-2).
Only the solution, local tests, and this handoff were changed.

## API and data
Export `solve(payload: dict) -> dict`. Use standard library and NumPy only.
This solution needs only the standard library. Do not read files, print,
use a network, or change the input in so