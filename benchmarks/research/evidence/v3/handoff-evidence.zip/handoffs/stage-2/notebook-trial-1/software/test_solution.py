import copy
import json
import unittest

from solution import solve


def run(events, stock=10, expire=False, allow_amend=False, reject_key_conflict=False):
    return solve({"stock": stock,
                  "policy": {"expire": expire, "reject_key_conflict": reject_key_conflict, "allow_amend": allow_amend},
                  "events": events})["result"]


def event(request_id, op, time=0, **fields):
    return {"request_id": request_id, "op": op, "time": time, **fields}


class LedgerTests(unittest.TestCase):
    def test_atomic_amend_and_original_deadline(self):
        base = [event("a", "reserve", hold_id="H", qty=6, ttl=10),
                event("b", "reserve", 1, hold_id="J", qty=3, ttl=10)]
        failed = run(base + [event("c", "amend", 2, hold_id="H", qty=8)],
                     expire=True, allow_amend=True)
        self.assertEqual(failed["responses"][-1]["code"], "insufficient")
        self.assertEqual(failed["holds"][0], {"hold_id": "H", "qty": 6, "expires_at": 10})
        result = run(base + [event("c", "amend", 2, hold_id="H", qty=7),
                             event("d", "amend", 3, hold_id="H", qty=2)],
                     expire=True, allow_amend=True)
        self.assertEqual(result["available"], 5)
        self.assertEqual(result["holds"][0], {"hold_id": "H", "qty": 2, "expires_at": 10})

    def test_amend_missing_expired_and_nonexpiring(self):
        result = run([event("a", "reserve", hold_id="H", qty=10, ttl=2),
                      event("b", "amend", 2, hold_id="H", qty=1)],
                     expire=True, allow_amend=True)
        self.assertEqual(result["responses"][-1]["code"], "missing_hold")
        self.assertEqual(result["available"], 10)
        result = run([event("a", "reserve", hold_id="H", qty=10),
                      event("b", "amend", 100, hold_id="H", qty=4)], allow_amend=True)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 4, "expires_at": None}])
        self.assertEqual(result["available"], 6)

    def test_conflicts_preserve_cache_after_expiry(self):
        result = run([event("a", "reserve", hold_id="H", qty=6, ttl=2),
                      event("a", "reserve", 2, hold_id="H", qty=6, ttl=3),
                      event("b", "buy", 2, qty=2),
                      event("a", "reserve", 3, hold_id="H", qty=6, ttl=2)],
                     expire=True, reject_key_conflict=True)
        self.assertEqual(result["responses"][1], {"request_id": "a", "code": "conflict", "available": 10})
        self.assertEqual(result["responses"][0], result["responses"][3])
        self.assertEqual(result["available"], 8)

    def test_all_fingerprint_fields_and_failed_cache(self):
        original = event("a", "reserve", hold_id="H", qty=11, ttl=2)
        for field, value in [("op", "amend"), ("hold_id", "J"), ("qty", 1), ("ttl", 3)]:
            changed = dict(original, time=1)
            changed[field] = value
            result = run([original, changed, dict(original, time=2)], reject_key_conflict=True, allow_amend=True)
            self.assertEqual([r["code"] for r in result["responses"]], ["insufficient", "conflict", "insufficient"])
            self.assertEqual(result["available"], 10)

    def test_stage_two_sample(self):
        with open("input.json") as source:
            payload = json.load(source)
        before = copy.deepcopy(payload)
        result = solve(payload)["result"]
        self.assertEqual(payload, before)
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "ok", "insufficient", "ok", "conflict", "ok"])
        self.assertEqual([r["available"] for r in result["responses"]], [4, 1, 1, 0, 0, 0])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [{"hold_id": "H2", "qty": 3, "expires_at": 11}])

    def test_original_sequence_and_cached_stock_snapshot(self):
        result = run([event("a", "reserve", hold_id="H1", qty=4, ttl=5),
                      event("b", "buy", 1, qty=3),
                      event("a", "reserve", 2, hold_id="H1", qty=4, ttl=5),
                      event("c", "release", 3, hold_id="H1")])
        self.assertEqual(result, {"responses": [
            {"request_id": "a", "code": "ok", "available": 6},
            {"request_id": "b", "code": "ok", "available": 3},
            {"request_id": "a", "code": "ok", "available": 6},
            {"request_id": "c", "code": "ok", "available": 7}],
            "available": 7, "purchased": 3, "holds": []})

    def test_changed_duplicate_request_returns_old_response(self):
        result = run([event("a", "buy", qty=3),
                      event("a", "reserve", 20, qty=5, hold_id="new")])
        self.assertEqual(result["responses"][0], result["responses"][1])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [])

    def test_failed_reserve_does_not_use_hold_id_but_is_cached(self):
        result = run([event("a", "reserve", qty=11, hold_id="H"),
                      event("b", "reserve", 1, qty=2, hold_id="H"),
                      event("a", "reserve", 2, qty=1, hold_id="other")])
        self.assertEqual([r["code"] for r in result["responses"]], ["insufficient", "ok", "insufficient"])
        self.assertEqual(result["responses"][2]["available"], 10)
        self.assertEqual(result["available"], 8)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 2, "expires_at": None}])

    def test_released_hold_id_cannot_be_reused(self):
        result = run([event("a", "reserve", qty=4, hold_id="H"),
                      event("b", "release", 1, hold_id="H"),
                      event("c", "reserve", 2, qty=20, hold_id="H"),
                      event("d", "release", 3, hold_id="H")])
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "ok", "duplicate_hold", "missing_hold"])
        self.assertEqual(result["available"], 10)

    def test_failed_buy_and_release_are_cached(self):
        result = run([event("a", "reserve", qty=10, hold_id="H"),
                      event("b", "buy", 1, qty=1),
                      event("c", "release", 2, hold_id="absent"),
                      event("d", "release", 3, hold_id="H"),
                      event("b", "buy", 4, qty=1),
                      event("c", "release", 5, hold_id="H")])
        self.assertEqual(result["responses"][1], result["responses"][4])
        self.assertEqual(result["responses"][2], result["responses"][5])
        self.assertEqual(result["available"], 10)
        self.assertEqual(result["purchased"], 0)

    def test_ttl_is_ignored_and_holds_are_sorted(self):
        result = run([event("a", "reserve", qty=2, hold_id="Z", ttl=1),
                      event("b", "reserve", 1000, qty=3, hold_id="A", ttl=1),
                      event("c", "buy", 1001, qty=5)])
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 5)
        self.assertEqual(result["holds"], [
            {"hold_id": "A", "qty": 3, "expires_at": None},
            {"hold_id": "Z", "qty": 2, "expires_at": None}])
        self.assertEqual(result["available"] + result["purchased"] + sum(h["qty"] for h in result["holds"]), 10)

    def test_empty_events_and_exact_stock_purchase(self):
        self.assertEqual(run([]), {"responses": [], "available": 10, "purchased": 0, "holds": []})
        result = run([event("a", "buy", qty=10), event("b", "buy", 1, qty=1)])
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 10)
        self.assertEqual(result["responses"][1]["code"], "insufficient")

    def test_expiry_before_duplicate_and_failed_cache(self):
        result = run([event("a", "reserve", hold_id="H", qty=6, ttl=3),
                      event("b", "buy", 1, qty=5),
                      event("a", "release", 3, hold_id="H"),
                      event("b", "buy", 4, qty=1),
                      event("c", "buy", 4, qty=5)], expire=True)
        self.assertEqual(result["responses"][0], result["responses"][2])
        self.assertEqual(result["responses"][1], result["responses"][3])
        self.assertEqual([r["available"] for r in result["responses"]], [4, 4, 4, 4, 5])
        self.assertEqual(result["available"], 5)
        self.assertEqual(result["purchased"], 5)
        self.assertEqual(result["holds"], [])

    def test_expiry_boundary_and_used_id(self):
        result = run([event("a", "reserve", hold_id="H", qty=6, ttl=3),
                      event("b", "buy", 2, qty=5),
                      event("c", "release", 3, hold_id="H"),
                      event("d", "reserve", 3, hold_id="H", qty=20, ttl=1),
                      event("e", "buy", 3, qty=10)], expire=True)
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "insufficient", "missing_hold", "duplicate_hold", "ok"])
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 10)

    def test_release_and_no_expiry_after_final_event(self):
        result = run([event("a", "reserve", hold_id="Z", qty=2, ttl=2),
                      event("b", "reserve", 1, hold_id="A", qty=3, ttl=4),
                      event("c", "release", 1, hold_id="Z"),
                      event("d", "buy", 2, qty=1)], expire=True)
        self.assertEqual(result["available"], 6)
        self.assertEqual(result["purchased"], 1)
        self.assertEqual(result["holds"], [{"hold_id": "A", "qty": 3, "expires_at": 5}])
        self.assertEqual(result["available"] + result["purchased"] + sum(h["qty"] for h in result["holds"]), 10)

    def test_multiple_expiries_and_same_time_events(self):
        result = run([event("a", "reserve", hold_id="A", qty=2, ttl=2),
                      event("b", "reserve", hold_id="B", qty=3, ttl=2),
                      event("c", "buy", 2, qty=10),
                      event("d", "buy", 2, qty=1)], expire=True)
        self.assertEqual([r["available"] for r in result["responses"]], [8, 5, 0, 0])
        self.assertEqual(result["purchased"], 10)
        self.assertEqual(result["holds"], [])

    def test_interface_and_input_preservation(self):
        data = {"stock": 5, "events": [event("a", "reserve", qty=2, hold_id="H")], "policy": {}}
        original = copy.deepcopy(data)
        output = solve(data)
        self.assertEqual(data, original)
        self.assertEqual(output["schema_version"], 1)
        self.assertEqual(set(output["result"]), {"responses", "available", "purchased", "holds"})
        self.assertEqual(set(output["result"]["responses"][0]), {"request_id", "code", "available"})
        json.dumps(output, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
