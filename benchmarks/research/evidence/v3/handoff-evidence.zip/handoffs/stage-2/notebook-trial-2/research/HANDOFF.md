# Sensor calibration: stage 2 handoff

## Status

Stage 2 is complete. All 10 local tests passed. The basic interface check passed.
The research task was completed first. No required work is open.
Read the next task before a change. Keep all rules below unless that task changes them.

## API and input

Export `solve(payload: dict) -> dict` from `solution.py`.
Use only the Python standard library and NumPy. Do not read files, print,
use a network, or change the input in `solve`.
Return native JSON values and finite numbers.

Input arrays `x`, `y`, `sigma`, and `include` are aligned.
The model is `y = offset + gain*x + error`.
Valid inputs have at least three included observations, full-rank design,
positive sigma, and finite data. A supplied covariance is symmetric positive definite.
If covariance is absent or null, sigma gives known independent measurement errors.
If covariance is a matrix, it overrides sigma completely.

Output has exactly this form:

```python
{"schema_version": 1, "result": {
    "offset": float, "gain": float, "gain_se": float,
    "gain_lower": float, "chi2": float, "dof": int,
    "reduced_chi2": float, "accepted": bool, "reason": str
}}
```

## Required method

Use only observations with `include = true`.
Select both rows and columns of covariance with this same mask before factorization.
Do not select a submatrix from the inverse of the full covariance.
Keep every included observation, including those with large residuals.

For included observations and design columns `[1, x]`, use generalized least squares:

```text
beta = inverse(X.T @ inverse(C) @ X) @ X.T @ inverse(C) @ y
parameter_covariance = inverse(X.T @ inverse(C) @ X)
offset = beta[0]
gain = beta[1]
gain_se = sqrt(parameter_covariance[1, 1])
residual = y - X @ beta
chi2 = residual.T @ inverse(C) @ residual
dof = included observation count - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided * gain_se
```

Measurement uncertainty is known. Do not scale covariance or standard error
with residuals or reduced chi-square. Use the supplied one-sided z value.
The gain gate passes when `gain_lower >= min_gain`.
The fit gate passes when `reduced_chi2 <= max_reduced_chi2`.
Equality passes. Accept only if both gates pass.
Reasons are `ok`, `gain`, `fit`, and `gain+fit`, for the corresponding failed gates.

The correlated branch uses Cholesky whitening and reduced QR decomposition.
Center x at its ordinary mean. Solve `L @ A = centered_design` and `L @ b = y`,
where `L @ L.T = selected_covariance`. Solve `R @ beta = Q.T @ b`.
Compute parameter covariance as `inverse(R) @ inverse(R).T`.
Centering leaves gain variance unchanged. Restore offset as `beta[0] - gain*x_origin`.
Compute chi-square from the whitened residual norm.

The independent branch keeps centered weighted sums:

```text
w = 1 / sigma^2
x_bar = sum(w*x) / sum(w)
y_bar = sum(w*y) / sum(w)
Sxx = sum(w*(x-x_bar)^2)
gain = sum(w*(x-x_bar)*(y-y_bar)) / Sxx
offset = y_bar - gain*x_bar
gain_se = sqrt(1 / Sxx)
chi2 = sum((residual/sigma)^2)
```

## Work and checks

Earlier rules were recovered with `read_notes.py --all`.
The input already contains the stage 2 change. It was left unchanged.
No separate CHANGE2.json exists here. The task confirms that the input is prepared.
The prior solver already meets the new numerical rules. Its algorithm was preserved.
The docstring now states the selection and uncertainty rules.
A new regression test checks the changed sample, excluded-value independence,
retention of the included large residual, and changes to the fit limit only.

All nine prior tests remain. They check independent and correlated estimates,
matrix row and column selection, sigma override, diagonal covariance equivalence,
known unscaled uncertainty, all gate reasons and equality, JSON types,
exact output keys, and input preservation.

Run from this directory with the supplied runtime:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

The 10 tests passed. The interface check passed. It checks only the API.
The supplied sample returned:

```text
offset = 0.991860465116277
gain = 1.056976744186047
gain_se = 0.018677184190940714
gain_lower = 1.0262555100283375
chi2 = 56.027131782945865
dof = 3
reduced_chi2 = 18.675710594315287
accepted = false
reason = fit
```

## Limits

Automatic clipping, robust regression, and uncertainty rescaling are prohibited.
They change the scientific acceptance rule. Do not omit the intercept, discard
correlations, combine sigma with covariance, or use a two-sided or Student t limit.
Invalid input validation is outside the contract. Extreme numerical ranges and
nearly singular covariance matrices were not tested.
Only solution code, local tests, and this handoff note were changed.
No network, other agents, helper source, library source, graders, or references were used.
