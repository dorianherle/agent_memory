import copy
import json
import unittest

import numpy as np

from solution import solve


def data():
    return {"x": [0, 1, 2, 3], "y": [1, 3, 5, 7],
            "sigma": [1, 1, 1, 1], "include": [True] * 4,
            "covariance": None,
            "policy": {"min_gain": 1, "max_reduced_chi2": 2,
                       "z_one_sided": 1.6448536269514722}}


class CalibrationTests(unittest.TestCase):
    def test_stage_two_keeps_included_residual_and_rejects_fit(self):
        payload = data()
        payload.update(x=[0, 1, 2, 3, 4, 5], y=[1, 2, 99, 4, 5.7, 6],
                       sigma=[0.1] * 6,
                       covariance=(0.006 * np.eye(6) + 0.004 * np.ones((6, 6))).tolist(),
                       include=[True, True, False, True, True, True])
        payload["policy"].update(min_gain=0.85, max_reduced_chi2=1.5)
        result = solve(payload)["result"]
        self.assertAlmostEqual(result["offset"], 0.991860465116279)
        self.assertAlmostEqual(result["gain"], 1.056976744186047)
        self.assertAlmostEqual(result["gain_se"], np.sqrt(0.006 / 17.2))
        self.assertAlmostEqual(result["chi2"], 56.027131782945736)
        self.assertEqual(result["dof"], 3)
        self.assertAlmostEqual(result["reduced_chi2"], result["chi2"] / 3)
        self.assertFalse(result["accepted"])
        self.assertEqual(result["reason"], "fit")
        payload["y"][2] = -1e12
        self.assertEqual(result, solve(payload)["result"])
        payload["policy"]["max_reduced_chi2"] = 20
        relaxed = solve(payload)["result"]
        self.assertTrue(relaxed["accepted"])
        self.assertEqual(relaxed["reason"], "ok")
        for field in set(result) - {"accepted", "reason"}:
            self.assertEqual(result[field], relaxed[field])

    def test_correlated_fit_and_noncontiguous_exclusion(self):
        rng = np.random.default_rng(217)
        for include in [[True] * 6, [True, False, True, True, False, True]]:
            factor = rng.normal(size=(6, 6))
            covariance = factor @ factor.T + np.eye(6) * 0.3
            payload = data()
            payload.update(x=[-2, -1, 0, 1, 2, 3],
                           y=[-2.9, -1.3, 1.4, 2.8, 5.3, 7.1],
                           sigma=[0.001] * 6, include=include,
                           covariance=covariance.tolist())
            selected = np.flatnonzero(include)
            x = np.asarray(payload["x"])[selected]
            y = np.asarray(payload["y"])[selected]
            c = covariance[np.ix_(selected, selected)]
            design = np.column_stack((np.ones(len(x)), x))
            precision = np.linalg.inv(c)
            parameter_covariance = np.linalg.inv(design.T @ precision @ design)
            beta = parameter_covariance @ design.T @ precision @ y
            residual = y - design @ beta
            original = copy.deepcopy(payload)
            result = solve(payload)["result"]
            self.assertEqual(payload, original)
            self.assertAlmostEqual(result["offset"], beta[0])
            self.assertAlmostEqual(result["gain"], beta[1])
            self.assertAlmostEqual(result["gain_se"], np.sqrt(parameter_covariance[1, 1]))
            self.assertAlmostEqual(result["chi2"], residual @ precision @ residual)
            self.assertEqual(result["dof"], len(x) - 2)
            payload["sigma"] = [1000] * 6
            self.assertEqual(result, solve(payload)["result"])
            json.dumps(result, allow_nan=False)

    def test_diagonal_covariance_matches_independent_errors(self):
        payload = data()
        payload.update(sigma=[0.1, 0.3, 0.5, 0.2], y=[1.1, 2.8, 5.4, 6.9])
        independent = solve(payload)["result"]
        payload["covariance"] = np.diag(np.square(payload["sigma"])).tolist()
        correlated = solve(payload)["result"]
        for field in ["offset", "gain", "gain_se", "gain_lower", "chi2", "reduced_chi2"]:
            self.assertAlmostEqual(correlated[field], independent[field])
        for field in ["accepted", "reason", "dof"]:
            self.assertEqual(correlated[field], independent[field])

    def test_correlated_known_uncertainty_and_gate_equality(self):
        payload = data()
        payload["covariance"] = (0.2 * np.ones((4, 4)) + 0.3 * np.eye(4)).tolist()
        exact = solve(payload)["result"]
        self.assertAlmostEqual(exact["gain_se"], np.sqrt(0.3 / 5))
        payload["y"] = [0, 4, 6, 6]
        noisy = solve(payload)["result"]
        self.assertEqual(exact["gain_se"], noisy["gain_se"])
        self.assertGreater(noisy["chi2"], 0)
        for gain_pass, fit_pass, reason in [(True, True, "ok"), (False, True, "gain"),
                                          (True, False, "fit"), (False, False, "gain+fit")]:
            payload["policy"]["min_gain"] = noisy["gain_lower"] + (0 if gain_pass else 1)
            payload["policy"]["max_reduced_chi2"] = noisy["reduced_chi2"] - (0 if fit_pass else 1)
            result = solve(payload)["result"]
            self.assertEqual(result["reason"], reason)
            self.assertEqual(result["accepted"], gain_pass and fit_pass)

    def test_exact_line_and_known_uncertainty(self):
        result = solve(data())["result"]
        self.assertEqual(result["offset"], 1.0)
        self.assertEqual(result["gain"], 2.0)
        self.assertAlmostEqual(result["gain_se"], np.sqrt(1 / 5))
        self.assertEqual(result["chi2"], 0.0)
        self.assertEqual(result["dof"], 2)
        self.assertTrue(result["accepted"])
        self.assertEqual(result["reason"], "ok")

    def test_heteroscedastic_against_matrix_solution(self):
        payload = data()
        payload["sigma"] = [0.1, 0.3, 0.5, 0.2]
        payload["y"] = [1.1, 2.8, 5.4, 6.9]
        design = np.column_stack((np.ones(4), payload["x"]))
        weights = np.diag(1 / np.square(payload["sigma"]))
        covariance = np.linalg.inv(design.T @ weights @ design)
        beta = covariance @ design.T @ weights @ payload["y"]
        residual = np.asarray(payload["y"]) - design @ beta
        result = solve(payload)["result"]
        self.assertAlmostEqual(result["offset"], beta[0])
        self.assertAlmostEqual(result["gain"], beta[1])
        self.assertAlmostEqual(result["gain_se"], np.sqrt(covariance[1, 1]))
        self.assertAlmostEqual(result["chi2"], residual @ weights @ residual)

    def test_exclusion(self):
        payload = data()
        payload["include"][-1] = False
        payload["y"][-1] = 1000000
        result = solve(payload)["result"]
        self.assertEqual(result["gain"], 2.0)
        self.assertEqual(result["offset"], 1.0)
        self.assertEqual(result["dof"], 1)
        self.assertAlmostEqual(result["gain_se"], np.sqrt(0.5))

    def test_covariance_not_scaled_by_fit(self):
        first = data()
        second = data()
        second["y"] = [0, 4, 6, 6]
        self.assertEqual(solve(first)["result"]["gain_se"],
                         solve(second)["result"]["gain_se"])
        self.assertGreater(solve(second)["result"]["chi2"], 0)

    def test_all_gate_reasons_and_equality(self):
        payload = data()
        payload["y"] = [0, 4, 6, 6]
        result = solve(payload)["result"]
        for gain_pass, fit_pass, reason in [(True, True, "ok"),
                                          (False, True, "gain"),
                                          (True, False, "fit"),
                                          (False, False, "gain+fit")]:
            payload["policy"]["min_gain"] = result["gain_lower"] + (0 if gain_pass else 1)
            payload["policy"]["max_reduced_chi2"] = result["reduced_chi2"] - (0 if fit_pass else 1)
            actual = solve(payload)["result"]
            self.assertEqual(actual["reason"], reason)
            self.assertEqual(actual["accepted"], gain_pass and fit_pass)

    def test_native_json_and_input_unchanged(self):
        payload = data()
        original = copy.deepcopy(payload)
        output = solve(payload)
        self.assertEqual(payload, original)
        json.dumps(output, allow_nan=False)
        self.assertEqual(set(output), {"schema_version", "result"})
        result = output["result"]
        self.assertEqual(set(result), {"offset", "gain", "gain_se", "gain_lower",
                                      "chi2", "dof", "reduced_chi2", "accepted", "reason"})
        self.assertIs(type(result["dof"]), int)
        self.assertIs(type(result["accepted"]), bool)
        for key in ["offset", "gain", "gain_se", "gain_lower", "chi2", "reduced_chi2"]:
            self.assertIs(type(result[key]), float)


if __name__ == "__main__":
    unittest.main()
