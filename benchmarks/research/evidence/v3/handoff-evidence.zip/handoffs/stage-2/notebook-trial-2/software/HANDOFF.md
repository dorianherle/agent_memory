# Inventory ledger: stage 2 handoff

## Status

Stage 2 is complete. All 16 local tests passed. The basic interface check passed.
The research task was completed before this task. No required work is open.
Read the next task before a change. Keep all rules below unless that task changes them.

## API and input

Export `solve(payload: dict) -> dict` from `solution.py`.
Use only the Python standard library and NumPy. This solver needs no imports.
Do not read files, print, use a network, or change the input in `solve`.
Return native JSON values and finite numbers.

Input has initial `stock`, `policy`, and ordered `events`.
Events have `request_id`, nondecreasing integer `time`, and `op`.
Request IDs can repeat. Keep equal-time events in their supplied order.
Events are structurally valid. Quantities and TTL values are positive integers when present.
Unknown operations and amendments with `allow_amend = false` are outside the valid contract.
The solver raises ValueError for unsupported operations.
Policy flags default to false when absent.

Output has exactly this form:

```python
{"schema_version": 1, "result": {
    "responses": [{"request_id": request_id, "code": code, "available": int}],
    "available": int,
    "purchased": int,
    "holds": [{"hold_id": hold_id, "qty": int, "expires_at": int_or_None}]
}}
```

Keep responses in event order. Sort final holds by hold_id.
Each response and hold has exactly the three fields above.
Purchased stock is the sum of successful buy quantities.

## State and event order

Each call starts with initial available stock, zero purchases, and empty containers.
Track active quantities, expiry times, used hold IDs, cached responses, and fingerprints.
Maintain this identity:

```text
available = initial stock - purchased - sum(active hold quantities)
```

Before EVERY event, when `policy.expire` is true, remove all active holds with
`expires_at <= event.time`. Restore their stock. Keep their IDs marked used.
Do this before replays and conflicts. Do not expire holds beyond the last event time.
With expiry disabled, ignore TTL and use `expires_at = None`.

After expiry, check the request ID cache. Fingerprint each event as:

```text
(op, hold_id or null, qty or null, ttl or null)
```

The implementation uses dictionary get for the three optional fields.
Missing and explicit null fields therefore have the same fingerprint value.
Time is excluded. Do not omit TTL from the fingerprint when expiry is disabled.

If the ID is cached and `policy.reject_key_conflict` is false, return the original
cached response regardless of changes to the event data.
If the flag is true, return that response only when the fingerprint matches.
A changed fingerprint returns `conflict` with current available stock.
Do not apply the changed operation. Do not replace the original response or fingerprint.
Exact replays return the original snapshot after expiry processing.
Thus their response stock can differ from current stock.
Cache every first response, including failures. Copy responses into the output list.

## Operations for first requests

1. `reserve`: Check used hold IDs first. If used, return `duplicate_hold`.
   Otherwise, if qty exceeds available stock, return `insufficient`.
   A failed reserve does not consume its hold ID.
   On success, add the hold, mark its ID used, subtract qty, and return `ok`.
   Set expiry to `event.time + event.ttl` when expiry is enabled.
2. `buy`: If qty exceeds available stock, return `insufficient` without change.
   Otherwise subtract qty, increase purchased stock by qty, and return `ok`.
3. `release`: If active, remove the hold and its expiry record, restore stock,
   and return `ok`. Otherwise return `missing_hold`.
   Keep the hold ID marked used.
4. `amend`: Enable only when `policy.allow_amend` is true.
   If the hold is absent, return `missing_hold`.
   Check new qty against `available + old_qty`.
   If it exceeds this amount, return `insufficient` and preserve the old hold exactly.
   On success, set `available += old_qty - new_qty`, replace only the quantity,
   and return `ok`. Preserve the original expires_at, including a null expiry.

Hold IDs cannot be reused after any successful reserve, including after release or expiry.
Successful amendment does not change used IDs or purchased stock.
Do not implement amendment with release followed by reserve.
An unsuccessful amendment must preserve the quantity and deadline.

## Work and checks

Earlier rules were recovered with `read_notes.py --all`.
The input already contains the supplied change and was left unchanged.
Added two optional policy flags, stored request fingerprints, a conflict branch,
and an atomic amendment branch. Prior expiry and ledger branches remain in place.

All 10 prior tests remain. They check cached successes and failures, stock snapshots,
hold-ID reuse and priority, failed-reserve ID availability, equal-time order,
expiry boundaries, expiry before repeated requests, release, simultaneous expiry,
no future expiry, ignored TTL, sorted holds, conservation, JSON keys, and input preservation.

Six new tests check the stage 2 sample; unsuccessful amendment preservation;
stock credit for successful growth; equal and smaller quantities; missing holds;
no-expiry amendments; conflicts for each fingerprint field; conflict before exact replay;
failed amendment response caching; expiry before amendment; and the disabled amendment guard.

Run these commands from this directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

The 16 tests passed. The interface check passed. It checks only the API.
The supplied sample returned:

```text
response codes = [ok, ok, insufficient, ok, conflict, ok]
response stock snapshots = [4, 1, 1, 0, 0, 0]
final available = 7
purchased = 0
holds = [{hold_id: H2, qty: 3, expires_at: 11}]
```

The final exact replay retains stock snapshot 0. Current stock is 7 because H1
expired first. The conflict did not replace the successful amendment cache entry.

## Limits and next action

No required work remains. Invalid input validation is outside the contract.
Expiry scans active holds before each event. No large-load performance test was required.
Do not refresh cached stock snapshots, cache only successes, reuse released or expired
hold IDs, sort events, skip expiry on repeated IDs, or change deadlines during amendment.
Only solution code, local tests, and this handoff note were changed.
No network, other agents, helper source, library source, graders, or references were used.
