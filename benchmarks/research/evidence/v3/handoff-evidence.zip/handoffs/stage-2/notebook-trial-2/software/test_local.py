import copy
import json
import unittest

from solution import solve


def run(events, stock=10):
    return solve({"stock": stock, "policy": {"expire": False,
                 "reject_key_conflict": False, "allow_amend": False},
                  "events": [dict(event, time=i) for i, event in enumerate(events)]})["result"]


class LedgerTests(unittest.TestCase):
    def test_stage_two_sample_atomic_failure_conflict_and_expiry(self):
        payload = {"stock": 10, "policy": {"expire": True, "allow_amend": True,
                    "reject_key_conflict": True}, "events": [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H1", "qty": 6, "ttl": 10},
            {"request_id": "b", "time": 1, "op": "reserve", "hold_id": "H2", "qty": 3, "ttl": 10},
            {"request_id": "c", "time": 2, "op": "amend", "hold_id": "H1", "qty": 8},
            {"request_id": "d", "time": 3, "op": "amend", "hold_id": "H1", "qty": 7},
            {"request_id": "d", "time": 4, "op": "amend", "hold_id": "H1", "qty": 2},
            {"request_id": "d", "time": 10, "op": "amend", "hold_id": "H1", "qty": 7}]}
        original = copy.deepcopy(payload)
        result = solve(payload)["result"]
        self.assertEqual(payload, original)
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "ok", "insufficient", "ok", "conflict", "ok"])
        self.assertEqual([r["available"] for r in result["responses"]], [4, 1, 1, 0, 0, 0])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["purchased"], 0)
        self.assertEqual(result["holds"], [{"hold_id": "H2", "qty": 3, "expires_at": 11}])
        self.assertEqual(10, result["available"] + sum(h["qty"] for h in result["holds"]))

    def test_amend_failure_preserves_quantity_and_deadline(self):
        payload = {"stock": 10, "policy": {"expire": True, "allow_amend": True},
                   "events": [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 6, "ttl": 5},
            {"request_id": "b", "time": 1, "op": "buy", "qty": 3},
            {"request_id": "c", "time": 2, "op": "amend", "hold_id": "H", "qty": 8}]}
        result = solve(payload)["result"]
        self.assertEqual(result["responses"][-1]["code"], "insufficient")
        self.assertEqual(result["available"], 1)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 6, "expires_at": 5}])
        payload["events"].append({"request_id": "d", "time": 3, "op": "amend", "hold_id": "H", "qty": 7})
        result = solve(payload)["result"]
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 7, "expires_at": 5}])

    def test_amend_shrink_equal_missing_and_no_expiry(self):
        events = [
            {"request_id": "a", "op": "reserve", "hold_id": "H", "qty": 8, "ttl": 1},
            {"request_id": "b", "op": "amend", "hold_id": "H", "qty": 8},
            {"request_id": "c", "op": "amend", "hold_id": "H", "qty": 2},
            {"request_id": "d", "op": "amend", "hold_id": "absent", "qty": 1}]
        result = solve({"stock": 10, "policy": {"allow_amend": True},
                        "events": [dict(e, time=i) for i, e in enumerate(events)]})["result"]
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "ok", "ok", "missing_hold"])
        self.assertEqual([r["available"] for r in result["responses"]], [2, 2, 8, 8])
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 2, "expires_at": None}])

    def test_each_fingerprint_field_conflicts_without_cache_replacement(self):
        first = {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 6, "ttl": 2}
        for key, value in [("op", "buy"), ("hold_id", "X"), ("qty", 5), ("ttl", 3)]:
            changed = dict(first, time=2)
            changed[key] = value
            result = solve({"stock": 10, "policy": {"expire": True, "reject_key_conflict": True},
                            "events": [first, changed, dict(first, time=3)]})["result"]
            self.assertEqual(result["responses"][1], {"request_id": "a", "code": "conflict", "available": 10})
            self.assertEqual(result["responses"][0], result["responses"][2])
            self.assertEqual(result["available"], 10)
            self.assertEqual(result["holds"], [])

    def test_failed_amend_cache_survives_conflict_and_exact_replay(self):
        events = [
            {"request_id": "a", "time": 0, "op": "amend", "hold_id": "H", "qty": 2},
            {"request_id": "b", "time": 1, "op": "reserve", "hold_id": "H", "qty": 3},
            {"request_id": "a", "time": 2, "op": "amend", "hold_id": "H", "qty": 1},
            {"request_id": "a", "time": 3, "op": "amend", "hold_id": "H", "qty": 2}]
        result = solve({"stock": 10, "policy": {"allow_amend": True, "reject_key_conflict": True}, "events": events})["result"]
        self.assertEqual([r["code"] for r in result["responses"]], ["missing_hold", "ok", "conflict", "missing_hold"])
        self.assertEqual([r["available"] for r in result["responses"]], [10, 7, 7, 10])
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 3, "expires_at": None}])

    def test_amend_after_expiry_is_missing_and_disabled_amend_is_unsupported(self):
        events = [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 6, "ttl": 2},
            {"request_id": "b", "time": 2, "op": "amend", "hold_id": "H", "qty": 2}]
        payload = {"stock": 10, "policy": {"expire": True, "allow_amend": True}, "events": events}
        result = solve(payload)["result"]
        self.assertEqual(result["responses"][-1]["code"], "missing_hold")
        self.assertEqual(result["available"], 10)
        payload["policy"]["allow_amend"] = False
        with self.assertRaises(ValueError):
            solve(payload)

    def test_expiry_before_repeat_and_cached_failure(self):
        payload = {"stock": 10, "policy": {"expire": True}, "events": [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 6, "ttl": 3},
            {"request_id": "b", "time": 1, "op": "buy", "qty": 5},
            {"request_id": "a", "time": 3, "op": "buy", "qty": 10},
            {"request_id": "b", "time": 4, "op": "buy", "qty": 1},
            {"request_id": "c", "time": 4, "op": "buy", "qty": 5}]}
        original = copy.deepcopy(payload)
        result = solve(payload)["result"]
        self.assertEqual(payload, original)
        self.assertEqual([r["available"] for r in result["responses"]], [4, 4, 4, 4, 5])
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "insufficient", "ok", "insufficient", "ok"])
        self.assertEqual(result["available"], 5)
        self.assertEqual(result["purchased"], 5)
        self.assertEqual(result["holds"], [])

    def test_expiry_boundary_and_used_id(self):
        result = solve({"stock": 10, "policy": {"expire": True}, "events": [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 10, "ttl": 2},
            {"request_id": "b", "time": 1, "op": "buy", "qty": 1},
            {"request_id": "c", "time": 2, "op": "release", "hold_id": "H"},
            {"request_id": "d", "time": 2, "op": "reserve", "hold_id": "H", "qty": 11, "ttl": 1}]})["result"]
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "insufficient", "missing_hold", "duplicate_hold"])
        self.assertEqual(result["available"], 10)

    def test_final_holds_no_future_expiry_and_multiple_expiry(self):
        events = [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "Z", "qty": 2, "ttl": 3},
            {"request_id": "b", "time": 0, "op": "reserve", "hold_id": "A", "qty": 3, "ttl": 3},
            {"request_id": "c", "time": 0, "op": "reserve", "hold_id": "M", "qty": 1, "ttl": 10}]
        payload = {"stock": 10, "policy": {"expire": True}, "events": events}
        result = solve(payload)["result"]
        self.assertEqual([h["hold_id"] for h in result["holds"]], ["A", "M", "Z"])
        self.assertEqual([h["expires_at"] for h in result["holds"]], [3, 10, 3])
        events.append({"request_id": "a", "time": 3, "op": "buy", "qty": 10})
        result = solve(payload)["result"]
        self.assertEqual(result["available"], 9)
        self.assertEqual(result["responses"][-1]["available"], 8)
        self.assertEqual(result["holds"], [{"hold_id": "M", "qty": 1, "expires_at": 10}])
        self.assertEqual(10, result["available"] + result["purchased"] + sum(h["qty"] for h in result["holds"]))

    def test_release_before_expiry(self):
        result = solve({"stock": 10, "policy": {"expire": True}, "events": [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 4, "ttl": 2},
            {"request_id": "b", "time": 1, "op": "release", "hold_id": "H"},
            {"request_id": "c", "time": 2, "op": "buy", "qty": 10}]})["result"]
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 10)

    def test_sample_cache_snapshot(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H1", "qty": 4, "ttl": 5},
            {"request_id": "b", "op": "buy", "qty": 3},
            {"request_id": "a", "op": "buy", "qty": 100},
            {"request_id": "c", "op": "release", "hold_id": "H1"},
        ])
        self.assertEqual([r["available"] for r in result["responses"]], [6, 3, 6, 7])
        self.assertEqual(result["responses"][0], result["responses"][2])
        self.assertEqual(result["purchased"], 3)
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [])

    def test_hold_ids_never_reused_and_duplicate_priority(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H", "qty": 10},
            {"request_id": "b", "op": "reserve", "hold_id": "H", "qty": 20},
            {"request_id": "c", "op": "release", "hold_id": "H"},
            {"request_id": "d", "op": "reserve", "hold_id": "H", "qty": 1},
            {"request_id": "e", "op": "release", "hold_id": "H"},
        ])
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "duplicate_hold", "ok", "duplicate_hold", "missing_hold"])
        self.assertEqual(result["available"], 10)

    def test_failed_reserve_does_not_use_hold_but_response_is_cached(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H", "qty": 11},
            {"request_id": "b", "op": "reserve", "hold_id": "H", "qty": 3},
            {"request_id": "a", "op": "release", "hold_id": "H"},
        ])
        self.assertEqual([r["code"] for r in result["responses"]], ["insufficient", "ok", "insufficient"])
        self.assertEqual(result["responses"][0], result["responses"][2])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 3, "expires_at": None}])

    def test_failed_buy_and_missing_release_cached(self):
        result = run([
            {"request_id": "a", "op": "buy", "qty": 11},
            {"request_id": "b", "op": "release", "hold_id": "H"},
            {"request_id": "c", "op": "reserve", "hold_id": "H", "qty": 2},
            {"request_id": "b", "op": "release", "hold_id": "H"},
            {"request_id": "a", "op": "buy", "qty": 1},
        ])
        self.assertEqual(result["available"], 8)
        self.assertEqual(result["purchased"], 0)
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["insufficient", "missing_hold", "ok", "missing_hold", "insufficient"])

    def test_ttl_ignored_sorted_holds_and_conservation(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "Z", "qty": 2, "ttl": 1},
            {"request_id": "b", "op": "reserve", "hold_id": "A", "qty": 3, "ttl": 1},
            {"request_id": "c", "op": "buy", "qty": 5},
        ])
        self.assertEqual(result["available"], 0)
        self.assertEqual([h["hold_id"] for h in result["holds"]], ["A", "Z"])
        self.assertTrue(all(h["expires_at"] is None for h in result["holds"]))
        self.assertEqual(10, result["available"] + result["purchased"] +
                         sum(h["qty"] for h in result["holds"]))

    def test_empty_and_native_json_input_unchanged(self):
        self.assertEqual(run([]), {"responses": [], "available": 10, "purchased": 0, "holds": []})
        payload = {"stock": 1, "policy": {}, "events": [
            {"request_id": "a", "time": 0, "op": "buy", "qty": 1}]}
        original = copy.deepcopy(payload)
        output = solve(payload)
        self.assertEqual(original, payload)
        json.dumps(output, allow_nan=False)
        self.assertEqual(set(output), {"schema_version", "result"})
        self.assertEqual(set(output["result"]), {"responses", "available", "purchased", "holds"})
        self.assertEqual(set(output["result"]["responses"][0]), {"request_id", "code", "available"})


if __name__ == "__main__":
    unittest.main()
