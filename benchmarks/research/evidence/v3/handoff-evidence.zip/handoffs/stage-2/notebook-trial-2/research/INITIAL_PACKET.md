Goal: # Linear sensor experiment, stage 0
Current steering [n-4]:
One measurement can now be excluded by a predeclared protocol. Select both rows AND columns of covariance with the same `include` mask. Use only included rows for degrees of freedom.
The changed sample has a known excluded record and a large residual on an included record. Keep every included record. Automatic clipping, robust regression, and rescaling uncertainty are rejected approaches: they change the experiment's scientific acceptance rule.
The policy now uses a stricter fit gate. Apply CHANGE2.json to the current input.json. Preserve prior
Latest handoff [n-3]:
# Sensor calibration: stage 1 handoff

## Status

Stage 1 is complete. All nine local tests passed. The basic interface check passed.
No required work is open. Read the next task before you make a change.
Keep the rules below unless the next task changes them.

## API and input

`solution.py` exports `solve(payload: dict) -> dict`.
Use only the Python standard library and NumPy. The solver uses NumPy.
It must not read files, print, use a network, or change its input.
Return native JSON values and finite numbers.

The input contains aligned arrays `x`, `y`