Goal: # Inventory reservation ledger, stage 0
Current steering [n-4]:
Enable atomic `amend` when `policy.allow_amend` is true. It replaces an active hold quantity with positive `qty`. Credit that hold's old quantity when checking stock. If the new quantity does not fit, return `insufficient` and preserve the old hold exactly. If absent, return `missing_hold`. On success keep the original expires_at.
A release-then-reserve implementation is rejected: an unsuccessful amendment must not lose the original hold or deadline.
When `policy.reject_key_conflict` is true, a repeated request ID is a replay only if its finger
Latest handoff [n-3]:
# Inventory ledger: stage 1 handoff

## Status

Stage 1 is complete. The software task was completed before the research task.
All 10 local tests passed. The basic interface check passed. No required work is open.
Read the next task before you make a change. Keep the rules below unless the next task changes them.

## API and input

`solution.py` exports `solve(payload: dict) -> dict`.
Use only the Python standard library and NumPy. This solver uses only the standard library.
The solver must not read files, print, use a network, or change its input.
Re