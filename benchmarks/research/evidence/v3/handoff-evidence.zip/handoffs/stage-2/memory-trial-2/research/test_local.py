import copy
import json
import unittest

import numpy as np

from solution import solve


def data():
    return {"x": [0, 1, 2, 3], "y": [1, 3, 5, 7],
            "sigma": [1, 1, 1, 1], "include": [True] * 4,
            "covariance": None,
            "policy": {"min_gain": 1, "max_reduced_chi2": 2,
                       "z_one_sided": 1.6448536269514722}}


class CalibrationTests(unittest.TestCase):
    def test_exact_line_and_known_uncertainty(self):
        result = solve(data())["result"]
        self.assertEqual(result["offset"], 1.0)
        self.assertEqual(result["gain"], 2.0)
        self.assertAlmostEqual(result["gain_se"], np.sqrt(1 / 5))
        self.assertEqual(result["chi2"], 0.0)
        self.assertEqual(result["dof"], 2)
        self.assertTrue(result["accepted"])
        self.assertEqual(result["reason"], "ok")

    def test_heteroscedastic_against_matrix_solution(self):
        payload = data()
        payload["sigma"] = [0.1, 0.3, 0.5, 0.2]
        payload["y"] = [1.1, 2.8, 5.4, 6.9]
        design = np.column_stack((np.ones(4), payload["x"]))
        weights = np.diag(1 / np.square(payload["sigma"]))
        covariance = np.linalg.inv(design.T @ weights @ design)
        beta = covariance @ design.T @ weights @ payload["y"]
        residual = np.asarray(payload["y"]) - design @ beta
        result = solve(payload)["result"]
        self.assertAlmostEqual(result["offset"], beta[0])
        self.assertAlmostEqual(result["gain"], beta[1])
        self.assertAlmostEqual(result["gain_se"], np.sqrt(covariance[1, 1]))
        self.assertAlmostEqual(result["chi2"], residual @ weights @ residual)

    def test_exclusion(self):
        payload = data()
        payload["include"][-1] = False
        payload["y"][-1] = 1000000
        result = solve(payload)["result"]
        self.assertEqual(result["gain"], 2.0)
        self.assertEqual(result["offset"], 1.0)
        self.assertEqual(result["dof"], 1)
        self.assertAlmostEqual(result["gain_se"], np.sqrt(0.5))

    def test_covariance_not_scaled_by_fit(self):
        first = data()
        second = data()
        second["y"] = [0, 4, 6, 6]
        self.assertEqual(solve(first)["result"]["gain_se"],
                         solve(second)["result"]["gain_se"])
        self.assertGreater(solve(second)["result"]["chi2"], 0)

    def test_all_gate_reasons_and_equality(self):
        payload = data()
        payload["y"] = [0, 4, 6, 6]
        result = solve(payload)["result"]
        for gain_pass, fit_pass, reason in [(True, True, "ok"),
                                          (False, True, "gain"),
                                          (True, False, "fit"),
                                          (False, False, "gain+fit")]:
            payload["policy"]["min_gain"] = result["gain_lower"] + (0 if gain_pass else 1)
            payload["policy"]["max_reduced_chi2"] = result["reduced_chi2"] - (0 if fit_pass else 1)
            actual = solve(payload)["result"]
            self.assertEqual(actual["reason"], reason)
            self.assertEqual(actual["accepted"], gain_pass and fit_pass)

    def test_native_json_and_input_unchanged(self):
        payload = data()
        original = copy.deepcopy(payload)
        output = solve(payload)
        self.assertEqual(payload, original)
        json.dumps(output, allow_nan=False)
        self.assertEqual(set(output), {"schema_version", "result"})
        result = output["result"]
        self.assertEqual(set(result), {"offset", "gain", "gain_se", "gain_lower",
                                      "chi2", "dof", "reduced_chi2", "accepted", "reason"})
        self.assertIs(type(result["dof"]), int)
        self.assertIs(type(result["accepted"]), bool)
        for key in ["offset", "gain", "gain_se", "gain_lower", "chi2", "reduced_chi2"]:
            self.assertIs(type(result[key]), float)


class CorrelatedTests(unittest.TestCase):
    def correlated_data(self):
        payload = data()
        payload["x"] = [-2, 0, 1, 4, 7]
        payload["y"] = [-3, 1.1, 3.4, 8.6, 15.2]
        payload["sigma"] = [0.001] * 5
        payload["include"] = [True] * 5
        factor = np.asarray([[1, 0, 0, 0, 0], [.3, .8, 0, 0, 0],
                             [.2, -.1, 1.2, 0, 0], [.4, .2, .3, .7, 0],
                             [.1, -.2, .4, .2, 1]])
        payload["covariance"] = (factor @ factor.T).tolist()
        return payload

    def check_matrix_reference(self, payload):
        include = np.asarray(payload["include"], dtype=bool)
        x = np.asarray(payload["x"])[include]
        y = np.asarray(payload["y"])[include]
        cov = np.asarray(payload["covariance"])[np.ix_(include, include)]
        design = np.column_stack((np.ones(x.size), x))
        precision = np.linalg.inv(cov)
        parameter_covariance = np.linalg.inv(design.T @ precision @ design)
        beta = parameter_covariance @ design.T @ precision @ y
        residual = y - design @ beta
        result = solve(payload)["result"]
        self.assertAlmostEqual(result["offset"], beta[0])
        self.assertAlmostEqual(result["gain"], beta[1])
        self.assertAlmostEqual(result["gain_se"], np.sqrt(parameter_covariance[1, 1]))
        self.assertAlmostEqual(result["chi2"], residual @ precision @ residual)
        self.assertEqual(result["dof"], x.size - 2)
        return result

    def test_gls_and_sigma_override(self):
        payload = self.correlated_data()
        result = self.check_matrix_reference(payload)
        payload["sigma"] = [100] * 5
        self.assertEqual(solve(payload)["result"], result)

    def test_exclusion_uses_covariance_submatrix(self):
        payload = self.correlated_data()
        payload["include"] = [True, False, True, True, True]
        payload["y"][1] = 1e9
        self.check_matrix_reference(payload)

    def test_diagonal_covariance_matches_independent_errors(self):
        payload = self.correlated_data()
        payload["covariance"] = None
        payload["sigma"] = [.2, .4, .8, .3, .5]
        independent = solve(payload)["result"]
        payload["covariance"] = np.diag(np.square(payload["sigma"])).tolist()
        correlated = self.check_matrix_reference(payload)
        for key in ["offset", "gain", "gain_se", "gain_lower", "chi2", "reduced_chi2"]:
            self.assertAlmostEqual(correlated[key], independent[key])
        self.assertEqual(correlated["reason"], independent["reason"])

    def test_known_covariance_unchanged_by_residual_and_input_preserved(self):
        payload = self.correlated_data()
        original = copy.deepcopy(payload)
        first = solve(payload)
        self.assertEqual(payload, original)
        json.dumps(first, allow_nan=False)
        payload["y"] = [4, -6, 8, -2, 13]
        second = solve(payload)
        self.assertEqual(first["result"]["gain_se"], second["result"]["gain_se"])
        self.assertNotEqual(first["result"]["chi2"], second["result"]["chi2"])

    def test_correlated_gate_reasons_and_equality(self):
        payload = self.correlated_data()
        result = solve(payload)["result"]
        for gain_pass, fit_pass, reason in [(True, True, "ok"), (False, True, "gain"),
                                           (True, False, "fit"), (False, False, "gain+fit")]:
            payload["policy"]["min_gain"] = result["gain_lower"] + (0 if gain_pass else 1)
            payload["policy"]["max_reduced_chi2"] = result["reduced_chi2"] - (0 if fit_pass else 1)
            actual = solve(payload)["result"]
            self.assertEqual(actual["reason"], reason)
            self.assertEqual(actual["accepted"], gain_pass and fit_pass)

    def test_stage_two_sample_keeps_included_large_residual(self):
        with open("input.json") as source:
            payload = json.load(source)
        result = self.check_matrix_reference(payload)
        self.assertEqual(result["dof"], 3)
        self.assertFalse(result["accepted"])
        self.assertEqual(result["reason"], "fit")
        self.assertGreater(result["reduced_chi2"], 1.5)
        self.assertGreaterEqual(result["gain_lower"], .85)
        payload["y"][2] = -1e12
        self.assertEqual(solve(payload)["result"], result)
        payload["y"][4] = 5.0
        repaired = solve(payload)["result"]
        self.assertEqual(repaired["gain_se"], result["gain_se"])
        self.assertLess(repaired["chi2"], result["chi2"])

    def test_mask_matches_explicitly_reduced_dataset(self):
        payload = self.correlated_data()
        payload["include"] = [True, False, True, True, True]
        result = solve(payload)
        indices = [i for i, included in enumerate(payload["include"]) if included]
        payload["covariance"] = [[payload["covariance"][i][j] for j in indices]
                                 for i in indices]
        for key in ("x", "y", "sigma"):
            payload[key] = [payload[key][i] for i in indices]
        payload["include"] = [True] * len(indices)
        self.assertEqual(solve(payload), result)


if __name__ == "__main__":
    unittest.main()
