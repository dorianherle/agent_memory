## Goal
[01231006] # Inventory reservation ledger, stage 0
Supported operations:
- `reserve`: require unused `hold_id`, positive integer `qty`, and enough available stock. Hold the quantity. Code is `ok`, `duplicate_hold`, or `insufficient`. … [more]

## Steering
[78b9f9a0] Enable atomic `amend` when `policy.allow_amend` is true. It replaces an active hold quantity with po…
Apply CHANGE2.json. Preserve all prior behavior and output fields. Update HANDOFF.md after your checks. … [more]

## Handoff
[6a2b7070] # Inventory ledger: stage 1 handoff
"available": int,
}}
After the expiry step, check the request cache. A repeated request ID returns its exact original response value. Ignore changed payload fields on a repeat. Do not apply its operation again. Do not change its stock snapshot to the current stock. Cache every first response, including failures. … [more]

## Related
[e4dbf293] # Inventory ledger: stage 0 handoff
```python
],
2. `buy`: If `qty > available`, return `insufficient` with no state change. Otherwise, subtract its quantity from available stock, add that quantity to purchased stock, and return `ok`. … [more]