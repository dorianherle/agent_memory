## Goal
[eeac5e48] # Linear sensor experiment, stage 0
- Use only rows for which `include` is true. At this stage all rows are included.
- Use the supplied measurement uncertainty. Do not multiply parameter covariance by reduced chi-square. … [more]

## Steering
[d4e24767] One measurement can now be excluded by a predeclared protocol. Select both rows AND columns of covar… … [more]

## Handoff
[b4f77321] # Sensor calibration: stage 1 handoff
}}
Do not add parameter covariance to the output. The covariance field is an input field.
For included rows:
Do not multiply parameter covariance or gain_se by residual error or reduced chi-square. Known measurement uncertainty determines the standard error in both modes.
The following rules apply in both modes: … [more]

## Related
[697ff9fc] # Sensor calibration: stage 0 handoff
```python
The implementation selects included rows, computes centered weighted sums, applies both policy gates, and converts all returned numerical scalars to native Python types. All state is local to one call. … [more]