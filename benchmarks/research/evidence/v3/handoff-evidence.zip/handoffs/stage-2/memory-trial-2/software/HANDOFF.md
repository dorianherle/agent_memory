# Inventory ledger: stage 2 handoff

Stage 2 is complete. All 16 local tests passed. The basic interface check passed. No work remains open.

## Source and scope

Read TASK.md, STEERING.md, INITIAL_PACKET.md, input.json, CHANGE.json, and ../API.md. Recovered all prior rules with the supplied `read_notes.py --all`. The input already contains the change. Do not apply it a second time. Only solution.py, test_local.py, and this note were changed. No network, other agents, reference code, hidden tests, helper source, or library source were used.

## API and valid inputs

Export `solve(payload: dict) -> dict`. Use only the standard library and NumPy. This solver uses only the standard library. The function must not read files, print, use a network, or change its input. Return finite native JSON values.

Input has stock, policy, and events. Each event has request_id, nondecreasing integer time, and op. Keep input order, including equal-time events. Request IDs can repeat. Quantities and TTL values are positive integers when present. Events are structurally valid. Unknown operations are outside scope.

Return `{"schema_version": 1, "result": {...}}`. Result keys are exactly responses, available, purchased, and holds. Each response has exactly request_id, code, and available. Keep responses in event order. Each hold has exactly hold_id, qty, and expires_at. Sort final holds by hold_id. Stock values and quantities are integers. expires_at is an integer or null. purchased is the total quantity of successful buys.

## State and processing order

Each call starts with available=stock, purchased=0, empty holds, empty expirations, empty used_hold_ids, empty cached responses, and empty fingerprints. All state is local to the call. The stock identity is:

```text
available + purchased + sum(active hold quantities) = initial stock
```

Before EVERY event, if policy.expire is true, remove every hold with expires_at<=event.time. Restore its quantity to available. Keep its ID marked used. Do this before the cache check, including for repeated requests and conflicts. Do not run expiry after the final event. Release removes its expiry entry to prevent a second stock restoration.

Missing policy flags default to false. When expire is false, time and TTL do not cause expiry. Return expires_at=null.

## Request cache and conflicts

Compute the fingerprint as the ordered tuple `(op, hold_id or null, qty or null, ttl or null)`. Missing fields give null. Time is excluded. Fields in this tuple count even if the operation does not use them.

After expiry, check the request cache. If a request ID is cached and reject_key_conflict is false, return the original response even when the payload differs. If reject_key_conflict is true, return the original response only when fingerprints match. A changed fingerprint returns conflict with current available stock. Do not apply its operation. Do not replace the original cached response or fingerprint. A later exact replay must still return the original response and stock snapshot.

Cache every first response, including failures, with its original fingerprint. Its available field is the stock after that event's expiry and operation. Copy response dictionaries into the output list. An exact replay can return an old stock snapshot while final available reflects expiry.

## Operations

For a first request:

1. reserve: Check used hold IDs first. Return duplicate_hold if the ID was used by a successful reserve. Otherwise return insufficient if qty>available. Otherwise subtract qty, add the active hold, mark the ID used, and return ok. If expiry is enabled, set expires_at=time+ttl. A failed reserve does not consume its ID. A successful reserve consumes its ID permanently. Release and expiry do not permit reuse.
2. buy: Return insufficient if qty>available. Otherwise subtract qty, add qty to purchased, and return ok.
3. release: If active, remove the hold, restore its quantity, remove its expiry entry, and return ok. Otherwise return missing_hold. Keep its used ID.
4. amend: Enable only when allow_amend is true. If the hold is absent, return missing_hold. Otherwise check qty<=available+old_hold_qty. If this fails, return insufficient and preserve quantity, available stock, and deadline exactly. If it passes, set available=available+old_hold_qty-qty and replace the hold quantity. Return ok. Keep the original expires_at. An event TTL does not reset the deadline. Do not implement amend as release followed by reserve.

Unknown operations and amend when disabled are outside the valid operation contract. The solver raises ValueError in that case. Prior stages did the same for unsupported operations.

## Changes and checks

Added flag-controlled atomic amendment and request fingerprint checks. Prior reserve, buy, release, expiry, and legacy replay behavior remain in force. Conflict responses do not enter the original request cache.

Run from this software directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both passed. All ten prior tests still pass. They cover failed request caching, legacy changed-payload replay, old stock snapshots, hold-ID rules and priority, TTL disabled, exact-stock buying, output fields, JSON, input preservation, deadline equality, expiry before replay, release cleanup, multiple expiry, and no expiry after the final event.

Six added tests cover the changed sample; failed amendment preservation; amendment after expiry; full-stock amendment with credit for the old hold; decrease in quantity; preserved deadline despite supplied TTL; amendment with expiry disabled; each fingerprint field; conflict after expiry with current stock; original cache preservation; cached failed amendments; legacy replay with conflict rejection disabled; and stock conservation.

The sample response codes are [ok, ok, insufficient, ok, conflict, ok]. Stock snapshots are [4,1,1,0,0,0]. Final available=7 and purchased=0. The only active hold is H2 with qty=3 and expires_at=11. H1 expires at time 10 before the final exact replay. That replay returns its original available=0 snapshot. It does not restore H1.

## Limits and next action

No work remains open. Invalid-input validation is outside the contract. Extreme event-list sizes were not benchmarked. Expiry scans active holds before each event. The basic interface check alone does not prove state correctness. Preserve all rules above. Read the next task and run all tests after each later change.
