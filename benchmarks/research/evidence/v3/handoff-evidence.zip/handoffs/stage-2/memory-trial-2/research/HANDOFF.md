# Sensor calibration: stage 2 handoff

Stage 2 is complete. All 13 local tests passed. The basic interface check passed. No work remains open.

## Source and scope

Read TASK.md, STEERING.md, INITIAL_PACKET.md, input.json, CHANGE.json, and ../API.md. Recovered all prior rules with the supplied `read_notes.py --all`. The input already contains the stage 2 change. Do not apply the change a second time. Only solution.py, test_local.py, and this note were changed. No helper source, library source, network, other agents, reference code, or hidden tests were used.

## API and valid inputs

Export `solve(payload: dict) -> dict`. Use the standard library and NumPy only. The function must not read files, print, use a network, or change its input. Return finite native JSON values.

Input arrays x, y, sigma, and include have aligned rows. Model: `y = offset + gain*x + error`. Valid inputs have finite data, at least three included rows, positive sigma, and full-rank design. A supplied covariance is symmetric positive definite. The policy contains min_gain, max_reduced_chi2, and z_one_sided.

Return `{"schema_version": 1, "result": {...}}`. Result keys are exactly offset, gain, gain_se, gain_lower, chi2, dof, reduced_chi2, accepted, and reason. All numerical fields are Python floats except integer dof. accepted is Boolean. reason is ok, gain, fit, or gain+fit. Do not return parameter covariance.

## Fit and uncertainty rules

Use only rows with include=true. Keep every included row, including rows with large residuals. Do not use automatic clipping or robust regression. Select the same rows AND columns of the supplied covariance. Use the selected covariance itself, not selected rows of the full precision matrix.

When covariance is null or absent, use independent weighted least squares with an intercept. Let `w=1/sigma^2`, `W=sum(w)`, `x_bar=sum(w*x)/W`, and `y_bar=sum(w*y)/W`. Compute `Sxx=sum(w*(x-x_bar)^2)` and `Sxy=sum(w*(x-x_bar)*(y-y_bar))`. Then gain=Sxy/Sxx, offset=y_bar-gain*x_bar, and gain_se=sqrt(1/Sxx). Compute chi2=sum((residual/sigma)^2).

When covariance is a matrix, it overrides sigma. Let X have columns [1,x] and C be the selected covariance. Generalized least squares gives beta=(X.T C^-1 X)^-1 X.T C^-1 y. Parameter covariance is (X.T C^-1 X)^-1. gain_se is the square root of its gain variance. chi2=residual.T C^-1 residual.

The implementation uses Cholesky whitening and reduced QR. With C=L L.T, solve L A=X and L b=y. Factor A=Q R. Solve R beta=Q.T b. Parameter covariance is R^-1 R^-T. Compute chi2 from the squared norm of L^-1 residual. This avoids explicit inversion of C.

Use known measurement uncertainty in both modes. Do not scale parameter covariance or gain_se by residual error or reduced chi-square. Do not replace the supplied one-sided z value with a two-sided or Student t value.

## Acceptance rules

Compute dof=number of included rows-2. Compute reduced_chi2=chi2/dof and gain_lower=gain-z_one_sided*gain_se. The gain gate passes when gain_lower>=min_gain. The fit gate passes when reduced_chi2<=max_reduced_chi2. Equality passes. Accept only if both gates pass. Return ok if both pass, gain if only gain fails, fit if only fit fails, and gain+fit if both fail.

## Changes and checks

The prior solver already implements the new mask and gate rules. Added a comment to make the exclusion rule clear. Added two tests. They check the stage 2 fit rejection, removal of only the declared excluded row, preservation of known uncertainty, and agreement with a dataset reduced explicitly on both covariance axes. All 11 prior tests still pass. They cover independent and correlated fits, dense covariance, sigma override, diagonal agreement, all reasons, equality, unscaled uncertainty, input preservation, JSON types, and exact fields.

Run from this research directory:

```text
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_local
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

Both passed. The sample returns offset=0.991860465116278, gain=1.0569767441860467, gain_se=0.01867718419094071, gain_lower=1.0262555100283373, chi2=56.02713178294577, dof=3, reduced_chi2=18.67571059431526, accepted=false, reason=fit. This rejected result is required. Do not remove the included large residual to make it pass.

## Limits and next action

Invalid-input handling, extreme floating-point ranges, and nearly singular designs are outside the checked scope. The basic interface check alone does not prove correctness. Preserve all rules above in later stages. Read the next task and run all tests after any change.
