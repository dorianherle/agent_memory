import copy
import json
import unittest

from solution import solve


def run(events, stock=10):
    return solve({"stock": stock, "policy": {"expire": False,
                 "reject_key_conflict": False, "allow_amend": False},
                  "events": [dict(event, time=i) for i, event in enumerate(events)]})["result"]


class LedgerTests(unittest.TestCase):
    def test_sample_cache_snapshot(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H1", "qty": 4, "ttl": 5},
            {"request_id": "b", "op": "buy", "qty": 3},
            {"request_id": "a", "op": "buy", "qty": 100},
            {"request_id": "c", "op": "release", "hold_id": "H1"},
        ])
        self.assertEqual([r["available"] for r in result["responses"]], [6, 3, 6, 7])
        self.assertEqual(result["responses"][0], result["responses"][2])
        self.assertEqual(result["purchased"], 3)
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [])

    def test_hold_ids_never_reused_and_duplicate_priority(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H", "qty": 10},
            {"request_id": "b", "op": "reserve", "hold_id": "H", "qty": 20},
            {"request_id": "c", "op": "release", "hold_id": "H"},
            {"request_id": "d", "op": "reserve", "hold_id": "H", "qty": 1},
            {"request_id": "e", "op": "release", "hold_id": "H"},
        ])
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "duplicate_hold", "ok", "duplicate_hold", "missing_hold"])
        self.assertEqual(result["available"], 10)

    def test_failed_reserve_does_not_use_hold_but_response_is_cached(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "H", "qty": 11},
            {"request_id": "b", "op": "reserve", "hold_id": "H", "qty": 3},
            {"request_id": "a", "op": "release", "hold_id": "H"},
        ])
        self.assertEqual([r["code"] for r in result["responses"]], ["insufficient", "ok", "insufficient"])
        self.assertEqual(result["responses"][0], result["responses"][2])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 3, "expires_at": None}])

    def test_failed_buy_and_missing_release_cached(self):
        result = run([
            {"request_id": "a", "op": "buy", "qty": 11},
            {"request_id": "b", "op": "release", "hold_id": "H"},
            {"request_id": "c", "op": "reserve", "hold_id": "H", "qty": 2},
            {"request_id": "b", "op": "release", "hold_id": "H"},
            {"request_id": "a", "op": "buy", "qty": 1},
        ])
        self.assertEqual(result["available"], 8)
        self.assertEqual(result["purchased"], 0)
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["insufficient", "missing_hold", "ok", "missing_hold", "insufficient"])

    def test_ttl_ignored_sorted_holds_and_conservation(self):
        result = run([
            {"request_id": "a", "op": "reserve", "hold_id": "Z", "qty": 2, "ttl": 1},
            {"request_id": "b", "op": "reserve", "hold_id": "A", "qty": 3, "ttl": 1},
            {"request_id": "c", "op": "buy", "qty": 5},
        ])
        self.assertEqual(result["available"], 0)
        self.assertEqual([h["hold_id"] for h in result["holds"]], ["A", "Z"])
        self.assertTrue(all(h["expires_at"] is None for h in result["holds"]))
        self.assertEqual(10, result["available"] + result["purchased"] +
                         sum(h["qty"] for h in result["holds"]))

    def test_empty_and_native_json_input_unchanged(self):
        self.assertEqual(run([]), {"responses": [], "available": 10, "purchased": 0, "holds": []})
        payload = {"stock": 1, "policy": {}, "events": [
            {"request_id": "a", "time": 0, "op": "buy", "qty": 1}]}
        original = copy.deepcopy(payload)
        output = solve(payload)
        self.assertEqual(original, payload)
        json.dumps(output, allow_nan=False)
        self.assertEqual(set(output), {"schema_version", "result"})
        self.assertEqual(set(output["result"]), {"responses", "available", "purchased", "holds"})
        self.assertEqual(set(output["result"]["responses"][0]), {"request_id", "code", "available"})


class ExpiryTests(unittest.TestCase):
    def run_events(self, events):
        return solve({"stock": 10, "policy": {"expire": True},
                      "events": events})["result"]

    def test_expiry_before_repeated_request_and_failed_cache(self):
        result = self.run_events([
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 6, "ttl": 3},
            {"request_id": "b", "time": 1, "op": "buy", "qty": 5},
            {"request_id": "a", "time": 3, "op": "buy", "qty": 10},
            {"request_id": "b", "time": 4, "op": "buy", "qty": 5},
            {"request_id": "c", "time": 4, "op": "buy", "qty": 5},
        ])
        self.assertEqual([r["available"] for r in result["responses"]], [4, 4, 4, 4, 5])
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "insufficient", "ok", "insufficient", "ok"])
        self.assertEqual(result["available"], 5)
        self.assertEqual(result["purchased"], 5)
        self.assertEqual(result["holds"], [])

    def test_expired_ids_stay_used_and_expiry_at_boundary(self):
        result = self.run_events([
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 10, "ttl": 2},
            {"request_id": "b", "time": 2, "op": "release", "hold_id": "H"},
            {"request_id": "c", "time": 2, "op": "reserve", "hold_id": "H", "qty": 11, "ttl": 3},
        ])
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "missing_hold", "duplicate_hold"])
        self.assertEqual(result["available"], 10)

    def test_no_expiry_after_last_event_and_sorted_active_holds(self):
        result = self.run_events([
            {"request_id": "a", "time": 1, "op": "reserve", "hold_id": "Z", "qty": 2, "ttl": 5},
            {"request_id": "b", "time": 1, "op": "reserve", "hold_id": "A", "qty": 3, "ttl": 2},
        ])
        self.assertEqual(result["holds"], [{"hold_id": "A", "qty": 3, "expires_at": 3},
                                           {"hold_id": "Z", "qty": 2, "expires_at": 6}])
        self.assertEqual(result["available"], 5)

    def test_release_removes_expiry_and_multiple_holds_expire(self):
        result = self.run_events([
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "A", "qty": 2, "ttl": 2},
            {"request_id": "b", "time": 0, "op": "reserve", "hold_id": "B", "qty": 3, "ttl": 2},
            {"request_id": "c", "time": 0, "op": "reserve", "hold_id": "C", "qty": 1, "ttl": 2},
            {"request_id": "d", "time": 1, "op": "release", "hold_id": "A"},
            {"request_id": "e", "time": 3, "op": "buy", "qty": 10},
        ])
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 10)
        self.assertEqual(result["holds"], [])


class AmendmentTests(unittest.TestCase):
    def ledger(self, events, expire=True, reject=True):
        payload = {"stock": 10, "policy": {"expire": expire,
                   "allow_amend": True, "reject_key_conflict": reject},
                   "events": events}
        original = copy.deepcopy(payload)
        result = solve(payload)["result"]
        self.assertEqual(payload, original)
        json.dumps(result, allow_nan=False)
        self.assertEqual(10, result["available"] + result["purchased"] +
                         sum(h["qty"] for h in result["holds"]))
        return result

    def test_sample_amendment_conflict_and_expiry_replay(self):
        with open("input.json") as source:
            payload = json.load(source)
        result = self.ledger(payload["events"])
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "ok", "insufficient", "ok", "conflict", "ok"])
        self.assertEqual([r["available"] for r in result["responses"]], [4, 1, 1, 0, 0, 0])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [{"hold_id": "H2", "qty": 3, "expires_at": 11}])

    def test_failed_amend_preserves_quantity_and_deadline(self):
        events = [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 6, "ttl": 5},
            {"request_id": "b", "time": 1, "op": "buy", "qty": 3},
            {"request_id": "c", "time": 2, "op": "amend", "hold_id": "H", "qty": 8},
        ]
        result = self.ledger(events)
        self.assertEqual(result["responses"][-1]["code"], "insufficient")
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 6, "expires_at": 5}])
        events.append({"request_id": "d", "time": 5, "op": "amend", "hold_id": "H", "qty": 1})
        result = self.ledger(events)
        self.assertEqual(result["responses"][-1]["code"], "missing_hold")
        self.assertEqual(result["available"], 7)

    def test_success_credits_old_quantity_and_keeps_deadline(self):
        events = [
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 6, "ttl": 5},
            {"request_id": "b", "time": 1, "op": "amend", "hold_id": "H", "qty": 10, "ttl": 100},
            {"request_id": "c", "time": 2, "op": "amend", "hold_id": "H", "qty": 2},
        ]
        result = self.ledger(events)
        self.assertEqual([r["available"] for r in result["responses"]], [4, 0, 8])
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 2, "expires_at": 5}])
        result = self.ledger(events, expire=False)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 2, "expires_at": None}])

    def test_each_fingerprint_field_and_original_cache_preserved(self):
        first = {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 3, "ttl": 5}
        for field, value in [("op", "release"), ("hold_id", "J"), ("qty", 2), ("ttl", 6)]:
            conflict = dict(first, time=5)
            conflict[field] = value
            result = self.ledger([first, conflict, dict(first, time=6)])
            self.assertEqual([r["code"] for r in result["responses"]], ["ok", "conflict", "ok"])
            self.assertEqual([r["available"] for r in result["responses"]], [7, 10, 7])
            self.assertEqual(result["available"], 10)
            self.assertEqual(result["holds"], [])

    def test_failed_requests_are_cached_with_fingerprint(self):
        first = {"request_id": "a", "time": 0, "op": "amend", "hold_id": "H", "qty": 2}
        result = self.ledger([
            first,
            {"request_id": "b", "time": 1, "op": "reserve", "hold_id": "H", "qty": 4, "ttl": 10},
            dict(first, time=2, qty=3), dict(first, time=3),
        ])
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["missing_hold", "ok", "conflict", "missing_hold"])
        self.assertEqual([r["available"] for r in result["responses"]], [10, 6, 6, 10])
        self.assertEqual(result["holds"][0]["qty"], 4)

    def test_conflict_flag_false_retains_legacy_replay(self):
        result = self.ledger([
            {"request_id": "a", "time": 0, "op": "reserve", "hold_id": "H", "qty": 4, "ttl": 10},
            {"request_id": "a", "time": 1, "op": "amend", "hold_id": "H", "qty": 8},
        ], reject=False)
        self.assertEqual(result["responses"][0], result["responses"][1])
        self.assertEqual(result["holds"][0]["qty"], 4)


if __name__ == "__main__":
    unittest.main()
