"""Replay holds, expiry, atomic amendments, and cached request responses."""


def solve(payload: dict) -> dict:
    available = payload["stock"]
    purchased = 0
    policy = payload.get("policy", {})
    expire = policy.get("expire", False)
    allow_amend = policy.get("allow_amend", False)
    reject_key_conflict = policy.get("reject_key_conflict", False)
    expirations = {}
    holds = {}
    used_hold_ids = set()
    cached = {}
    fingerprints = {}
    responses = []
    for event in payload["events"]:
        if expire:
            due = [hold_id for hold_id, expires_at in expirations.items()
                   if expires_at <= event["time"]]
            for hold_id in due:
                available += holds.pop(hold_id)
                del expirations[hold_id]
        request_id = event["request_id"]
        fingerprint = tuple(event.get(key) for key in ("op", "hold_id", "qty", "ttl"))
        if request_id in cached:
            if reject_key_conflict and fingerprint != fingerprints[request_id]:
                responses.append({"request_id": request_id, "code": "conflict",
                                  "available": available})
            else:
                responses.append(dict(cached[request_id]))
            continue
        op = event["op"]
        if op == "reserve":
            hold_id = event["hold_id"]
            qty = event["qty"]
            if hold_id in used_hold_ids:
                code = "duplicate_hold"
            elif qty > available:
                code = "insufficient"
            else:
                holds[hold_id] = qty
                if expire:
                    expirations[hold_id] = event["time"] + event["ttl"]
                used_hold_ids.add(hold_id)
                available -= qty
                code = "ok"
        elif op == "amend" and allow_amend:
            hold_id = event["hold_id"]
            qty = event["qty"]
            if hold_id not in holds:
                code = "missing_hold"
            elif qty > available + holds[hold_id]:
                code = "insufficient"
            else:
                # Change stock and quantity together. Keep the original deadline.
                available += holds[hold_id] - qty
                holds[hold_id] = qty
                code = "ok"
        elif op == "buy":
            qty = event["qty"]
            if qty > available:
                code = "insufficient"
            else:
                available -= qty
                purchased += qty
                code = "ok"
        elif op == "release":
            hold_id = event["hold_id"]
            if hold_id in holds:
                available += holds.pop(hold_id)
                expirations.pop(hold_id, None)
                code = "ok"
            else:
                code = "missing_hold"
        else:
            raise ValueError("Unsupported operation")
        response = {"request_id": request_id, "code": code, "available": available}
        cached[request_id] = response
        fingerprints[request_id] = fingerprint
        responses.append(dict(response))
    return {"schema_version": 1, "result": {
        "responses": responses,
        "available": available,
        "purchased": purchased,
        "holds": [{"hold_id": hold_id, "qty": holds[hold_id], "expires_at": expirations.get(hold_id)}
                  for hold_id in sorted(holds)],
    }}
