## Goal
[ac0c5464] # Linear sensor experiment, stage 0
- Use only rows for which `include` is true. At this stage all rows are included.
- Use the supplied measurement uncertainty. Do not multiply parameter covariance by reduced chi-square. … [more]

## Steering
[bba0bfa3] One measurement can now be excluded by a predeclared protocol. Select both rows AND columns of covar… … [more]

## Handoff
[a5a8f1fe] # Sensor fit: stage 1 handoff
## API and input
or change its input. All output values are native JSON values and finite.
Input arrays are `x`, `y`, `sigma`, and `include`. Select only included rows.
Do not scale parameter covariance by residual error or reduced chi-square.
Do not use unweighted regression, remove the intercept, rescale uncertainty … [more]

## Related
[1ebfa2e5] # Sensor fit: stage 0 handoff
Do not add an output `covariance` field. The task reserves the input field.
Do not multiply parameter covariance by reduced chi-square. The measurement
Do not infer later covariance behavior from the reserved field alone. … [more]