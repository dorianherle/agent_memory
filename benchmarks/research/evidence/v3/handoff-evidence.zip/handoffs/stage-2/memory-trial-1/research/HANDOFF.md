# Sensor fit: stage 2 handoff

## Status

Stage 2 is complete. All 12 local tests and the basic interface check passed.
Earlier rules were recovered with `read_notes.py --all`. The supplied input
already contained the change. Only solution.py, tests, and this file changed.
The previous implementation already selected both covariance axes. This
change makes one selected-index array explicit for all data and covariance.
New tests verify the excluded record, the large included residual, and the
stricter fit limit. The supplied experiment remains rejected.

## API and input

Export `solve(payload: dict) -> dict`. Use only the standard library and
NumPy. In solve, do not read files, print, use a network, or change the input.
Return finite native JSON values. No state persists between calls.
Output is `{"schema_version": 1, "result": {...}}`.

Input arrays are x, y, sigma, and include. The model is
`y = offset + gain*x + error`, with an intercept. Valid inputs have at least
three included observations, a full-rank design, positive sigma, and finite
data. Policy supplies min_gain, max_reduced_chi2, and z_one_sided. Use the
supplied values. Do not insert fixed confidence or fit limits.

The result has exactly nine fields: offset, gain, gain_se, gain_lower, chi2,
dof, reduced_chi2, accepted, and reason. Numerical values are floats, except
integer dof. Accepted is Boolean. Reason is ok, gain, fit, or gain+fit.
Do not add an output covariance field.

## Selection and scientific rules

Select only rows whose include flag is true. This is a declared experiment
protocol. Keep every included record, regardless of residual size. Select
both rows and columns of covariance with the same indices before the fit.
Use the selected principal covariance submatrix, not the selected submatrix
of the full inverse covariance. Excluded data and their covariance rows and
columns have no effect. Degrees of freedom use the included count only.

If covariance is null or absent, sigma gives known independent measurement
standard deviations. Use weighted least squares with weights 1/sigma**2.
Sigma is not an estimate from residuals. If covariance is a matrix, it gives
the full covariance of y and overrides sigma. The supplied matrix is
symmetric positive definite. Use generalized least squares.

For selected data, let X have columns one and x. For independent errors,
C is diag(sigma**2). For correlated errors, C is the selected covariance.

```text
beta = [offset, gain]
beta_hat = inverse(X.T C^-1 X) X.T C^-1 y
Cov(beta_hat) = inverse(X.T C^-1 X)
gain_se = sqrt(Cov(beta_hat)[1, 1])
residual = y - X beta_hat
chi2 = residual.T C^-1 residual
dof = number of included observations - 2
reduced_chi2 = chi2 / dof
gain_lower = gain - policy.z_one_sided * gain_se
```

Do not multiply parameter covariance by residual variance or reduced
chi-square. Do not clip included measurements, use robust regression,
remove the intercept, use unweighted regression, or replace the one-sided
gain limit with a two-sided limit. These methods change the experiment rule.

The gain test passes when gain_lower >= min_gain. The fit test passes when
reduced_chi2 <= max_reduced_chi2. Equality passes. Both tests must pass for
acceptance. Use strict failure comparisons without an added tolerance.

| Gain test | Fit test | accepted | reason |
|---|---|---|---|
| Pass | Pass | true | ok |
| Fail | Pass | false | gain |
| Pass | Fail | false | fit |
| Fail | Fail | false | gain+fit |

## Numerical method

The code centers and scales x, then uses reduced QR. It does not explicitly
invert the normal matrix. For independent errors, set s = min(sigma),
a = s/sigma, w = a**2, c = sum(w*x)/sum(w), and h = max(abs(x-c)).
The full-rank assumption gives a positive h. Define D = [1, (x-c)/h].
Factor a*D = Q R and solve R theta = Q.T (a*y). Gain is theta[1]/h.
Offset is theta[0] - gain*c. Gain SE is s*norm(row_1(R^-1))/h.

For correlated errors, use c = mean(x) and the same h and D definition.
Factor C = L L.T with Cholesky. Factor solve(L,D) = Q R and solve
R theta = Q.T solve(L,y). Gain SE is norm(row_1(R^-1))/h. The known
covariance already sets the uncertainty scale.

Residuals use y - D theta to reduce cancellation. Chi-square is the squared
norm of residual/sigma for independent errors, or solve(L,residual) for
correlated errors. Centering and scaling do not change the required fit.

## Checks and results

From this directory, run:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All 12 tests passed. Nine earlier tests cover exact-line gain uncertainty,
sigma scaling, uncertainty independent of residual size, excluded records,
all reason codes, equality at limits, 40 deterministic random weighted fits
against scalar formulas, 30 deterministic random covariance fits against
normal-equation formulas, covariance selection, sigma override, diagonal
covariance equivalence, covariance scaling, exact fields and native types,
finite JSON values, and input preservation.

Three new tests cover the changed experiment against independent analytic
formulas, retention of the large included residual, included-only degrees
of freedom, ignored excluded x and y, selection of both covariance axes,
equivalence to a compact input, and fit-limit changes that affect acceptance
without changing the numerical fit. For the supplied compound-symmetric
covariance, the analytic comparison uses slope from centered sums,
gain_se = sqrt(0.006 / sum((x-mean(x))**2)), and chi2 = residual SSE/0.006.
As a test comparison only, excluding the large residual gives acceptance.
The implementation does not perform that exclusion.

The supplied input returns approximately:

```text
offset = 0.9918604651162783
gain = 1.0569767441860465
gain_se = 0.01867718419094071
gain_lower = 1.026255510028337
chi2 = 56.02713178294569
dof = 3
reduced_chi2 = 18.67571059431523
accepted = false
reason = fit
```

The gain limit passes 0.85. Reduced chi-square exceeds the fit limit of 1.5.
Keep this negative result. Changing selection or uncertainty to obtain a
pass would violate the specified scientific rule.

The interface check alone does not prove scientific correctness. The local
analytic and numerical tests provide the recorded checks. Extreme
floating-point scales were not tested. No open stage 2 work remains.
Preserve these rules, API, and tests when a later change is supplied.
