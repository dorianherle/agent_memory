## Goal
[f52c2c99] # Inventory reservation ledger, stage 0
Supported operations:
- `reserve`: require unused `hold_id`, positive integer `qty`, and enough available stock. Hold the quantity. Code is `ok`, `duplicate_hold`, or `insufficient`. … [more]

## Steering
[6eecc13f] Enable atomic `amend` when `policy.allow_amend` is true. It replaces an active hold quantity with po…
Apply CHANGE2.json. Preserve all prior behavior and output fields. Update HANDOFF.md after your checks. … [more]

## Handoff
[6552bdb4] # Reservation ledger: stage 1 handoff
```text
`expires_at <= event.time`. Add its quantity to available stock. Keep its
Changed operation, quantity, hold ID, time, or TTL does not change it.
`expires_at = event.time + event.ttl`. With expiry disabled, store null and
Do not cache only successes, replay repeated operations, replace cached
## Checks … [more]

## Related
[2a9b877d] # Reservation ledger: stage 0 handoff
Do not replace the cached stock snapshot with current stock.
An unsuccessful reservation does not consume its hold ID.
Do not infer rules for expiration, conflicts, or amendment from policy names. … [more]