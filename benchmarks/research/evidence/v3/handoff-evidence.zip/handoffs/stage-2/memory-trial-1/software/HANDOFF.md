# Reservation ledger: stage 2 handoff

## Status

Stage 2 is complete. All 19 local tests and the basic interface check passed.
Earlier rules were recovered with `read_notes.py --all`. The supplied input
already contained the change. Only solution.py, tests, and this file changed.

## API and input

Export `solve(payload: dict) -> dict`. Use only the Python standard library
and NumPy. This solution needs only the standard library. Do not read files,
print, use a network, or change the input in solve. Return native JSON values
and finite numbers. Each call starts with fresh state.

Output is `{"schema_version": 1, "result": {...}}`. The result has exactly
`responses`, `available`, `purchased`, and `holds`. Responses stay in event
order and have exactly `request_id`, `code`, and `available`. Holds are sorted
by hold_id and have exactly `hold_id`, `qty`, and `expires_at`.

Input has initial stock, policy, and ordered events. Events have request_id,
op, and nondecreasing integer time. Events are structurally valid. Quantities
and TTLs are positive integers when present. Unknown operations are outside
scope. All policy flags default to false when absent.

## Rules and processing order

The invariant is:

```text
available = initial stock - purchased - sum(active hold quantities)
```

1. If policy.expire is true, expire every active hold with
   `expires_at <= event.time` before every event, including repeated keys.
   Restore its stock but keep its ID used. No expiry occurs after the last
   event time. With expiry disabled, ignore TTL and store null deadlines.
2. Check the request cache. If reject_key_conflict is false, every repeated
   request ID returns the first cached response, even with changed content.
   If it is true, compare `(op, hold_id or null, qty or null, ttl or null)`.
   Time is excluded. Absent fields and explicit null have the same value.
   An exact match returns the original response and stock snapshot.
   A mismatch returns conflict with current available stock. Do not execute
   the operation or replace the original cache or fingerprint.
3. Execute a first request, then cache its response and fingerprint. Cache
   failures as well as successes. Append a separate response dictionary.

Reserve checks the used hold ID first. Return duplicate_hold for a used ID,
even if stock is insufficient. Otherwise, return insufficient if qty exceeds
available stock. On success, subtract qty, create the hold, and mark its ID
used. With expiry enabled, its deadline is time + ttl. Only a successful
reserve marks an ID used. A used ID cannot be reused after release or expiry.

Buy returns insufficient if qty exceeds available stock. Otherwise subtract
qty, add it to purchased, and return ok.

Release returns missing_hold for an inactive ID. Otherwise remove the hold
and its deadline, restore qty, and return ok. Release at the deadline fails
because expiry occurs first. Removing the deadline prevents double restoration.

Amend is enabled only when allow_amend is true. Return missing_hold for an
inactive ID. Check the new qty against available + the old hold qty. If it
does not fit, return insufficient and keep the old hold and deadline exactly.
On success, add old_qty - new_qty to available and replace the hold qty.
Keep the original deadline and used ID. Do not release and reserve to amend.
An amend event with the policy disabled is outside the supported contract.

## Decisions

Keep separate maps for quantities and deadlines, a permanent used-ID set,
and the original response and fingerprint caches. Expiry uses a linear scan
of active holds per event. No larger performance requirement was supplied.
Do not replay operations, cache only successes, replace cached snapshots,
consume failed reserve IDs, reschedule amendment deadlines, or expire past
the final event. Changed keys are rejected only when the policy requires it.

## Checks and results

From this directory, run:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_solution.py
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B ../check_interface.py solution.py input.json
```

All 19 tests passed. The 14 earlier tests cover original caching, cached
failures, changed duplicates with rejection disabled, permanent used IDs,
reserve code priority, ignored TTL, sorted holds, conservation, exact-stock
buys, empty events, expiry boundaries, early release, simultaneous expiry,
expiry before replay, no future expiry, exact schema, and input preservation.

Five new tests cover failed atomic amendments, increases at the stock limit,
decreases, missing and expired holds, unchanged deadlines, null deadlines,
cached amendment failures, conflict stock after expiry, unchanged original
cache after conflict, each fingerprint field, and null field equivalence.

The supplied input returns codes ok, ok, insufficient, ok, conflict, ok,
with response stock snapshots 4, 1, 1, 0, 0, 0. Final available is 7,
purchased is 0, and H2 remains with qty 3 and expires_at 11. The last replay
returns the old zero snapshot after H1 expires. This is required behavior.

The interface check alone does not prove ledger correctness. The local tests
check state changes and responses. No open stage 2 work remains. Preserve
these tests and rules when a later change is supplied.
