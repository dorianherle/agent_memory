import copy
import json
import unittest

from solution import solve


def run(events, stock=10, expire=False, allow_amend=False, reject_key_conflict=False):
    return solve({"stock": stock,
                  "policy": {"expire": expire, "reject_key_conflict": reject_key_conflict, "allow_amend": allow_amend},
                  "events": events})["result"]


def event(request_id, op, time=0, **fields):
    return {"request_id": request_id, "op": op, "time": time, **fields}


class LedgerTests(unittest.TestCase):
    def test_atomic_amend_failure_and_deadline(self):
        result = run([event("a", "reserve", hold_id="H", qty=6, ttl=10),
                      event("b", "reserve", 1, hold_id="J", qty=3, ttl=20),
                      event("c", "amend", 2, hold_id="H", qty=8),
                      event("d", "amend", 3, hold_id="H", qty=7)],
                     expire=True, allow_amend=True)
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "ok", "insufficient", "ok"])
        self.assertEqual(result["responses"][2]["available"], 1)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 7, "expires_at": 10},
                                           {"hold_id": "J", "qty": 3, "expires_at": 21}])
        failed = run([event("a", "reserve", hold_id="H", qty=6, ttl=10),
                      event("b", "amend", 1, hold_id="H", qty=11)], expire=True, allow_amend=True)
        self.assertEqual(failed["holds"], [{"hold_id": "H", "qty": 6, "expires_at": 10}])

    def test_amend_shrink_missing_expired_and_cached_failure(self):
        result = run([event("a", "reserve", hold_id="H", qty=10, ttl=3),
                      event("b", "amend", 1, hold_id="H", qty=11),
                      event("c", "amend", 1, hold_id="H", qty=2),
                      event("b", "amend", 2, hold_id="H", qty=11),
                      event("d", "amend", 3, hold_id="H", qty=1),
                      event("e", "amend", 3, hold_id="absent", qty=1)],
                     expire=True, allow_amend=True, reject_key_conflict=True)
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "insufficient", "ok", "insufficient", "missing_hold", "missing_hold"])
        self.assertEqual(result["responses"][1], result["responses"][3])
        self.assertEqual(result["available"], 10)
        self.assertEqual(result["holds"], [])

    def test_conflict_does_not_replace_cache_and_expiry_occurs_first(self):
        result = run([event("a", "reserve", hold_id="H", qty=6, ttl=3),
                      event("a", "reserve", 1, hold_id="H", qty=5, ttl=3),
                      event("a", "buy", 3, qty=1),
                      event("a", "reserve", 4, hold_id="H", qty=6, ttl=3)],
                     expire=True, reject_key_conflict=True)
        self.assertEqual(result["responses"], [
            {"request_id": "a", "code": "ok", "available": 4},
            {"request_id": "a", "code": "conflict", "available": 4},
            {"request_id": "a", "code": "conflict", "available": 10},
            {"request_id": "a", "code": "ok", "available": 4}])
        self.assertEqual(result["available"], 10)
        self.assertEqual(result["purchased"], 0)

    def test_all_fingerprint_fields_and_null_equivalence(self):
        for field, value in (("op", "buy"), ("hold_id", "J"), ("qty", 3), ("ttl", 2)):
            first = event("a", "reserve", hold_id="H", qty=2, ttl=1)
            changed = dict(first, time=1)
            changed[field] = value
            result = run([first, changed, dict(first, time=2)], reject_key_conflict=True)
            self.assertEqual(result["responses"][1]["code"], "conflict")
            self.assertEqual(result["responses"][0], result["responses"][2])
        result = run([event("a", "buy", qty=2), event("a", "buy", 5, qty=2, ttl=None, hold_id=None)],
                     reject_key_conflict=True)
        self.assertEqual(result["responses"][0], result["responses"][1])

    def test_amend_without_expiry_preserves_null_deadline(self):
        result = run([event("a", "reserve", hold_id="H", qty=6),
                      event("b", "amend", 100, hold_id="H", qty=10)], allow_amend=True)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 10, "expires_at": None}])
        self.assertEqual(result["available"], 0)

    def test_expiry_before_repeated_request_preserves_cached_failures(self):
        result = run([event("a", "reserve", hold_id="H1", qty=6, ttl=3),
                      event("b", "buy", 1, qty=5),
                      event("a", "reserve", 3, hold_id="H1", qty=6, ttl=3),
                      event("b", "buy", 4, qty=5),
                      event("c", "buy", 4, qty=5)], expire=True)
        self.assertEqual(result, {"responses": [
            {"request_id": "a", "code": "ok", "available": 4},
            {"request_id": "b", "code": "insufficient", "available": 4},
            {"request_id": "a", "code": "ok", "available": 4},
            {"request_id": "b", "code": "insufficient", "available": 4},
            {"request_id": "c", "code": "ok", "available": 5}],
            "available": 5, "purchased": 5, "holds": []})

    def test_expired_id_stays_used_and_release_at_boundary_fails(self):
        result = run([event("a", "reserve", hold_id="H", qty=4, ttl=2),
                      event("b", "release", 2, hold_id="H"),
                      event("c", "reserve", 2, hold_id="H", qty=20, ttl=1)], expire=True)
        self.assertEqual([r["code"] for r in result["responses"]],
                         ["ok", "missing_hold", "duplicate_hold"])
        self.assertEqual(result["available"], 10)

    def test_active_expirations_and_no_future_expiry(self):
        result = run([event("a", "reserve", 1, hold_id="Z", qty=2, ttl=4),
                      event("b", "reserve", 2, hold_id="A", qty=3, ttl=1)], expire=True)
        self.assertEqual(result["holds"], [
            {"hold_id": "A", "qty": 3, "expires_at": 3},
            {"hold_id": "Z", "qty": 2, "expires_at": 5}])
        self.assertEqual(result["available"], 5)

    def test_multiple_expirations_restore_stock_before_buy(self):
        result = run([event("a", "reserve", hold_id="A", qty=3, ttl=2),
                      event("b", "reserve", hold_id="B", qty=4, ttl=2),
                      event("c", "buy", 2, qty=10)], expire=True)
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 10)
        self.assertEqual(result["holds"], [])

    def test_release_before_expiry_restores_stock_only_once(self):
        result = run([event("a", "reserve", hold_id="H", qty=4, ttl=3),
                      event("b", "release", 2, hold_id="H"),
                      event("c", "buy", 3, qty=10)], expire=True)
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 10)

    def test_expiry_on_changed_duplicate_and_input_preservation(self):
        data = {"stock": 10, "policy": {"expire": True}, "events": [
            event("a", "reserve", hold_id="H", qty=7, ttl=1),
            event("a", "buy", 1, qty=10)]}
        original = copy.deepcopy(data)
        result = solve(data)["result"]
        self.assertEqual(data, original)
        self.assertEqual(result["responses"][0], result["responses"][1])
        self.assertEqual(result["available"], 10)
        self.assertEqual(result["purchased"], 0)
        self.assertEqual(result["holds"], [])

    def test_original_sequence_and_cached_stock_snapshot(self):
        result = run([event("a", "reserve", hold_id="H1", qty=4, ttl=5),
                      event("b", "buy", 1, qty=3),
                      event("a", "reserve", 2, hold_id="H1", qty=4, ttl=5),
                      event("c", "release", 3, hold_id="H1")])
        self.assertEqual(result, {"responses": [
            {"request_id": "a", "code": "ok", "available": 6},
            {"request_id": "b", "code": "ok", "available": 3},
            {"request_id": "a", "code": "ok", "available": 6},
            {"request_id": "c", "code": "ok", "available": 7}],
            "available": 7, "purchased": 3, "holds": []})

    def test_changed_duplicate_request_returns_old_response(self):
        result = run([event("a", "buy", qty=3),
                      event("a", "reserve", 20, qty=5, hold_id="new")])
        self.assertEqual(result["responses"][0], result["responses"][1])
        self.assertEqual(result["available"], 7)
        self.assertEqual(result["holds"], [])

    def test_failed_reserve_does_not_use_hold_id_but_is_cached(self):
        result = run([event("a", "reserve", qty=11, hold_id="H"),
                      event("b", "reserve", 1, qty=2, hold_id="H"),
                      event("a", "reserve", 2, qty=1, hold_id="other")])
        self.assertEqual([r["code"] for r in result["responses"]], ["insufficient", "ok", "insufficient"])
        self.assertEqual(result["responses"][2]["available"], 10)
        self.assertEqual(result["available"], 8)
        self.assertEqual(result["holds"], [{"hold_id": "H", "qty": 2, "expires_at": None}])

    def test_released_hold_id_cannot_be_reused(self):
        result = run([event("a", "reserve", qty=4, hold_id="H"),
                      event("b", "release", 1, hold_id="H"),
                      event("c", "reserve", 2, qty=20, hold_id="H"),
                      event("d", "release", 3, hold_id="H")])
        self.assertEqual([r["code"] for r in result["responses"]], ["ok", "ok", "duplicate_hold", "missing_hold"])
        self.assertEqual(result["available"], 10)

    def test_failed_buy_and_release_are_cached(self):
        result = run([event("a", "reserve", qty=10, hold_id="H"),
                      event("b", "buy", 1, qty=1),
                      event("c", "release", 2, hold_id="absent"),
                      event("d", "release", 3, hold_id="H"),
                      event("b", "buy", 4, qty=1),
                      event("c", "release", 5, hold_id="H")])
        self.assertEqual(result["responses"][1], result["responses"][4])
        self.assertEqual(result["responses"][2], result["responses"][5])
        self.assertEqual(result["available"], 10)
        self.assertEqual(result["purchased"], 0)

    def test_ttl_is_ignored_and_holds_are_sorted(self):
        result = run([event("a", "reserve", qty=2, hold_id="Z", ttl=1),
                      event("b", "reserve", 1000, qty=3, hold_id="A", ttl=1),
                      event("c", "buy", 1001, qty=5)])
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 5)
        self.assertEqual(result["holds"], [
            {"hold_id": "A", "qty": 3, "expires_at": None},
            {"hold_id": "Z", "qty": 2, "expires_at": None}])
        self.assertEqual(result["available"] + result["purchased"] + sum(h["qty"] for h in result["holds"]), 10)

    def test_empty_events_and_exact_stock_purchase(self):
        self.assertEqual(run([]), {"responses": [], "available": 10, "purchased": 0, "holds": []})
        result = run([event("a", "buy", qty=10), event("b", "buy", 1, qty=1)])
        self.assertEqual(result["available"], 0)
        self.assertEqual(result["purchased"], 10)
        self.assertEqual(result["responses"][1]["code"], "insufficient")

    def test_interface_and_input_preservation(self):
        data = {"stock": 5, "events": [event("a", "reserve", qty=2, hold_id="H")], "policy": {}}
        original = copy.deepcopy(data)
        output = solve(data)
        self.assertEqual(data, original)
        self.assertEqual(output["schema_version"], 1)
        self.assertEqual(set(output["result"]), {"responses", "available", "purchased", "holds"})
        self.assertEqual(set(output["result"]["responses"][0]), {"request_id", "code", "available"})
        json.dumps(output, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
