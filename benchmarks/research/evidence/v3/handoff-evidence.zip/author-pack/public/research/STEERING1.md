The laboratory now supplies correlated measurement errors. Update the same API.
If `covariance` is a matrix, use it as the full covariance of `y`. It overrides `sigma`. Use generalized least squares: minimize residual-transpose times covariance-inverse times residual.
Use `(X^T C^-1 X)^-1` for parameter covariance. Do not scale it by residual error.
The one-sided gain gate and fit gate remain as specified. The supplied covariance is symmetric positive definite.
Apply CHANGE1.json to input.json. Preserve independent-error support. Update HANDOFF.md after your checks.
