# Linear sensor experiment, stage 0
Implement `solution.py` with the interface in `../API.md`. Input is `input.json`.
Estimate sensor offset and gain from measurements `y = offset + gain*x + error`.
Stage 0 has independent errors. Each `sigma` is a known standard deviation of `y`, not an estimated residual deviation. Use weighted least squares with an intercept.
Scientific decisions are fixed:
- Use only rows for which `include` is true. At this stage all rows are included.
- Use the supplied measurement uncertainty. Do not multiply parameter covariance by reduced chi-square.
- The lower gain limit is one-sided: `gain - policy.z_one_sided * gain_se`.
- Accept only if the lower gain limit is at least `min_gain` AND reduced chi-square is at most `max_reduced_chi2`. Equality passes.
- Degrees of freedom are the number of included observations minus two.
All test inputs have at least three included observations, full-rank design, positive sigma, and finite data.
Output `result` must contain exactly `offset`, `gain`, `gain_se`, `gain_lower`, `chi2`, `dof`, `reduced_chi2`, `accepted`, and `reason`.
`accepted` is Boolean. `reason` is `ok`, `gain`, `fit`, or `gain+fit`, depending on the failed gates. Numerical values are floats, except integer `dof`.
`covariance` is null at stage 0. The field is reserved for a later change.
Deliver executable code. Then write `HANDOFF.md` with the full decisions, formulas, API, completed work, checks, and open work. Keep the note complete enough for a fresh agent.
