import json,sys
from pathlib import Path
p=Path(sys.argv[1]); data=json.loads(p.read_text()); change=json.loads(Path(sys.argv[2]).read_text())
assert change["operation"]=="replace_top_level"
data.update(change["set"])
p.write_text(json.dumps(data,indent=2)+"\n")
