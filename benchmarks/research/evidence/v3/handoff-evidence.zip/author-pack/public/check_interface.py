import importlib.util, json, sys
from pathlib import Path
spec=importlib.util.spec_from_file_location("candidate",Path(sys.argv[1]).resolve())
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=json.loads(Path(sys.argv[2]).read_text())
r=m.solve(p)
assert set(r)=={"schema_version","result"} and r["schema_version"]==1
assert isinstance(r["result"],dict)
print(json.dumps(r,allow_nan=False,indent=2))
