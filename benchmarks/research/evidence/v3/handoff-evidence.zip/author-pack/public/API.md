# Common interface
Create `solution.py` in the task directory. Export `solve(payload: dict) -> dict`.
Use only Python standard library and NumPy. Do not read files, print, use a network, or change the input in `solve`.
Each input is a JSON object. Each output is `{"schema_version": 1, "result": {...}}`.
Return native JSON values. Use finite numbers. Numerical comparison permits small floating-point error.
Run `python check_interface.py solution.py input.json` for a basic local check. This check does not verify scientific or software correctness.
All stages use this interface. Later stages must preserve earlier behavior.
