Enable expiring holds when `policy.expire` is true. A successful reserve expires at event.time + event.ttl.
Before EVERY event, including a repeated request, expire holds for which expires_at <= event.time. Restore their stock, but keep their IDs marked used.
After this expiry step, a repeated request still returns its original cached response. Thus its stock snapshot can differ from current stock. Do not recompute cached responses. No expiry occurs beyond the final event time.
Apply CHANGE1.json. Preserve behavior when expire is false. Update HANDOFF.md after your checks.
