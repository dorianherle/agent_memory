# Inventory reservation ledger, stage 0
Implement `solution.py` with the interface in `../API.md`. Input is `input.json`.
Replay an ordered event list from initial `stock`. Each event has unique or repeated `request_id`, nondecreasing integer `time`, and `op`.
Supported operations:
- `reserve`: require unused `hold_id`, positive integer `qty`, and enough available stock. Hold the quantity. Code is `ok`, `duplicate_hold`, or `insufficient`.
- `buy`: require enough available stock. Remove `qty` permanently. Code is `ok` or `insufficient`.
- `release`: remove an active hold and restore its quantity. Code is `ok` or `missing_hold`.
Available stock equals initial stock minus all purchases minus active hold quantities.
Hold IDs can never be reused, including after release. Mark an ID as used only after a successful reserve.
Cache the response of every first request, including failed requests. Repeated request IDs return the exact cached response. At stage 0 they return that response even if the event payload differs.
Output `result` contains exactly `responses`, `available`, `purchased`, and `holds`.
Each response contains exactly `request_id`, `code`, and `available` (the stock snapshot for that response). Responses stay in event order.
`holds` is a list sorted by hold_id. Each entry contains exactly `hold_id`, `qty`, and `expires_at`. In stage 0 `expires_at` is null. `purchased` is total successful buy quantity.
All events are structurally valid. `qty` and `ttl` are positive integers when present. Unknown operations are outside scope. `policy` flags are false in stage 0. `ttl` is ignored in stage 0.
Deliver executable code. Then write HANDOFF.md with the rules, API, decisions, completed checks, and open work for a fresh agent.
