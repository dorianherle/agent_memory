# Fresh-agent development evaluation pack

This pack has two executable tasks and two sequential handoffs for each task. It tests continuation of work after changed inputs and requirements. It does not test recall of isolated facts.

## Files and access

Give workers only a copy of `public/API.md`, the selected `public/<task>/` directory, and the two public utility scripts. Keep `private/`, this protocol, validation reports, and the freeze manifest outside their accessible workspace. Do not provide the reference code or private check inputs. The grader is a functional check tool, not a security sandbox. Run untrusted submissions in a separate restricted environment if necessary. The subprocess time limit is an operational guard, not a measured speed result.

Workers use `solution.py` and the common `solve(payload)` interface. No model workers have been run for this pack.

## Sequence and equal information

1. A sender implements stage 0 from TASK0.md and input.json. The sender writes a complete HANDOFF.md. Allow about five minutes as a target work budget, not as a validated completion time.
2. Store the exact same HANDOFF.md text in Agent Memory and in an ordinary searchable Markdown notebook. Preserve all content and its order. Do not add filler to either condition. Keep insertion evidence and a SHA-256 hash of the original note. A retrieval system can change indexing; record that difference.
3. Start a fresh receiver with the sender's source files, the public interface, current input, STEERING1.md, and CHANGE1.json. Give access only to the assigned note store. Do not copy the sender's conversation. Apply the change file to the current input. The receiver updates the code and writes a new complete HANDOFF.md.
4. Use a saved stage-1 checkpoint as the sender for the second handoff. For each such checkpoint, copy its exact code and byte-identical complete note into both conditions. Start a fresh receiver in each condition with that same checkpoint, the public interface, current input, STEERING2.md, and CHANGE2.json. Repeat the work and note procedure. If both stage-1 outputs are selected, run a separate matched pair for each output.
5. Grade after each stage. Use the same frozen checks, model, tools, work budget, and workspace rules in both conditions. Grade stages 1 and 2 cumulatively to check earlier behavior. Preserve every submission, handoff note, retrieval trace available, tool error, and timeout.

At both handoffs, the compared conditions must receive the same sender code and byte-identical stored note. Select stage-1 checkpoints by a rule declared before runs. One rule is to use every stage-1 checkpoint as a separate matched pair. Each stage-2 worker continues actual stage-1 work. This matched design tests the second handoff but does not directly estimate an unpaired end-to-end pipeline effect. If a separate end-to-end study is added, label it separately and report any differences in the stage-1 notes and code.

Counterbalance condition order and randomize task order. Keep separate fresh workspaces. Record actual model IDs, settings, retrieval configuration, and tool access. A worker must not inspect another condition. No notebook condition has deliberate distracting filler.

## Checks and scoring

`private/grader.py TASK SOLUTION --stage N` outputs JSON. Stages 0, 1, and 2 select all cases through N. It executes each candidate in a fresh subprocess, checks the unchanged input, and requires JSON output. A process error causes all check groups for that case to fail. It does not rank runtime.

Research has 15 private cases: eight at stage 0, four added at stage 1, and three added at stage 2. Expected values come from analytic symmetric designs and exact rational arithmetic for two asymmetric designs. They are stored as fixed numbers. The grader does not import the reference code. The checks cover unequal uncertainty, one-sided confidence, known uncertainty without residual scaling, both acceptance gates, equality, full covariance, covariance precedence, selected rows and columns, degrees of freedom, and retained discrepant observations.

Software has 13 private cases: five at stage 0, three added at stage 1, and five added at stage 2. Expected state and response values were specified directly. Checks cover failed-response caching, permanent hold IDs, ordered replies, sorted holds, expiry at the exact deadline, expiry before replay, stale cached snapshots, no final time advance, atomic failure, original deadline preservation, request conflicts, and cache preservation.

The research score is 10% interface/schema, 45% numerical results, and 45% scientific decisions. The software score is 10% interface/schema, 50% response behavior, and 40% final state. Each case has equal weight within a group. Scores are descriptive partial credit. Always report full-case passes and all group counts. A high interface score does not establish scientific correctness.

The numeric tolerance is relative 1e-7 and absolute 1e-8. Research decisions and Boolean types must match exactly. Software values are discrete, although the shared comparator allows the numeric tolerance. List order and all expected keys must match. Research dof must be an integer. Do not change checks after workers start. Use a new pack version if a real check defect is found.

## Reference and controls

`private/references/` contains complete correct implementations. `private/controls/` contains unfinished stubs and complete stage-0 implementations that miss later requirements. These are functional controls for the grader. They are not model outputs and do not measure memory quality. `private/VALIDATION.json` records all stage checks for references and controls. The references must pass every case. The stubs must fail meaningful checks. The stage-0 controls must pass stage 0 and fail later checks.

## Scope and limitations

The research task is a small linear experimental analysis with known observation covariance. It is not a physical experiment or a claim of measured sensor performance. The software task is an in-memory inventory replay. It has no concurrent clients, persistence, external clock, malformed inputs, or network service.

Two compact tasks cannot establish a general advantage for any memory system. Correct code can encode much of the earlier knowledge. Public task documents also provide some prior rules. Measure source-code carryover and document availability as part of the environment. Handoff notes and retrieval traces help explain a result, but do not replace executable correctness checks. API naming is a small part of the score. The private cases are fixed rather than exhaustive. Multiple paired runs are required to estimate model variability. Report failures and tool limitations without replacing them with positive claims.

No timing, cost, worker success, or memory-system effect is claimed from this pack's validation. References and controls were the only programs evaluated.
