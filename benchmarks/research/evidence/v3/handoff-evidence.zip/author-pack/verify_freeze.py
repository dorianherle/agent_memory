"""Verify the frozen author pack before and after worker evaluation."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'FREEZE.json').read_text())
fail=[]
for name,expected in manifest['sha256'].items():
 p=root/name
 if not p.is_file():fail.append(name+': missing');continue
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 if actual!=expected:fail.append(name+': changed')
expected=set(manifest['sha256'])
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='FREEZE.json'}
fail.extend(name+': extra' for name in sorted(actual-expected))
if fail:
 print('\n'.join(fail));sys.exit(1)
print('Frozen pack verified: '+str(len(expected))+' files.')
