"""Private functional grader. No runtime ranking. Use --stage for cumulative checks."""
import argparse,json,math,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RUNNER="""import importlib.util,json,sys,copy
s=importlib.util.spec_from_file_location('solution',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=json.load(sys.stdin);before=copy.deepcopy(p);r=m.solve(p);assert p==before,'input mutation';print(json.dumps(r,allow_nan=False))"""
def close(a,b):
 if isinstance(b,bool):return type(a) is bool and a==b
 if isinstance(b,(float,int)):
  return isinstance(a,(float,int)) and not isinstance(a,bool) and math.isfinite(a) and math.isclose(a,b,rel_tol=1e-7,abs_tol=1e-8)
 if isinstance(b,dict):return isinstance(a,dict) and set(a)==set(b) and all(close(a[k],v) for k,v in b.items())
 if isinstance(b,list):return isinstance(a,list) and len(a)==len(b) and all(close(x,y) for x,y in zip(a,b))
 return a==b

def grade(task,solution,stage=2):
 cases=json.loads((ROOT/(task+'_cases.json')).read_text());cases=[c for c in cases if c['stage']<=stage]
 groups={'schema':10,'numeric':45,'decisions':45} if task=='research' else {'schema':10,'responses':50,'state':40}
 passed={k:0 for k in groups};rows=[]
 for c in cases:
  checks={k:False for k in groups};error=None
  try:
   proc=subprocess.run([sys.executable,'-c',RUNNER,str(Path(solution).resolve())],input=json.dumps(c['input']),text=True,capture_output=True,timeout=10)
   if proc.returncode:raise RuntimeError('candidate process failed')
   out=json.loads(proc.stdout);exp=c['expected'];res=out.get('result',{})
   checks['schema']=isinstance(out,dict) and set(out)=={'schema_version','result'} and type(out['schema_version']) is int and out['schema_version']==1 and isinstance(res,dict) and set(res)==set(exp)
   if task=='research':
    num=[k for k in exp if k not in ('accepted','reason')]
    checks['numeric']=all(k in res and close(res[k],exp[k]) for k in num) and type(res.get('dof')) is int
    checks['decisions']=all(k in res and close(res[k],exp[k]) for k in ('accepted','reason'))
   else:
    checks['responses']='responses' in res and close(res['responses'],exp['responses'])
    checks['state']=all(k in res and close(res[k],exp[k]) for k in ('available','purchased','holds'))
  except Exception as exc:error=type(exc).__name__+': '+str(exc)
  for k,v in checks.items():passed[k]+=int(v)
  rows.append({'name':c['name'],'stage':c['stage'],'checks':checks,'all_pass':all(checks.values()),'error':error})
 n=len(cases)
 return {'task':task,'max_stage':stage,'cases':n,'full_passes':sum(v['all_pass'] for v in rows),'score':round(sum(groups[k]*passed[k]/n for k in groups),4),'category_passes':passed,'category_weights':groups,'details':rows}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('task',choices=['research','software']);p.add_argument('solution');p.add_argument('--stage',type=int,choices=[0,1,2],default=2);a=p.parse_args();print(json.dumps(grade(a.task,a.solution,a.stage),indent=2))
