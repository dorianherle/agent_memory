import numpy as np
def solve(payload):
 x=np.array(payload["x"],float);y=np.array(payload["y"],float);X=np.column_stack((np.ones(len(x)),x));w=1/np.array(payload["sigma"],float)**2
 V=np.linalg.inv(X.T@(w[:,None]*X));b=V@(X.T@(w*y));chi=float(((y-X@b)**2*w).sum());df=len(x)-2;se=float(np.sqrt(V[1,1]));p=payload["policy"];lo=float(b[1]-p["z_one_sided"]*se);g=lo<p["min_gain"];f=chi/df>p["max_reduced_chi2"]
 return {"schema_version":1,"result":{"offset":float(b[0]),"gain":float(b[1]),"gain_se":se,"gain_lower":lo,"chi2":chi,"dof":df,"reduced_chi2":chi/df,"accepted":not(g or f),"reason":"gain+fit" if g and f else "gain" if g else "fit" if f else "ok"}}
