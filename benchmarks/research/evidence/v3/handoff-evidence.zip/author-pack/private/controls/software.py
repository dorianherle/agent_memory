def solve(payload):
 return {"schema_version":1,"result":{"responses":[{"request_id":e["request_id"],"code":"ok","available":payload["stock"]} for e in payload["events"]],"available":payload["stock"],"purchased":0,"holds":[]}}
