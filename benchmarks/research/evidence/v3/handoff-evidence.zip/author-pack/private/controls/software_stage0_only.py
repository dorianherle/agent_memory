def solve(payload):
 available=payload["stock"]; purchased=0;holds={};used=set();cache={};responses=[];p={"expire":False,"reject_key_conflict":False,"allow_amend":False}
 for e in payload["events"]:
  if p["expire"]:
   for h in list(holds):
    if holds[h]["expires_at"]<=e["time"]:available+=holds.pop(h)["qty"]
  rid=e["request_id"];finger=tuple(e.get(k) for k in ("op","hold_id","qty","ttl"))
  if rid in cache:
   oldfinger,response=cache[rid]
   if p["reject_key_conflict"] and finger!=oldfinger:response={"request_id":rid,"code":"conflict","available":available}
   responses.append(dict(response));continue
  op=e["op"];h=e.get("hold_id");q=e.get("qty");code="ok"
  if op=="reserve":
   if h in used:code="duplicate_hold"
   elif q>available:code="insufficient"
   else:
    available-=q;used.add(h);holds[h]={"hold_id":h,"qty":q,"expires_at":e["time"]+e["ttl"] if p["expire"] else None}
  elif op=="buy":
   if q>available:code="insufficient"
   else:available-=q;purchased+=q
  elif op=="release":
   if h not in holds:code="missing_hold"
   else:available+=holds.pop(h)["qty"]
  elif op=="amend" and p["allow_amend"]:
   if h not in holds:code="missing_hold"
   elif q>available+holds[h]["qty"]:code="insufficient"
   else:available+=holds[h]["qty"]-q;holds[h]["qty"]=q
  else:raise ValueError("operation unsupported by policy")
  response={"request_id":rid,"code":code,"available":available};cache[rid]=(finger,response);responses.append(dict(response))
 return {"schema_version":1,"result":{"responses":responses,"available":available,"purchased":purchased,"holds":[holds[h] for h in sorted(holds)]}}
