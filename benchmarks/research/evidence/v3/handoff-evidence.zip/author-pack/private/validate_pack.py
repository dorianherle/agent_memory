"""Validate reference programs, controls, and public change recipes."""
from pathlib import Path
import importlib.util,json,copy
from grader import grade
ROOT=Path(__file__).resolve().parent
reports=[]
for task in ['research','software']:
 for kind,file in [('reference',f'references/{task}.py'),('stub',f'controls/{task}.py'),('stage0_only',f'controls/{task}_stage0_only.py')]:
  for stage in range(3):
   z=grade(task,ROOT/file,stage);z['implementation']=kind;reports.append(z)
   print(task,kind,stage,z['full_passes'],z['cases'],z['score'])
   if kind=='reference':assert z['full_passes']==z['cases'],z
   elif kind=='stub':assert z['full_passes']<z['cases'],z
   elif stage==0:assert z['full_passes']==z['cases'],z
   else:assert z['full_passes']<z['cases'],z
 public=ROOT.parent/'public'/task
 data=json.loads((public/'input.json').read_text())
 s=importlib.util.spec_from_file_location('ref',ROOT/'references'/f'{task}.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 for stage in range(3):
  if stage:
   change=json.loads((public/f'CHANGE{stage}.json').read_text());assert change['operation']=='replace_top_level';data.update(change['set'])
  before=copy.deepcopy(data);out=m.solve(data);assert data==before
  json.dumps(out,allow_nan=False)
  assert set(out)=={'schema_version','result'} and out['schema_version']==1
(ROOT/'VALIDATION.json').write_text(json.dumps(reports,indent=2)+'\n')
