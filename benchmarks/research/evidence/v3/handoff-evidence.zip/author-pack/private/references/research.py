import numpy as np
def solve(payload):
 mask=np.array(payload["include"],dtype=bool)
 x=np.array(payload["x"],dtype=float)[mask];y=np.array(payload["y"],dtype=float)[mask]
 X=np.column_stack((np.ones(len(x)),x))
 if payload["covariance"] is None:
  C=np.diag(np.array(payload["sigma"],dtype=float)[mask]**2)
 else:C=np.array(payload["covariance"],dtype=float)[np.ix_(mask,mask)]
 WX=np.linalg.solve(C,X);Wy=np.linalg.solve(C,y)
 V=np.linalg.inv(X.T@WX);b=V@(X.T@Wy)
 residual=y-X@b;chi=float(residual@np.linalg.solve(C,residual));dof=len(x)-2
 se=float(np.sqrt(V[1,1]));p=payload["policy"];lower=float(b[1]-p["z_one_sided"]*se)
 fg=lower<p["min_gain"];ff=chi/dof>p["max_reduced_chi2"]
 reason="gain+fit" if fg and ff else "gain" if fg else "fit" if ff else "ok"
 return {"schema_version":1,"result":{"offset":float(b[0]),"gain":float(b[1]),"gain_se":se,"gain_lower":lower,"chi2":chi,"dof":dof,"reduced_chi2":chi/dof,"accepted":not(fg or ff),"reason":reason}}
