import copy
import json
import math
from pathlib import Path
import unittest
from study import assess


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        self.config = {'length': 1.2, 'tolerance': 1e-6, 'order_min': 1.8, 'order_max': 2.2}
        self.reference = (math.pi / self.config['length']) ** 2
        self.records = [{'intervals': n, 'length': 1.2, 'eigenvalue': self.reference - 1 / n**2}
                        for n in (16, 32, 64, 128)]

    def test_observed_order_and_unsorted_records(self):
        result = assess(list(reversed(self.records)), self.config)
        self.assertAlmostEqual(result['observed_order'], 2)
        self.assertAlmostEqual(result['extrapolated'], self.reference)
        self.assertTrue(result['qualified'])

    def test_first_order_is_rejected_despite_exact_extrapolation(self):
        for row in self.records:
            row['eigenvalue'] = self.reference - 1e-5 / row['intervals']
        result = assess(self.records, self.config)
        self.assertAlmostEqual(result['observed_order'], 1, places=6)
        self.assertLess(result['relative_error'], 1e-6)
        self.assertFalse(result['qualified'])

    def test_invalid_measurements(self):
        cases = [self.records[:2]]
        for key, value in [('length', 1), ('intervals', 100), ('eigenvalue', float('nan')),
                           ('eigenvalue', 0)]:
            rows = copy.deepcopy(self.records)
            rows[-1][key] = value
            cases.append(rows)
        zero_difference = copy.deepcopy(self.records)
        zero_difference[-1]['eigenvalue'] = zero_difference[-2]['eigenvalue']
        cases.append(zero_difference)
        nonpositive_order = copy.deepcopy(self.records)
        for row, value in zip(nonpositive_order, [1, 2, 3, 5]):
            row['eigenvalue'] = value
        cases.append(nonpositive_order)
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                assess(rows, self.config)

    def test_current_samples_match_current_config(self):
        directory = Path(__file__).parent
        config = json.loads((directory / 'config.json').read_text())
        rows = json.loads((directory / 'samples.json').read_text())
        self.assertTrue(all(row['length'] == config['length'] for row in rows))
        self.assertTrue(assess(rows, config)['qualified'])


if __name__ == '__main__':
    unittest.main()
