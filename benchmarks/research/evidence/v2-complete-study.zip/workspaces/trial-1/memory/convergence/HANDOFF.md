# Cavity convergence study

Completed assess() and main(). The stored samples used length 1.0. main() ran the supplied measure.py and replaced them with samples for the current length, 1.2.

Result in report.json:

- Observed order: 1.9995654545089394.
- Extrapolated eigenvalue: 6.853892055765409.
- Relative error: 1.6131632366384717e-08.
- Qualified: true. The permitted order is 1.8 to 2.2. The error limit is 1e-6.

Method: use the three finest grids, with doubled interval counts. Estimate the order from measured differences. Use that order for Richardson extrapolation. Compare the result with (pi / current length)^2. Keep the measured eigenvalues separate from this analytical reference. Reject invalid data and stale geometry in assess().

Evidence recovered with memory_read.py: 535cbb7a and 75a81ab9.

Tests: main() completed. All four tests in test_study.py passed. The tests cover current geometry, an unsorted grid list, second-order qualification, first-order rejection, and invalid data. Run with the supplied Python: python -m unittest -v test_study.py.

Limits: this result applies to the supplied numerical cavity model. It does not validate a physical cavity. Only the three finest grids determine the order and extrapolation.

Next action: use main() after each configuration change. Add finer measurements if the model or discretization changes.
