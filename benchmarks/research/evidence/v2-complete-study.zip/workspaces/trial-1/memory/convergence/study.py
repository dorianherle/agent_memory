import json
import math
from pathlib import Path
import subprocess
import sys


def _positive(value, name):
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be a finite positive number') from exc
    if not math.isfinite(number) or number <= 0:
        raise ValueError(f'{name} must be a finite positive number')
    return number


def assess(records, config):
    try:
        length = _positive(config['length'], 'length')
        tolerance = _positive(config['tolerance'], 'tolerance')
        order_min = _positive(config['order_min'], 'order_min')
        order_max = _positive(config['order_max'], 'order_max')
        if order_min > order_max:
            raise ValueError('order_min must not exceed order_max')
        measured = []
        for record in records:
            intervals = _positive(record['intervals'], 'intervals')
            record_length = _positive(record['length'], 'record length')
            eigenvalue = _positive(record['eigenvalue'], 'eigenvalue')
            if not intervals.is_integer():
                raise ValueError('intervals must be integers')
            if record_length != length:
                raise ValueError('all sample lengths must equal the current length')
            measured.append((intervals, eigenvalue))
    except (KeyError, TypeError) as exc:
        raise ValueError('required configuration or record field is missing') from exc
    if len(measured) < 3:
        raise ValueError('at least three records are required')
    coarse, middle, fine = sorted(measured)[-3:]
    if middle[0] != 2 * coarse[0] or fine[0] != 2 * middle[0]:
        raise ValueError('the three finest grids must double')
    difference_coarse = abs(coarse[1] - middle[1])
    difference_fine = abs(middle[1] - fine[1])
    if difference_coarse == 0 or difference_fine == 0:
        raise ValueError('grid differences must be nonzero')
    observed_order = math.log2(difference_coarse) - math.log2(difference_fine)
    if not math.isfinite(observed_order) or observed_order <= 0:
        raise ValueError('observed order must be finite and positive')
    # Use measured differences to extrapolate before comparison with the reference.
    try:
        denominator = math.expm1(observed_order * math.log(2))
        extrapolated = fine[1] + (fine[1] - middle[1]) / denominator
        analytical = (math.pi / length) ** 2
        relative_error = abs(extrapolated - analytical) / analytical
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError('extrapolation is not finite') from exc
    if not all(math.isfinite(v) for v in (extrapolated, relative_error)):
        raise ValueError('extrapolation is not finite')
    return {
        'observed_order': observed_order,
        'extrapolated': extrapolated,
        'relative_error': relative_error,
        'qualified': order_min <= observed_order <= order_max and relative_error <= tolerance,
    }


def main():
    directory = Path(__file__).resolve().parent
    config = json.loads((directory / 'config.json').read_text())
    records = json.loads((directory / 'samples.json').read_text())
    if any(record.get('length') != config['length'] for record in records):
        subprocess.run([sys.executable, str(directory / 'measure.py')], cwd=directory, check=True)
        records = json.loads((directory / 'samples.json').read_text())
    report = assess(records, config)
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report


if __name__ == '__main__':
    main()
