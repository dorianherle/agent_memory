import argparse,json,os
from pathlib import Path
from agent_memory import Memory
os.environ['AGENT_MEMORY_NO_REVEAL']='1'
p=argparse.ArgumentParser()
p.add_argument('--id');p.add_argument('--text');p.add_argument('--query')
p.add_argument('--full', action='store_true')
a=p.parse_args()
if not any((a.id,a.text,a.query)): p.error('Use --id, --text, or --query.')
m=Memory(Path(__file__).parent)
args={'action':'find','full':a.full}
if a.id: args['ids']=[a.id]
if a.text: args['text']=a.text
if a.query: args['query']=a.query
text=m.call('memory',args)
with Path(__file__).with_name('reads.jsonl').open('a') as f:
    f.write(json.dumps({'arguments':args,'characters':len(text),'text':text})+'\n')
m._catalog.close()
print(text)
