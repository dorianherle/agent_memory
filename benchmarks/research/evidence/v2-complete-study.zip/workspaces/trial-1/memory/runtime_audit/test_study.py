import copy
import unittest
from study import summarize


def row(predict=1, residual=1e-8, baseline=10):
    return dict(load_ms=2, predict_ms=predict, correct_ms=8, verify_ms=4,
                output_ms=3, training_ms=100000, baseline_ms=baseline, residual=residual)


class RuntimeTests(unittest.TestCase):
    def test_full_attempt_and_failed_coverage(self):
        rows = [row(1), row(2, 1e-3, 11), row(3, baseline=12), row(4, baseline=13)]
        for index, item in enumerate(rows):
            item['correct_ms'] = 8 + index
        result = summarize(rows, {'residual_limit': 1e-6})
        self.assertEqual(result['attempted'], 4)
        self.assertEqual(result['qualified'], 3)
        self.assertEqual(result['median_attempt_ms'], 21)
        self.assertAlmostEqual(result['median_qualified_speedup'], 12 / 22)
        self.assertEqual(result['median_inference_speedup'], 4.75)
        self.assertEqual(result['baseline_contract'], 'construction_only')
        self.assertEqual(result['claim'], 'accuracy_limited')

    def test_claims(self):
        policy = {'residual_limit': 1e-6}
        self.assertEqual(summarize([row(residual=1e-3)], policy)['claim'], 'no_qualified_speedup')
        self.assertIsNone(summarize([row(residual=1e-3)], policy)['median_qualified_speedup'])
        self.assertEqual(summarize([row()], policy)['claim'], 'slower_or_equal')
        self.assertEqual(summarize([row(baseline=100)], policy)['claim'], 'faster')

    def test_threshold_and_training_exclusion(self):
        a = row(residual=1e-6)
        b = dict(a, training_ms=0)
        self.assertEqual(summarize([a], {'residual_limit': 1e-6}),
                         summarize([b], {'residual_limit': 1e-6}))
        self.assertEqual(summarize([a], {'residual_limit': 1e-6})['qualified'], 1)

    def test_invalid_inputs(self):
        cases = [([], {'residual_limit': 1e-6}), ([row()], {'residual_limit': 0})]
        for key, value in [('predict_ms', 0), ('baseline_ms', 0), ('load_ms', -1),
                           ('training_ms', float('nan')), ('residual', float('inf'))]:
            item = row()
            item[key] = value
            cases.append(([item], {'residual_limit': 1e-6}))
        missing = row()
        del missing['verify_ms']
        cases.append(([missing], {'residual_limit': 1e-6}))
        for rows, policy in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                summarize(rows, policy)


if __name__ == '__main__':
    unittest.main()
