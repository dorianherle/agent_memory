import json
import math
from pathlib import Path
from statistics import median


TIMING_FIELDS = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms',
                 'training_ms', 'baseline_ms', 'residual')
ATTEMPT_FIELDS = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms')


def _nonnegative(value, name):
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be finite and nonnegative') from exc
    if not math.isfinite(number) or number < 0:
        raise ValueError(f'{name} must be finite and nonnegative')
    return number


def summarize(rows, policy):
    try:
        limit = _nonnegative(policy['residual_limit'], 'residual_limit')
        if limit == 0:
            raise ValueError('residual_limit must be positive')
        attempts = []
        qualified_speedups = []
        inference_speedups = []
        for row in rows:
            values = {name: _nonnegative(row[name], name) for name in TIMING_FIELDS}
            try:
                full_ms = math.fsum(values[name] for name in ATTEMPT_FIELDS)
            except OverflowError as exc:
                raise ValueError('full attempt time must be finite') from exc
            if full_ms == 0 or values['predict_ms'] == 0 or values['baseline_ms'] == 0:
                raise ValueError('full, prediction, and baseline times must be positive')
            full_speedup = values['baseline_ms'] / full_ms
            inference_speedup = values['baseline_ms'] / values['predict_ms']
            if not math.isfinite(full_speedup) or not math.isfinite(inference_speedup):
                raise ValueError('speedup must be finite')
            attempts.append(full_ms)
            inference_speedups.append(inference_speedup)
            if values['residual'] <= limit:
                qualified_speedups.append(full_speedup)
    except (KeyError, TypeError) as exc:
        raise ValueError('a required row or policy field is missing') from exc
    if not attempts:
        raise ValueError('at least one timing row is required')
    qualified = len(qualified_speedups)
    qualified_median = median(qualified_speedups) if qualified else None
    if qualified == 0:
        claim = 'no_qualified_speedup'
    elif qualified < len(attempts):
        claim = 'accuracy_limited'
    elif qualified_median > 1:
        claim = 'faster'
    else:
        claim = 'slower_or_equal'
    return {
        'attempted': len(attempts),
        'qualified': qualified,
        'median_attempt_ms': median(attempts),
        'median_qualified_speedup': qualified_median,
        'median_inference_speedup': median(inference_speedups),
        'baseline_contract': 'construction_only',
        'claim': claim,
    }


def main():
    directory = Path(__file__).resolve().parent
    rows = json.loads((directory / 'timings.json').read_text())
    policy = json.loads((directory / 'policy.json').read_text())
    report = summarize(rows, policy)
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report


if __name__ == '__main__':
    main()
