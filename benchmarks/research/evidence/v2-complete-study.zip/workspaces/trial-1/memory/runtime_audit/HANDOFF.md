# Learned-solver runtime audit

Completed summarize() and main(). Results in report.json:

- Attempted: 4; accuracy-qualified: 3.
- Median full attempt time: 21 ms, across all four cases.
- Median qualified full speed ratio: 0.5454545454545454.
- Median inference-only speed ratio: 4.75, across all four cases.
- Baseline contract: construction_only.
- Claim: accuracy_limited.

The residual limit is 1e-6. Matrix 1 fails with residual 0.001. Its full attempt remains in the timing median. It is excluded from qualified speed ratios.

Full fresh construction includes loading, prediction, correction, verification, and output. Training is offline and is excluded. Each speed ratio is baseline construction time divided by candidate time. A ratio below one means the candidate takes longer. The qualified full median is slower than the baseline. The inference-only ratio does not establish a full construction speed improvement.

Evidence recovered with memory_read.py: 36b6eef7, d88c0c3c, and 77571cf4.

Tests: main() completed. All four tests in test_study.py passed. The tests cover complete timing, failed-case retention, all four claim labels, the accuracy boundary, offline training exclusion, and invalid inputs. Run with the supplied Python: python -m unittest -v test_study.py.

Limits: only four timing rows are supplied. There are no repeated measurements or timing uncertainties. The reference contract covers inverse construction. It does not cover repeated solves. The inference ratio includes cases that fail accuracy.

Next action: correct the failed case and reduce full construction time. Collect repeated measurements under the same construction contract before a speed claim.
