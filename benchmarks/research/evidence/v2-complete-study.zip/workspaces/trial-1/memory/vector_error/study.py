import json
import math
from pathlib import Path


def _unit_vector(values):
    if getattr(values, 'ndim', 1) != 1:
        raise ValueError('field vectors must be one-dimensional')
    try:
        vector = [complex(value) for value in values]
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('field vectors must contain complex numbers') from exc
    if not vector:
        raise ValueError('field vectors must not be empty')
    if any(not math.isfinite(z.real) or not math.isfinite(z.imag) for z in vector):
        raise ValueError('field values must be finite')
    # Scale before taking the norm to prevent overflow or underflow.
    scale = max(max(abs(z.real), abs(z.imag)) for z in vector)
    if scale == 0:
        raise ValueError('field vectors must have a nonzero norm')
    scaled = [z / scale for z in vector]
    norm = math.sqrt(math.fsum(abs(z) ** 2 for z in scaled))
    return [z / norm for z in scaled]


def field_error(predicted, reference):
    p = _unit_vector(predicted)
    r = _unit_vector(reference)
    if len(p) != len(r):
        raise ValueError('field vectors must have equal lengths')
    overlap = complex(
        math.fsum((a.conjugate() * b).real for a, b in zip(p, r)),
        math.fsum((a.conjugate() * b).imag for a, b in zip(p, r)),
    )
    phase = overlap / abs(overlap) if overlap != 0 else 1 + 0j
    return math.sqrt(math.fsum(abs(phase * a - b) ** 2 for a, b in zip(p, r)))


def main():
    directory = Path(__file__).resolve().parent
    fields = json.loads((directory / 'fields.json').read_text())
    policy = json.loads((directory / 'policy.json').read_text())
    try:
        predicted = [complex(real, imag) for real, imag in fields['predicted']]
        reference = [complex(real, imag) for real, imag in fields['reference']]
        limit = float(policy['field_error_limit'])
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        raise ValueError('invalid fields or policy') from exc
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('field_error_limit must be finite and nonnegative')
    error = field_error(predicted, reference)
    report = {'field_error': error, 'qualified': error <= limit}
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report


if __name__ == '__main__':
    main()
