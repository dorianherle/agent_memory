import math
import unittest
from study import field_error


class FieldTests(unittest.TestCase):
    def test_global_scale_and_phase(self):
        vector = [1 + 2j, 3 - 4j, -2j]
        self.assertLess(field_error([(-7j) * z for z in vector], vector), 1e-14)

    def test_relative_phase_is_detected(self):
        self.assertAlmostEqual(field_error([1, -1], [1, 1]), math.sqrt(2))

    def test_missing_component_is_detected(self):
        self.assertAlmostEqual(field_error([1, 0], [1, 1]), math.sqrt(2 - math.sqrt(2)))

    def test_large_and_small_scales(self):
        self.assertLess(field_error([1e300, 2e300j], [1e-300, 2e-300j]), 1e-14)

    def test_invalid_vectors(self):
        cases = [([], []), ([0, 0], [1, 1]), ([1], [1, 2]),
                 ([[1, 2]], [[1, 2]]), ([float('nan')], [1]),
                 ([complex(1, float('inf'))], [1]), (1, [1])]
        for predicted, reference in cases:
            with self.subTest(predicted=predicted), self.assertRaises(ValueError):
                field_error(predicted, reference)


if __name__ == '__main__':
    unittest.main()
