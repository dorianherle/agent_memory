import json
import math
from pathlib import Path
import unittest
from study import assess, main


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        directory = Path(__file__).resolve().parent
        self.config = json.loads((directory / 'config.json').read_text())
        self.records = json.loads((directory / 'samples.json').read_text())

    def test_current_samples_qualify(self):
        report = assess(self.records, self.config)
        self.assertTrue(report['qualified'])
        self.assertAlmostEqual(report['observed_order'], 2, places=3)
        self.assertLess(report['relative_error'], self.config['tolerance'])

    def test_stale_length_is_rejected(self):
        records = [dict(row, length=1.0) for row in self.records]
        with self.assertRaises(ValueError):
            assess(records, self.config)

    def test_known_order_without_reference_in_fit(self):
        records = [dict(intervals=n, length=1.2, eigenvalue=7 + 2 / n ** 2) for n in (16, 32, 64)]
        report = assess(records, self.config)
        self.assertAlmostEqual(report['observed_order'], 2)
        self.assertAlmostEqual(report['extrapolated'], 7)
        self.assertFalse(report['qualified'])
        self.assertAlmostEqual(report['relative_error'], abs(7 - (math.pi / 1.2) ** 2) / (math.pi / 1.2) ** 2)

    def test_order_gate_and_input_order(self):
        records = [dict(intervals=n, length=1.2, eigenvalue=(math.pi / 1.2) ** 2 + 1 / n) for n in (16, 32, 64)]
        report = assess(list(reversed(records)), self.config)
        self.assertAlmostEqual(report['observed_order'], 1)
        self.assertFalse(report['qualified'])

    def test_main_writes_report(self):
        result = main()
        report = json.loads(Path(__file__).with_name('report.json').read_text())
        self.assertEqual(result, report)


if __name__ == '__main__':
    unittest.main()
