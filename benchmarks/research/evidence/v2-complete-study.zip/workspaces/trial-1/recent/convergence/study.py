import json
import math
from pathlib import Path

def assess(records, config):
    """Estimate the limit from the three finest numerical measurements."""
    length = float(config['length'])
    tolerance = float(config['tolerance'])
    order_min = float(config['order_min'])
    order_max = float(config['order_max'])
    if not all(math.isfinite(x) for x in (length, tolerance, order_min, order_max)):
        raise ValueError('Config values must be finite.')
    if length <= 0 or tolerance < 0 or order_min > order_max:
        raise ValueError('Invalid length, tolerance, or order range.')
    if len(records) < 3:
        raise ValueError('At least three measurements are required.')
    ordered = sorted(records, key=lambda row: row['intervals'])
    for row in ordered:
        n = row['intervals']
        if isinstance(n, bool) or n < 1 or int(n) != n:
            raise ValueError('Intervals must be positive integers.')
        if not math.isclose(float(row['length']), length, rel_tol=1e-12, abs_tol=0):
            raise ValueError('Measurement length does not match the current config.')
        if not math.isfinite(float(row['eigenvalue'])):
            raise ValueError('Measurements must be finite.')
    if len({row['intervals'] for row in ordered}) != len(ordered):
        raise ValueError('Duplicate mesh sizes are not allowed.')
    coarse, medium, fine = ordered[-3:]
    ratio = medium['intervals'] / coarse['intervals']
    if not math.isclose(ratio, fine['intervals'] / medium['intervals'], rel_tol=1e-12):
        raise ValueError('The three finest meshes must have a constant refinement ratio.')
    delta_coarse = float(medium['eigenvalue']) - float(coarse['eigenvalue'])
    delta_fine = float(fine['eigenvalue']) - float(medium['eigenvalue'])
    if delta_coarse * delta_fine <= 0:
        raise ValueError('Observed order requires nonzero differences of the same sign.')
    observed_order = math.log(abs(delta_coarse / delta_fine)) / math.log(ratio)
    if observed_order <= 0:
        raise ValueError('The measurements do not show decreasing error.')
    extrapolated = float(fine['eigenvalue']) + delta_fine / math.expm1(observed_order * math.log(ratio))
    # This reference is used only after the numerical limit has been estimated.
    analytical_reference = (math.pi / length) ** 2
    relative_error = abs(extrapolated - analytical_reference) / analytical_reference
    return {
        'observed_order': observed_order,
        'extrapolated': extrapolated,
        'relative_error': relative_error,
        'qualified': bool(order_min <= observed_order <= order_max and relative_error <= tolerance),
    }

def main():
    directory = Path(__file__).resolve().parent
    records = json.loads((directory / 'samples.json').read_text())
    config = json.loads((directory / 'config.json').read_text())
    report = assess(records, config)
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
