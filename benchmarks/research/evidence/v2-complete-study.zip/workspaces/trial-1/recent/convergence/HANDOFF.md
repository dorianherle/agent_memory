# Cavity convergence study

The current result meets both limits.

- Observed order: 1.99956545450894.
- Extrapolated eigenvalue: 6.853892055765409.
- Relative error: 1.6131632366384717e-08.
- Required relative error: at most 1e-06.
- Required order: 1.8 to 2.2, inclusive.

The supplied samples used length 1.0. The current config uses length 1.2.
I ran the supplied measure.py with the required Python interpreter. It replaced
samples.json with measurements at length 1.2. No analytical reference values
were inserted into the samples.

The available context has only incidental display updates. It does not state
the earlier research method. The implemented method is an explicit assumption:
use the three finest meshes to estimate the observed order and apply Richardson
extrapolation with that order. Use pi squared divided by length squared only
to assess the error after extrapolation. Require both limits to pass.

Five local tests passed. They check the current result, rejection of stale
lengths, an independent known-order sequence, the order limit, and report output.
The known-order test extrapolates to 7 and fails the reference test. This checks
that the numerical fit does not use the analytical reference.

Run from this directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_study
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B study.py
```

Limits: The supplied tool computes a discrete eigenvalue from a closed formula.
These results do not validate a separate physical cavity solver. The last three
meshes must have a constant refinement ratio. Zero or reversed differences are
rejected. The present qualification applies to the extrapolated value.

Next action: Confirm the intended convergence method. Then add a finer mesh or
compare an independent solver with these numerical measurements.
