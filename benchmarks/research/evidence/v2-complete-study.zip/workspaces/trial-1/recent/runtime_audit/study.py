import json
import math
from pathlib import Path
from statistics import median

def summarize(rows, policy):
    """Separate full online runtime, qualified speed, and inference-only speed."""
    if not rows:
        raise ValueError('At least one timing row is required.')
    limit = float(policy['residual_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('Residual limit must be finite and nonnegative.')
    online_fields = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms')
    attempt_times = []
    qualified_speedups = []
    inference_speedups = []
    for row in rows:
        durations = {key: float(row[key]) for key in online_fields + ('training_ms', 'baseline_ms')}
        if not all(math.isfinite(value) and value >= 0 for value in durations.values()):
            raise ValueError('Durations must be finite and nonnegative.')
        attempt = sum(durations[key] for key in online_fields)
        if attempt <= 0 or durations['predict_ms'] <= 0 or durations['baseline_ms'] <= 0:
            raise ValueError('Attempt, prediction, and baseline times must be positive.')
        residual = float(row['residual'])
        if math.isfinite(residual) and residual < 0:
            raise ValueError('Residual must be nonnegative.')
        attempt_times.append(attempt)
        inference_speedups.append(durations['baseline_ms'] / durations['predict_ms'])
        if math.isfinite(residual) and residual <= limit:
            qualified_speedups.append(durations['baseline_ms'] / attempt)
    qualified_speed = median(qualified_speedups) if qualified_speedups else None
    if not qualified_speedups:
        claim = 'no_qualified_speedup'
    elif len(qualified_speedups) < len(rows):
        claim = 'accuracy_limited'
    elif qualified_speed > 1:
        claim = 'faster'
    else:
        claim = 'slower_or_equal'
    return {
        'attempted': len(rows),
        'qualified': len(qualified_speedups),
        'median_attempt_ms': median(attempt_times),
        'median_qualified_speedup': qualified_speed,
        'median_inference_speedup': median(inference_speedups),
        'baseline_contract': 'baseline_ms must cover the same output and residual tolerance as the full online attempt; this is not verified by the supplied data.',
        'claim': claim,
    }

def main():
    directory = Path(__file__).resolve().parent
    rows = json.loads((directory / 'timings.json').read_text())
    policy = json.loads((directory / 'policy.json').read_text())
    report = summarize(rows, policy)
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
