# Learned-solver runtime audit

The results do not support a full runtime speedup claim.

- Attempted cases: 4.
- Cases that meet the residual limit: 3.
- Median full online attempt time: 21 ms.
- Median qualified speedup: 0.5454545454545454.
- Median inference-only speedup: 4.75.
- Claim label: accuracy_limited.

Case 1 has residual 0.001 and fails the required limit of 1e-06.
All four cases remain in the attempt time calculation. Only cases that meet
the residual limit enter the qualified speedup calculation. No inputs changed.

The available context has only incidental display updates. It does not state
the earlier timing method. The implemented method is an explicit assumption:
sum load, prediction, correction, verification, and output times for each online
attempt. Exclude offline training from that sum. Compute each speedup as baseline
time divided by the corresponding attempt time. Report the median of those
ratios. Inference-only speedup uses prediction time alone and includes all cases.

The claim is no_qualified_speedup if no case meets the accuracy limit. It is
accuracy_limited if only some cases meet the limit. If all cases meet the limit,
it is faster when the median full speedup exceeds 1, or slower_or_equal otherwise.

Five local tests passed. They check all online costs, accuracy coverage, separate
training cost, failed and nonfinite residuals, all claim branches, inclusive
limits, and report output. main() ran during the tests and wrote report.json.

Run from this directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_study
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B study.py
```

Limits: The baseline must produce the same output and meet the same residual
tolerance as the full online attempt. The supplied rows do not verify this
contract. Four timing rows do not establish timing variance or general coverage.
Training takes 100000 ms in each supplied row. The data do not establish whether
these entries refer to one shared training run or separate runs. They cannot
support a training amortization estimate. No fallback cost is supplied.

Next action: Verify the baseline output and accuracy contract. Then repeat the
timing measurements, include failed-case handling, and record the training scope.
