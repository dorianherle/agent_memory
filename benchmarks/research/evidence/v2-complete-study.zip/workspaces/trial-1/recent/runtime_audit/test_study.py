import json
from pathlib import Path
import unittest
from study import summarize, main


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        directory = Path(__file__).resolve().parent
        self.rows = json.loads((directory / 'timings.json').read_text())
        self.policy = json.loads((directory / 'policy.json').read_text())

    def test_current_coverage_and_full_cost(self):
        report = summarize(self.rows, self.policy)
        self.assertEqual(report['attempted'], 4)
        self.assertEqual(report['qualified'], 3)
        self.assertEqual(report['median_attempt_ms'], 21)
        self.assertAlmostEqual(report['median_qualified_speedup'], 12 / 22)
        self.assertEqual(report['median_inference_speedup'], 4.75)
        self.assertEqual(report['claim'], 'accuracy_limited')

    def test_training_is_separate(self):
        changed = [dict(row, training_ms=0) for row in self.rows]
        self.assertEqual(summarize(changed, self.policy), summarize(self.rows, self.policy))

    def test_no_passes_and_nonfinite_residual(self):
        rows = [dict(row, residual=float('nan')) for row in self.rows]
        report = summarize(rows, self.policy)
        self.assertEqual(report['qualified'], 0)
        self.assertIsNone(report['median_qualified_speedup'])
        self.assertEqual(report['claim'], 'no_qualified_speedup')
        self.assertEqual(report['median_attempt_ms'], 21)

    def test_all_pass_claims_and_inclusive_limit(self):
        rows = [dict(row, residual=self.policy['residual_limit']) for row in self.rows]
        self.assertEqual(summarize(rows, self.policy)['claim'], 'slower_or_equal')
        faster = [dict(row, baseline_ms=100) for row in rows]
        self.assertEqual(summarize(faster, self.policy)['claim'], 'faster')

    def test_main_writes_report(self):
        result = main()
        self.assertEqual(result, json.loads(Path(__file__).with_name('report.json').read_text()))


if __name__ == '__main__':
    unittest.main()
