# Electromagnetic field assessment

The current field fails the limit.

- Field error: 1.414213562373095.
- Required error: at most 0.15.
- Qualified: false.

The two predicted components have the correct magnitudes. The second component
has reversed phase. This is a relative phase error and remains in the result.
No input files were changed.

The available context has only incidental display updates. It does not state
the earlier field metric. The implemented metric is an explicit assumption:
relative complex L2 error after one common phase adjustment for the entire
vector. The adjustment does not change component amplitudes or relative phase.
For a zero reference norm, the denominator has a floor of 1e-15. This keeps
the result finite for ordinary finite input values. The floor is a numerical
convention, not a physical tolerance.

Six local tests passed. They check a common phase offset, opposing component
phases, amplitude errors, zero fields, invalid inputs, and report output.
main() ran during the tests and wrote report.json.

Run from this directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_study
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B study.py
```

Limits: The supplied two-component vector cannot establish spatial convergence
or physical accuracy. The metric uses equal component weights. A common phase
offset is treated as arbitrary. Invalid or numerically overflowing inputs are
rejected. A zero reference requires a separate physical error policy.

Next action: Confirm that a common phase adjustment is permitted. Correct the
relative phase error, then repeat this assessment with the full field data.
