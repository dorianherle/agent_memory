import json
import math
from pathlib import Path

def field_error(predicted, reference):
    """Relative complex L2 error after one common phase adjustment.

    One phase offset is allowed for the whole field. Relative component phase
    and amplitude errors remain in the result. A 1e-15 denominator floor gives
    finite values for zero reference fields.
    """
    if getattr(predicted, 'ndim', 1) != 1 or getattr(reference, 'ndim', 1) != 1:
        raise ValueError('Fields must be one-dimensional.')
    predicted = [complex(value) for value in predicted]
    reference = [complex(value) for value in reference]
    if len(predicted) != len(reference) or not predicted:
        raise ValueError('Fields must have equal, nonzero lengths.')
    if not all(math.isfinite(z.real) and math.isfinite(z.imag) for z in predicted + reference):
        raise ValueError('Fields must contain finite values.')
    norm_reference = math.hypot(*(abs(value) for value in reference))
    scale = max(*(abs(value) for value in predicted + reference), 1e-15)
    overlap = sum((p / scale).conjugate() * (r / scale) for p, r in zip(predicted, reference))
    phase = overlap / abs(overlap) if overlap else 1.0
    difference = math.hypot(*(abs(phase * p - r) for p, r in zip(predicted, reference)))
    result = difference / max(norm_reference, 1e-15)
    if not math.isfinite(result):
        raise ValueError('Field error exceeds the finite numerical range.')
    return result

def main():
    directory = Path(__file__).resolve().parent
    fields = json.loads((directory / 'fields.json').read_text())
    policy = json.loads((directory / 'policy.json').read_text())
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('Field error limit must be finite and nonnegative.')
    error = field_error(
        [complex(real, imag) for real, imag in fields['predicted']],
        [complex(real, imag) for real, imag in fields['reference']],
    )
    report = {'field_error': error, 'qualified': bool(error <= limit)}
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
