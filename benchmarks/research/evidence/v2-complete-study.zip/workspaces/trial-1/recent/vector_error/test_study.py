import cmath
import json
import math
from pathlib import Path
import unittest
from study import field_error, main


class FieldTests(unittest.TestCase):
    def test_common_phase_is_removed(self):
        reference = [1 + 2j, -3 + 1j]
        predicted = [value * cmath.exp(0.7j) for value in reference]
        self.assertLess(field_error(predicted, reference), 1e-14)

    def test_relative_phase_is_retained(self):
        self.assertAlmostEqual(field_error([1, -1], [1, 1]), math.sqrt(2))

    def test_amplitude_error_is_retained(self):
        self.assertAlmostEqual(field_error([2, 2j], [1, 1j]), 1)

    def test_zero_fields_are_finite(self):
        self.assertEqual(field_error([0], [0]), 0)
        self.assertTrue(math.isfinite(field_error([1], [0])))

    def test_invalid_fields_are_rejected(self):
        for predicted, reference in (([], []), ([1, 2], [1]), ([math.nan], [1])):
            with self.assertRaises(ValueError):
                field_error(predicted, reference)

    def test_main_reports_failure(self):
        result = main()
        self.assertAlmostEqual(result['field_error'], math.sqrt(2))
        self.assertFalse(result['qualified'])
        self.assertEqual(result, json.loads(Path(__file__).with_name('report.json').read_text()))


if __name__ == '__main__':
    unittest.main()
