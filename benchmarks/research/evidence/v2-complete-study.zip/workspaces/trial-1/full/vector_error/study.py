import json
import math
from pathlib import Path

import numpy as np


def _unit_vector(values):
    try:
        values = np.asarray(values, dtype=np.complex128)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Input must be a complex vector') from exc
    if values.ndim != 1 or values.size == 0:
        raise ValueError('Input must be a nonempty one-dimensional vector')
    if not np.all(np.isfinite(values)):
        raise ValueError('Vector components must be finite')
    # Scale before the norm to avoid overflow or underflow.
    scale = max(np.max(np.abs(values.real)), np.max(np.abs(values.imag)))
    if scale == 0:
        raise ValueError('Vector norm must be nonzero')
    scaled = values.real / scale + 1j * (values.imag / scale)
    return scaled / np.linalg.norm(scaled)


def field_error(predicted, reference):
    predicted = _unit_vector(predicted)
    reference = _unit_vector(reference)
    if predicted.size != reference.size:
        raise ValueError('Vector lengths must be equal')
    overlap = np.vdot(reference, predicted)
    if abs(overlap) > 0:
        predicted = predicted * (overlap.conjugate() / abs(overlap))
    error = float(np.linalg.norm(predicted - reference))
    if not math.isfinite(error):
        raise ValueError('Field error must be finite')
    return error


def _decode(pairs):
    try:
        values = np.asarray(pairs, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Fields must contain real and imaginary pairs') from exc
    if values.ndim != 2 or values.shape[1] != 2:
        raise ValueError('Fields must contain real and imaginary pairs')
    return values[:, 0] + 1j * values[:, 1]


def main():
    base = Path(__file__).resolve().parent
    fields = json.loads((base / 'fields.json').read_text())
    policy = json.loads((base / 'policy.json').read_text())
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('Field error limit must be finite and nonnegative')
    error = field_error(_decode(fields['predicted']), _decode(fields['reference']))
    report = {'field_error': error, 'qualified': error <= limit}
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
