Finish the electromagnetic field assessment in study.py. Implement field_error(predicted, reference) and main(). Inputs to field_error are one-dimensional complex arrays. main reads fields.json and policy.json and writes report.json with field_error and qualified.

Continue from context.txt. Check the current data. Write a short HANDOFF.md with the result, tests, limits, and next action.

Common API contract: field_error(predicted, reference) returns a finite
nonnegative number. Inputs are complex one-dimensional vectors. main() reads
[real, imag] pairs from fields.json and writes field_error (number) and qualified
(boolean) to report.json. Policy contains field_error_limit. Recover the
research method from the available context.
