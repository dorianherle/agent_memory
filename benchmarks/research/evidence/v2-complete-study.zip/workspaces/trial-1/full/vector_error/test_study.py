import math
import unittest

import numpy as np

from study import field_error


class FieldTests(unittest.TestCase):
    def test_global_scale_and_phase_are_removed(self):
        reference = np.array([1 + 2j, -3j, 0.5])
        for scale in (2j, -3, 1e-300 * (1 + 1j), 1e300 * (1 - 1j)):
            with self.subTest(scale=scale):
                self.assertLess(field_error(scale * reference, reference), 1e-14)

    def test_relative_phase_is_retained(self):
        self.assertAlmostEqual(field_error([1, -1], [1, 1]), math.sqrt(2))

    def test_missing_component_is_retained(self):
        self.assertAlmostEqual(field_error([1, 0], [1, 1]),
                               math.sqrt(2 - math.sqrt(2)))

    def test_relative_amplitude_is_retained(self):
        self.assertGreater(field_error([1, 3], [1, 1]), 0.4)

    def test_symmetry(self):
        a, b = [1 + 2j, -3j], [1, 1j]
        self.assertAlmostEqual(field_error(a, b), field_error(b, a))

    def test_extreme_finite_components(self):
        for vector in ([1e-320 + 1e-320j], [1.7e308 + 1.7e308j]):
            self.assertLess(field_error(vector, [1j]), 1e-14)

    def test_invalid_vectors(self):
        cases = [([], []), ([0, 0], [1, 1]), ([1], [1, 2]),
                 ([[1, 2]], [1, 2]), ([1], [[1]]),
                 ([math.inf], [1]), ([1], [complex(0, math.nan)])]
        for predicted, reference in cases:
            with self.subTest(predicted=predicted, reference=reference):
                with self.assertRaises(ValueError):
                    field_error(predicted, reference)


if __name__ == '__main__':
    unittest.main()
