# Complex field assessment

The current field fails the policy limit. The field error is
1.4142135623730947. The limit is 0.15. `report.json` contains
`qualified: false`.

Each complete vector is normalized to unit L2 norm. One complex phase is
then applied to the complete predicted vector. The error is the L2 norm
of the resulting difference. The same phase applies to every component.

The supplied reference is `[1, 1]`. The prediction is approximately `[1, -1]`.
Their magnitudes agree, but their relative phases do not agree. A global
phase cannot remove this difference. The failed result is retained.

Tests: Run the supplied Python interpreter with `-B -m unittest -v test_study`.
All seven tests passed. They check global scale and phase, relative phase,
missing components, relative amplitude, symmetry, extreme finite values,
and invalid inputs. The actual `main()` run wrote `report.json` without an error.

Limit: This metric excludes global amplitude and phase by design. It does
not check absolute power. The supplied data contain two components only.
The implementation requires NumPy, which is available in the supplied environment.

Next action: Check the cause of the relative phase reversal in the prediction.
Repeat this assessment after a corrected field is available.
