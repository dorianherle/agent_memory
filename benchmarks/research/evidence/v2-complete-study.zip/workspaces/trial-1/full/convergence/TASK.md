Finish the cavity convergence study in study.py. Implement assess(records, config) and main(). main writes report.json. Keep the numerical measurements separate from the analytical reference.

Continue from context.txt. Check the current data. Write a short HANDOFF.md with the result, tests, limits, and next action.

Common API contract: assess(records, config) returns a dictionary with
observed_order (number), extrapolated (number), relative_error (number), and
qualified (boolean). main() writes these fields to report.json. Records contain
intervals, length, and eigenvalue. Config contains length, tolerance, order_min,
and order_max. Recover the research method from the available context.
