# Cavity convergence study

The current result passes the specified limits. The current length is 1.2.
The old samples had length 1.0. `main()` ran the supplied `measure.py` and
then read the new samples. All four new samples have length 1.2.

The three finest grids have 32, 64, and 128 intervals. The observed order is
1.9995654545089394. The Richardson estimate is 6.853892055765409.
Its relative error is 1.6131632366384717e-8. The order limits are 1.8 and 2.2.
The error limit is 1e-6. `report.json` contains `qualified: true`.

The calculation uses measured values for the order and extrapolation.
The analytical value, `(pi / length)**2`, is used only for the error check.

Tests: Run the supplied Python interpreter with `-B -m unittest -v test_study`.
All seven tests passed. They check order, the analytical error, invalid inputs,
the three finest grids, and regeneration of samples for an old geometry.
The regeneration test uses mocks. The actual `main()` run also regenerated
the samples and wrote `report.json` without an error.

Limit: The supplied tool computes a discrete cavity eigenvalue. This result
does not validate a physical device or another geometry. The qualification
applies only to the current configuration and supplied measurement method.

Next action: Obtain independent measurements if physical validation is needed.
Run `main()` again after any configuration or sample change.
