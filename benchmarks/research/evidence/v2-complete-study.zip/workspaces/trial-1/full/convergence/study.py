import json
import math
import subprocess
import sys
from pathlib import Path


def _positive(value, name):
    if isinstance(value, bool):
        raise ValueError(f'{name} must be a finite positive number')
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be a finite positive number') from exc
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f'{name} must be a finite positive number')
    return value


def _config(config):
    try:
        values = {key: _positive(config[key], key)
                  for key in ('length', 'tolerance', 'order_min', 'order_max')}
    except (KeyError, TypeError) as exc:
        raise ValueError('Config is missing a required field') from exc
    if values['order_min'] > values['order_max']:
        raise ValueError('Order bounds are reversed')
    return values


def assess(records, config):
    cfg = _config(config)
    records = list(records)
    if len(records) < 3:
        raise ValueError('At least three records are required')
    measured = []
    for record in records:
        try:
            n = _positive(record['intervals'], 'intervals')
            length = _positive(record['length'], 'length')
            eigenvalue = _positive(record['eigenvalue'], 'eigenvalue')
        except (KeyError, TypeError) as exc:
            raise ValueError('Record is missing a required field') from exc
        if not n.is_integer():
            raise ValueError('Intervals must be a positive integer')
        if length != cfg['length']:
            raise ValueError('All geometry lengths must equal the config length')
        measured.append((n, eigenvalue))
    measured.sort()
    coarse, middle, fine = measured[-3:]
    if middle[0] != 2 * coarse[0] or fine[0] != 2 * middle[0]:
        raise ValueError('The three finest grids must double at each refinement')
    first = abs(coarse[1] - middle[1])
    second = abs(middle[1] - fine[1])
    if first == 0 or second == 0:
        raise ValueError('Grid differences must be nonzero')
    order = math.log2(first) - math.log2(second)
    if not math.isfinite(order) or order <= 0:
        raise ValueError('Observed order must be finite and positive')
    try:
        denominator = math.expm1(order * math.log(2))
        extrapolated = fine[1] + (fine[1] - middle[1]) / denominator
        reference = (math.pi / cfg['length']) ** 2
        relative_error = abs(extrapolated - reference) / reference
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError('Calculation exceeds the finite numerical range') from exc
    if not all(math.isfinite(v) for v in (extrapolated, reference, relative_error)):
        raise ValueError('Calculation must give finite results')
    return {'observed_order': order, 'extrapolated': extrapolated,
            'relative_error': relative_error,
            'qualified': (cfg['order_min'] <= order <= cfg['order_max']
                          and relative_error <= cfg['tolerance'])}


def main():
    base = Path(__file__).resolve().parent
    config = json.loads((base / 'config.json').read_text())
    cfg = _config(config)
    records = json.loads((base / 'samples.json').read_text())
    if any(record['length'] != cfg['length'] for record in records):
        subprocess.run([sys.executable, str(base / 'measure.py')],
                       cwd=base, check=True)
        records = json.loads((base / 'samples.json').read_text())
    report = assess(records, config)
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
