import copy
import json
import math
import unittest
from pathlib import Path
from unittest.mock import patch

import study


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        self.config = {'length': 1.2, 'tolerance': 1e-6,
                       'order_min': 1.8, 'order_max': 2.2}

    def records(self, order=2, shift=0):
        exact = (math.pi / 1.2) ** 2 + shift
        return [{'intervals': n, 'length': 1.2,
                 'eigenvalue': exact + 0.01 / n ** order}
                for n in (16, 32, 64, 128)]

    def test_second_order_and_unsorted_input(self):
        result = study.assess(list(reversed(self.records())), self.config)
        self.assertAlmostEqual(result['observed_order'], 2, places=7)
        self.assertTrue(result['qualified'])

    def test_first_order_fails_despite_good_reference_agreement(self):
        result = study.assess(self.records(1), self.config)
        self.assertLess(result['relative_error'], self.config['tolerance'])
        self.assertAlmostEqual(result['observed_order'], 1)
        self.assertFalse(result['qualified'])

    def test_reference_is_not_substituted(self):
        result = study.assess(self.records(2, 0.1), self.config)
        self.assertGreater(result['relative_error'], 0.01)
        self.assertFalse(result['qualified'])

    def test_only_finest_three_are_used_for_order(self):
        records = self.records()
        records[0]['eigenvalue'] += 20
        self.assertTrue(study.assess(records, self.config)['qualified'])

    def test_invalid_records(self):
        cases = [self.records()[:2]]
        for key, value in [('intervals', 0), ('intervals', 63),
                           ('length', 1), ('eigenvalue', math.inf),
                           ('eigenvalue', -1)]:
            rows = self.records()
            rows[-1][key] = value
            cases.append(rows)
        zero = self.records()
        zero[-1]['eigenvalue'] = zero[-2]['eigenvalue']
        cases.append(zero)
        nonpositive = self.records()
        for row, value in zip(nonpositive[-3:], (1, 2, 4)):
            row['eigenvalue'] = value
        cases.append(nonpositive)
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                study.assess(rows, self.config)

    def test_invalid_config(self):
        for key in self.config:
            cfg = copy.deepcopy(self.config)
            cfg[key] = math.nan
            with self.subTest(key=key), self.assertRaises(ValueError):
                study.assess(self.records(), cfg)

    def test_stale_geometry_runs_measurement_and_reloads(self):
        base = Path(study.__file__).resolve().parent
        old = self.records()
        for row in old:
            row['length'] = 1
        state = {'samples': old}

        def read(path):
            return json.dumps(self.config if path.name == 'config.json'
                              else state['samples'])

        def regenerate(*args, **kwargs):
            self.assertEqual(kwargs['cwd'], base)
            self.assertTrue(kwargs['check'])
            state['samples'] = self.records()

        with patch.object(Path, 'read_text', read):
            with patch.object(Path, 'write_text') as write:
                with patch.object(study.subprocess, 'run', side_effect=regenerate) as run:
                    result = study.main()
                    run.assert_called_once()
                self.assertEqual(json.loads(write.call_args.args[0]), result)
        self.assertTrue(result['qualified'])


if __name__ == '__main__':
    unittest.main()
