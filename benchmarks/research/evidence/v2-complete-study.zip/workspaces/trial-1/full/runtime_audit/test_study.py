import math
import unittest

from study import summarize


def row(**changes):
    result = dict(load_ms=2, predict_ms=1, correct_ms=8, verify_ms=4,
                  output_ms=3, training_ms=100000, baseline_ms=10,
                  residual=1e-8)
    result.update(changes)
    return result


class RuntimeTests(unittest.TestCase):
    policy = {'residual_limit': 1e-6}

    def test_full_time_is_slower_despite_fast_inference(self):
        result = summarize([row()], self.policy)
        self.assertEqual(result['median_attempt_ms'], 18)
        self.assertEqual(result['median_inference_speedup'], 10)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10 / 18)
        self.assertEqual(result['claim'], 'slower_or_equal')
        self.assertEqual(result['baseline_contract'], 'construction_only')

    def test_failed_output_is_not_a_speed_win(self):
        result = summarize([row(), row(baseline_ms=10000, residual=1)], self.policy)
        self.assertEqual(result['attempted'], 2)
        self.assertEqual(result['qualified'], 1)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10 / 18)
        self.assertEqual(result['claim'], 'accuracy_limited')

    def test_no_qualified_output(self):
        result = summarize([row(residual=1)], self.policy)
        self.assertIsNone(result['median_qualified_speedup'])
        self.assertEqual(result['claim'], 'no_qualified_speedup')

    def test_faster_and_exact_threshold(self):
        result = summarize([row(baseline_ms=100, residual=1e-6)], self.policy)
        self.assertEqual(result['claim'], 'faster')
        self.assertEqual(result['qualified'], 1)

    def test_training_is_excluded(self):
        self.assertEqual(summarize([row(training_ms=0)], self.policy),
                         summarize([row(training_ms=1e200)], self.policy))

    def test_missing_and_invalid_values(self):
        cases = [[]]
        missing = row()
        del missing['verify_ms']
        cases.append([missing])
        for key in row():
            cases.extend([[row(**{key: -1})], [row(**{key: math.nan})]])
        for key in ('predict_ms', 'baseline_ms'):
            cases.append([row(**{key: 0})])
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                summarize(rows, self.policy)

    def test_invalid_policy(self):
        for limit in (0, -1, math.inf, math.nan):
            with self.subTest(limit=limit), self.assertRaises(ValueError):
                summarize([row()], {'residual_limit': limit})


if __name__ == '__main__':
    unittest.main()
