# Learned-solver runtime audit

Three of four attempts pass the residual limit of 1e-6. Matrix 1 fails:
its residual is 0.001. The report claim is `accuracy_limited`.

Full attempt times are 18, 20, 22, and 24 ms. Their median is 21 ms.
Each time includes loading, prediction, correction, verification, and output.
Offline training is excluded. The baseline contract is `construction_only`.

The median full speed ratio for the three accurate outputs is
0.5454545454545454. A ratio below one means that the candidate is slower.
The median inference-only speed ratio for all attempts is 4.75.
This inference result does not establish a full construction speed improvement.
The failed case remains in the attempted count and full-time median.
It is excluded from the qualified speed ratio.

Tests: Run the supplied Python interpreter with `-B -m unittest -v test_study`.
All seven tests passed. They check full timing, failure coverage, all claim
branches, the residual threshold, training exclusion, and invalid inputs.
The actual `main()` run wrote `report.json` without an error.

Limit: These are four supplied timing records. This audit does not measure
new runtimes, include offline training cost, or test reusable solves.
The supplied reference times cover inverse construction only.

Next action: Correct the failed output. Then repeat the full construction
benchmark with more matrices and the same residual limit.
