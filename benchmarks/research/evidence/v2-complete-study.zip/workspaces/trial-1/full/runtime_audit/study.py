import json
import math
from pathlib import Path
from statistics import median


def _number(value, name):
    if isinstance(value, bool):
        raise ValueError(f'{name} must be a finite nonnegative number')
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be a finite nonnegative number') from exc
    if not math.isfinite(value) or value < 0:
        raise ValueError(f'{name} must be a finite nonnegative number')
    return value


def summarize(rows, policy):
    try:
        limit = _number(policy['residual_limit'], 'residual_limit')
    except (KeyError, TypeError) as exc:
        raise ValueError('Policy must contain residual_limit') from exc
    if limit == 0:
        raise ValueError('Residual limit must be positive')
    rows = list(rows)
    if not rows:
        raise ValueError('At least one row is required')
    attempt_times, qualified_speedups, inference_speedups = [], [], []
    fields = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms',
              'output_ms', 'training_ms', 'baseline_ms', 'residual')
    for row in rows:
        try:
            values = {key: _number(row[key], key) for key in fields}
        except (KeyError, TypeError) as exc:
            raise ValueError('Row is missing a required field') from exc
        full_ms = sum(values[key] for key in fields[:5])
        if (not math.isfinite(full_ms) or full_ms <= 0
                or values['predict_ms'] <= 0 or values['baseline_ms'] <= 0):
            raise ValueError('Full, prediction, and baseline times must be finite and positive')
        inference = values['baseline_ms'] / values['predict_ms']
        speedup = values['baseline_ms'] / full_ms
        if not math.isfinite(inference) or not math.isfinite(speedup):
            raise ValueError('Speed ratios must be finite')
        attempt_times.append(full_ms)
        inference_speedups.append(inference)
        if values['residual'] <= limit:
            qualified_speedups.append(speedup)
    qualified = len(qualified_speedups)
    qualified_median = median(qualified_speedups) if qualified else None
    if qualified == 0:
        claim = 'no_qualified_speedup'
    elif qualified < len(rows):
        claim = 'accuracy_limited'
    elif qualified_median > 1:
        claim = 'faster'
    else:
        claim = 'slower_or_equal'
    return {'attempted': len(rows), 'qualified': qualified,
            'median_attempt_ms': median(attempt_times),
            'median_qualified_speedup': qualified_median,
            'median_inference_speedup': median(inference_speedups),
            'baseline_contract': 'construction_only', 'claim': claim}


def main():
    base = Path(__file__).resolve().parent
    rows = json.loads((base / 'timings.json').read_text())
    policy = json.loads((base / 'policy.json').read_text())
    report = summarize(rows, policy)
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
