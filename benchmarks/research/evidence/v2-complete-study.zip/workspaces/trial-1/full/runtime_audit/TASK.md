Finish the learned-solver runtime audit in study.py. Implement summarize(rows, policy) and main(). main reads timings.json and policy.json and writes report.json. Keep accuracy coverage and speed separate.

Continue from context.txt. Check the current data. Write a short HANDOFF.md with the result, tests, limits, and next action.

Common API contract: summarize(rows, policy) returns a dictionary with
attempted (integer), qualified (integer), median_attempt_ms (number),
median_qualified_speedup (number or null), median_inference_speedup (number),
baseline_contract (string), and claim (string). main() writes these fields to
report.json. Rows contain load_ms, predict_ms, correct_ms, verify_ms, output_ms,
training_ms, baseline_ms, and residual. matrix_id is optional metadata. Policy
contains residual_limit. Valid claim labels are no_qualified_speedup,
accuracy_limited, faster, and slower_or_equal. Recover the timing and accuracy
method from the available context.
