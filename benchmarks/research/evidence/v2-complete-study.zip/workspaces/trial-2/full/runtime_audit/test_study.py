import unittest

import study


class RuntimeTests(unittest.TestCase):
    def row(self, **updates):
        result = dict(load_ms=2, predict_ms=1, correct_ms=8, verify_ms=4, output_ms=3,
                      training_ms=100000, baseline_ms=10, residual=1e-8)
        result.update(updates)
        return result

    def summarize(self, rows):
        return study.summarize(rows, {'residual_limit': 1e-6})

    def test_full_cost_and_offline_training(self):
        result = self.summarize([self.row()])
        self.assertEqual(result['median_attempt_ms'], 18)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10/18)
        self.assertEqual(result['median_inference_speedup'], 10)
        self.assertEqual(result['baseline_contract'], 'construction_only')
        self.assertEqual(result['claim'], 'slower_or_equal')
        self.assertEqual(result, self.summarize([self.row(training_ms=0)]))

    def test_failed_output_is_not_a_speed_win(self):
        result = self.summarize([self.row(), self.row(baseline_ms=1000, residual=1e-3)])
        self.assertEqual(result['attempted'], 2)
        self.assertEqual(result['qualified'], 1)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10/18)
        self.assertEqual(result['claim'], 'accuracy_limited')

    def test_no_qualified_and_faster(self):
        result = self.summarize([self.row(residual=1e-3)])
        self.assertIsNone(result['median_qualified_speedup'])
        self.assertEqual(result['claim'], 'no_qualified_speedup')
        self.assertEqual(self.summarize([self.row(baseline_ms=36)])['claim'], 'faster')

    def test_policy_boundary_and_medians(self):
        result = self.summarize([self.row(residual=1e-6), self.row(predict_ms=3)])
        self.assertEqual(result['qualified'], 2)
        self.assertEqual(result['median_attempt_ms'], 19)
        self.assertAlmostEqual(result['median_qualified_speedup'], (10/18 + 10/20)/2)

    def test_invalid_rows(self):
        rows = [[], [{}]]
        for key, value in [('predict_ms', 0), ('baseline_ms', 0), ('load_ms', -1),
                           ('residual', float('inf')), ('training_ms', float('nan'))]:
            rows.append([self.row(**{key: value})])
        for example in rows:
            with self.subTest(rows=example), self.assertRaises(ValueError):
                self.summarize(example)
        for value in (0, -1, float('nan')):
            with self.subTest(limit=value), self.assertRaises(ValueError):
                study.summarize([self.row()], {'residual_limit': value})


if __name__ == '__main__':
    unittest.main()
