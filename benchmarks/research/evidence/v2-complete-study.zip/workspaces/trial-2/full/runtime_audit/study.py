import json
import math
from pathlib import Path
from statistics import median

def summarize(rows, policy):
    fields = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms',
              'training_ms', 'baseline_ms', 'residual')
    try:
        limit = float(policy['residual_limit'])
        if not math.isfinite(limit) or limit <= 0:
            raise ValueError('Residual limit must be finite and positive')
        rows = list(rows)
        if not rows:
            raise ValueError('At least one timing row is required')
        attempts, speedups, inference_speedups = [], [], []
        for row in rows:
            values = {key: float(row[key]) for key in fields}
            if any(not math.isfinite(v) or v < 0 for v in values.values()):
                raise ValueError('Timing and residual values must be finite and nonnegative')
            full_ms = sum(values[key] for key in fields[:5])
            if not math.isfinite(full_ms) or min(full_ms, values['predict_ms'], values['baseline_ms']) <= 0:
                raise ValueError('Full, prediction, and baseline times must be finite and positive')
            inference = values['baseline_ms'] / values['predict_ms']
            full_speedup = values['baseline_ms'] / full_ms
            if not math.isfinite(inference) or not math.isfinite(full_speedup):
                raise ValueError('Speed ratios must be finite')
            attempts.append(full_ms)
            inference_speedups.append(inference)
            if values['residual'] <= limit:
                speedups.append(full_speedup)
    except (KeyError, TypeError, OverflowError) as exc:
        raise ValueError('Missing or invalid timing or policy fields') from exc
    qualified_speedup = median(speedups) if speedups else None
    if not speedups:
        claim = 'no_qualified_speedup'
    elif len(speedups) < len(rows):
        claim = 'accuracy_limited'
    else:
        claim = 'faster' if qualified_speedup > 1 else 'slower_or_equal'
    return {
        'attempted': len(rows),
        'qualified': len(speedups),
        'median_attempt_ms': median(attempts),
        'median_qualified_speedup': qualified_speedup,
        'median_inference_speedup': median(inference_speedups),
        'baseline_contract': 'construction_only',
        'claim': claim,
    }

def main():
    base = Path(__file__).resolve().parent
    rows = json.loads((base / 'timings.json').read_text())
    policy = json.loads((base / 'policy.json').read_text())
    report = summarize(rows, policy)
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
