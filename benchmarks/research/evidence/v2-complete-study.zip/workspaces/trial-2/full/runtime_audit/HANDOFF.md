# Runtime study

Result: four attempts are recorded. Three meet the residual limit of 1e-6. Case 2 has residual 0.001 and fails. The claim is accuracy_limited.

The full attempt times are 18, 20, 22, and 24 ms. Their median is 21 ms. The median qualified full speed ratio is 0.55. This ratio is below one. The median inference-only speed ratio over all attempts is 4.75. Failed outputs are excluded from the qualified full speed ratio.

Method: full construction time includes loading, prediction, correction, verification, and output. Training is offline and excluded. The reference time measures inverse construction only. baseline_contract is construction_only. Keep accuracy coverage separate from speed.

Tests: all five tests in test_study.py passed. They check full cost, offline training, failed outputs, all claim labels, the accuracy boundary, medians, and invalid inputs. main() completed and wrote report.json.

Limits: only four recorded cases are available. There are no repeated measurements or uncertainty estimates. The inference-only ratio does not establish faster full construction. These records do not support a reusable-solve claim.

Next action: correct the failed case and reduce correction and verification costs. Then repeat the full construction measurements under the same reference contract.

Run: PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -m unittest -v test_study.py
