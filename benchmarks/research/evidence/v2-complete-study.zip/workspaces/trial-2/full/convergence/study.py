import json
import math
import subprocess
import sys
from pathlib import Path

def _positive(value, name):
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be a finite positive number') from exc
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f'{name} must be a finite positive number')
    return value

def assess(records, config):
    try:
        length = _positive(config['length'], 'length')
        tolerance = _positive(config['tolerance'], 'tolerance')
        order_min = _positive(config['order_min'], 'order_min')
        order_max = _positive(config['order_max'], 'order_max')
        rows = list(records)
        if len(rows) < 3 or order_min > order_max:
            raise ValueError('Use at least three records and ordered order bounds')
        checked = []
        for row in rows:
            intervals = _positive(row['intervals'], 'intervals')
            geometry = _positive(row['length'], 'record length')
            eigenvalue = _positive(row['eigenvalue'], 'eigenvalue')
            if not intervals.is_integer() or geometry != length:
                raise ValueError('Use integer intervals and the current geometry length')
            checked.append((intervals, eigenvalue))
    except (KeyError, TypeError) as exc:
        raise ValueError('Missing or invalid configuration or record fields') from exc
    coarse, middle, fine = sorted(checked)[-3:]
    if middle[0] != 2 * coarse[0] or fine[0] != 2 * middle[0]:
        raise ValueError('The three finest grids must double')
    first = abs(coarse[1] - middle[1])
    second = abs(middle[1] - fine[1])
    if first == 0 or second == 0:
        raise ValueError('Successive differences must be nonzero')
    observed_order = math.log2(first) - math.log2(second)
    if not math.isfinite(observed_order) or observed_order <= 0:
        raise ValueError('Observed order must be finite and positive')
    try:
        denominator = math.expm1(observed_order * math.log(2))
        extrapolated = fine[1] + (fine[1] - middle[1]) / denominator
        analytical = (math.pi / length) ** 2
        relative_error = abs(extrapolated - analytical) / analytical
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError('The extrapolation is outside the numerical range') from exc
    if not all(math.isfinite(v) for v in (extrapolated, relative_error)):
        raise ValueError('The extrapolation must be finite')
    return {
        'observed_order': observed_order,
        'extrapolated': extrapolated,
        'relative_error': relative_error,
        'qualified': order_min <= observed_order <= order_max and relative_error <= tolerance,
    }

def main():
    base = Path(__file__).resolve().parent
    config = json.loads((base / 'config.json').read_text())
    length = _positive(config['length'], 'length')
    records = json.loads((base / 'samples.json').read_text())
    if any(row.get('length') != length for row in records):
        subprocess.run([sys.executable, str(base / 'measure.py')], cwd=base, check=True)
        records = json.loads((base / 'samples.json').read_text())
    report = assess(records, config)
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
