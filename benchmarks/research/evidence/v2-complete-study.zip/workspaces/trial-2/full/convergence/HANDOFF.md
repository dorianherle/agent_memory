# Cavity study

Result: qualified is true. The current length is 1.7. The old samples used length 1.0. main() ran the supplied measure.py and read the new samples before assessment.

The three finest grids have 32, 64, and 128 intervals. The observed order is 1.9995654545. The extrapolated eigenvalue is 3.41508808315. Its relative error against the separate analytical reference is 1.61316326638e-8. The order bounds are 1.8 to 2.2. The error limit is 1e-6.

Method: sort by intervals, use the three finest grids, check doubling, and calculate observed-order Richardson extrapolation. Do not replace the measured eigenvalues with the analytical reference. Invalid geometry and numerical inputs cause ValueError.

Tests: all six tests in test_study.py passed. They check second-order and first-order data, selection of the finest grids, invalid records, current geometry and policy, and measurement of stale samples. main() completed and wrote report.json.

Limits: the supplied measurement script calculates the discrete cavity eigenvalue. This result applies to its present geometry and grid sequence. It does not validate an independent cavity solver or other geometries.

Next action: use independent solver measurements with the same geometry and grid sequence before a wider validation claim.

Run: PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -m unittest -v test_study.py
