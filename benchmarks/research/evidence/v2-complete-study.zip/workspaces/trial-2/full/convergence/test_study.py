import math
import unittest
from unittest.mock import patch

import study


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        self.config = {'length': 1.7, 'tolerance': 1e-6, 'order_min': 1.8, 'order_max': 2.2}

    def rows(self, order=2):
        exact = (math.pi / self.config['length']) ** 2
        return [{'intervals': n, 'length': self.config['length'], 'eigenvalue': exact + 2 / n**order}
                for n in (16, 32, 64, 128)]

    def test_observed_order_and_reference(self):
        result = study.assess(self.rows()[::-1], self.config)
        self.assertAlmostEqual(result['observed_order'], 2, places=9)
        self.assertAlmostEqual(result['relative_error'], 0, places=12)
        self.assertTrue(result['qualified'])

    def test_first_order_does_not_qualify(self):
        result = study.assess(self.rows(order=1), self.config)
        self.assertAlmostEqual(result['observed_order'], 1, places=9)
        self.assertFalse(result['qualified'])

    def test_three_finest_only(self):
        rows = self.rows()
        rows[0]['eigenvalue'] = 999
        self.assertTrue(study.assess(rows, self.config)['qualified'])

    def test_bad_records(self):
        examples = [self.rows()[:2]]
        for key, value in [('intervals', 100), ('length', 1.0), ('eigenvalue', 0),
                           ('eigenvalue', float('nan')), ('intervals', 0)]:
            rows = self.rows()
            rows[-1][key] = value
            examples.append(rows)
        rows = self.rows()
        rows[-1]['eigenvalue'] = rows[-2]['eigenvalue']
        examples.append(rows)
        rows = self.rows()
        for row, value in zip(rows, (1, 2, 4, 8)):
            row['eigenvalue'] = value
        examples.append(rows)
        for rows in examples:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                study.assess(rows, self.config)

    def test_current_geometry_and_policy(self):
        rows = self.rows()
        config = dict(self.config, length=1)
        with self.assertRaises(ValueError):
            study.assess(rows, config)
        config = dict(self.config, tolerance=1e-12)
        for row in rows:
            row['eigenvalue'] += 1e-5
        self.assertFalse(study.assess(rows, config)['qualified'])

    def test_stale_main_runs_measurement(self):
        import json
        stale = self.rows()
        stale[0]['length'] = 1
        with patch.object(study.Path, 'read_text', side_effect=[json.dumps(self.config), json.dumps(stale), json.dumps(self.rows())]), \
             patch.object(study.subprocess, 'run') as run, \
             patch.object(study.Path, 'write_text'):
            self.assertTrue(study.main()['qualified'])
            run.assert_called_once()
            self.assertTrue(run.call_args.kwargs['check'])


if __name__ == '__main__':
    unittest.main()
