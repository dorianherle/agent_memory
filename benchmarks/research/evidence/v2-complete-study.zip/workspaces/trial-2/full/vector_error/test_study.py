import math
import unittest

import numpy as np

import study


class FieldTests(unittest.TestCase):
    def test_scale_and_global_phase(self):
        reference = np.array([1+2j, -3j, 4-1j])
        for factor in (3, -2j, 1e-300, 1e300):
            self.assertLess(study.field_error(factor * reference, reference), 1e-14)

    def test_relative_phase(self):
        self.assertAlmostEqual(study.field_error([1, 1j], [1, 1]), math.sqrt(2-math.sqrt(2)))

    def test_relative_amplitude(self):
        self.assertGreater(study.field_error([1, 0], [1, 1]), 0.7)

    def test_orthogonal_vectors(self):
        self.assertAlmostEqual(study.field_error([1, 0], [0, 1]), math.sqrt(2))

    def test_extreme_finite_values(self):
        for vector in ([1e-320, 1e-320j], [1e308+1e308j, 1e308]):
            self.assertLess(study.field_error(vector, vector), 1e-14)

    def test_invalid_vectors(self):
        for predicted, reference in [([], []), ([[1]], [1]), ([1, 2], [1]), ([0], [1]),
                                     ([1], [0]), ([float('nan')], [1]), ([1], [complex(1, float('inf'))])]:
            with self.subTest(predicted=predicted, reference=reference), self.assertRaises(ValueError):
                study.field_error(predicted, reference)


if __name__ == '__main__':
    unittest.main()
