import json
import math
from pathlib import Path

import numpy as np

def _unit_vector(values):
    try:
        vector = np.asarray(values, dtype=np.complex128)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Use a one-dimensional complex vector') from exc
    if vector.ndim != 1 or vector.size == 0 or not np.all(np.isfinite(vector)):
        raise ValueError('Use a nonempty finite one-dimensional vector')
    # Scale first to prevent overflow or underflow during normalization.
    scale = max(float(np.max(np.abs(vector.real))), float(np.max(np.abs(vector.imag))))
    if scale == 0:
        raise ValueError('Vector norm must be nonzero')
    vector = vector.real / scale + 1j * (vector.imag / scale)
    return vector / np.linalg.norm(vector)

def field_error(predicted, reference):
    predicted = _unit_vector(predicted)
    reference = _unit_vector(reference)
    if predicted.size != reference.size:
        raise ValueError('Vectors must have equal lengths')
    overlap = np.vdot(reference, predicted)
    phase = np.conj(overlap) / abs(overlap) if abs(overlap) > 0 else 1.0
    return float(np.linalg.norm(predicted * phase - reference))

def _decode(pairs):
    try:
        array = np.asarray(pairs, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Field records must contain real and imaginary pairs') from exc
    if array.ndim != 2 or array.shape[1] != 2:
        raise ValueError('Field records must contain real and imaginary pairs')
    return array[:, 0] + 1j * array[:, 1]

def main():
    base = Path(__file__).resolve().parent
    fields = json.loads((base / 'fields.json').read_text())
    policy = json.loads((base / 'policy.json').read_text())
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('Field error limit must be finite and nonnegative')
    error = field_error(_decode(fields['predicted']), _decode(fields['reference']))
    report = {'field_error': error, 'qualified': error <= limit}
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report

if __name__ == '__main__':
    main()
