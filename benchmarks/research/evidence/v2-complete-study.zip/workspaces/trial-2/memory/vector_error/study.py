import json
import math
from pathlib import Path

def unit_vector(values):
    if getattr(values, 'ndim', 1) != 1 or isinstance(values, (str, bytes)):
        raise ValueError('Need a one-dimensional complex vector')
    try:
        values = [complex(value) for value in values]
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Need a one-dimensional complex vector') from exc
    if not values or not all(math.isfinite(z.real) and math.isfinite(z.imag) for z in values):
        raise ValueError('Vector must be nonempty and finite')
    scale = max(max(abs(z.real), abs(z.imag)) for z in values)
    if scale == 0:
        raise ValueError('Zero vector has no normalized field')
    scaled = [complex(z.real/scale, z.imag/scale) for z in values]
    norm = math.hypot(*(part for z in scaled for part in (z.real, z.imag)))
    return [z/norm for z in scaled]

def field_error(predicted, reference):
    predicted, reference = unit_vector(predicted), unit_vector(reference)
    if len(predicted) != len(reference):
        raise ValueError('Vector lengths must agree')
    products = [p.conjugate()*r for p, r in zip(predicted, reference)]
    overlap = complex(math.fsum(z.real for z in products), math.fsum(z.imag for z in products))
    phase = overlap/abs(overlap) if overlap else 1.0
    difference = [phase*p-r for p, r in zip(predicted, reference)]
    return math.hypot(*(part for z in difference for part in (z.real, z.imag)))

def main():
    base = Path(__file__).resolve().parent
    fields = json.loads((base/'fields.json').read_text())
    policy = json.loads((base/'policy.json').read_text())
    predicted = [complex(real, imag) for real, imag in fields['predicted']]
    reference = [complex(real, imag) for real, imag in fields['reference']]
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('Field error limit must be finite and nonnegative')
    error = field_error(predicted, reference)
    report = dict(field_error=error, qualified=error <= limit)
    (base/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    return report

if __name__ == '__main__':
    main()
