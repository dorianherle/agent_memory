import math
import unittest
from study import field_error, main

class FieldTests(unittest.TestCase):
    def test_global_scale_and_phase(self):
        reference = [1+2j, -3+1j, 0.25-0.5j]
        for factor in [2j, -3, 1e-200*(1+1j), 1e200*(1-1j)]:
            with self.subTest(factor=factor):
                self.assertLess(field_error([factor*z for z in reference], reference), 1e-14)

    def test_relative_phase_and_missing_component(self):
        self.assertAlmostEqual(field_error([1, 1j], [1, 1]), math.sqrt(2-math.sqrt(2)))
        self.assertAlmostEqual(field_error([1, 0], [1, 1]), math.sqrt(2-math.sqrt(2)))
        self.assertAlmostEqual(field_error([1, 0], [0, 1]), math.sqrt(2))

    def test_invalid_inputs(self):
        cases = [([], []), ([0, 0], [1, 1]), ([1], [1, 2]),
                 ([[1], [2]], [1, 2]), ([float('inf')], [1]),
                 ([complex(1, float('nan'))], [1]), (1, [1])]
        for predicted, reference in cases:
            with self.subTest(predicted=predicted), self.assertRaises(ValueError):
                field_error(predicted, reference)

    def test_current_data(self):
        report = main()
        self.assertAlmostEqual(report['field_error'], 0.7653668647301795)
        self.assertFalse(report['qualified'])

if __name__ == '__main__':
    unittest.main()
