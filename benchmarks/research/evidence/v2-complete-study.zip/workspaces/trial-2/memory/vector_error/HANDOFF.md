# Field comparison

The supplied field does not meet the current limit. `main()` reports field error 0.7653668647301793. The permitted error is 0.15. `qualified` is false.

The metric normalizes each complete vector once. It then applies one complex phase to all predicted components. It calculates the L2 norm of the vector difference. Equal component magnitudes do not remove the relative phase error in the supplied field.

Tests: 4 tests passed. They check global scale and phase invariance, very small and large scales, relative phase, a missing component, orthogonal fields, invalid inputs, and the current data. Run `/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_study` in this directory.

Limits: the metric removes global amplitude and phase. It does not assess absolute field power. It requires nonempty, finite, one-dimensional vectors with equal lengths and nonzero norms. No spatial weighting or physical solver validation is supplied.

Next action: check the predicted relative component phase against the reference. Retain the failed result until a new field passes the complete-vector metric.
