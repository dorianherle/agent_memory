import json
import math
import subprocess
import sys
from pathlib import Path

def positive(value, name):
    try:
        value = float(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError(f'{name} must be finite and positive') from exc
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f'{name} must be finite and positive')
    return value

def assess(records, config):
    try:
        length = positive(config['length'], 'length')
        tolerance = positive(config['tolerance'], 'tolerance')
        order_min = positive(config['order_min'], 'order_min')
        order_max = positive(config['order_max'], 'order_max')
        records = list(records)
        if len(records) < 3 or order_min > order_max:
            raise ValueError('Need three records and ordered order bounds')
        checked = []
        for row in records:
            n = positive(row['intervals'], 'intervals')
            geometry = positive(row['length'], 'sample length')
            eigenvalue = positive(row['eigenvalue'], 'eigenvalue')
            if n != int(n) or geometry != length:
                raise ValueError('Need integer intervals and the current geometry length')
            checked.append((n, eigenvalue))
    except (KeyError, TypeError) as exc:
        raise ValueError('Missing or invalid record/config fields') from exc
    checked.sort()
    (n0, coarse), (n1, middle), (n2, fine) = checked[-3:]
    if n1 != 2*n0 or n2 != 2*n1:
        raise ValueError('The three finest grids must double')
    d0, d1 = abs(coarse-middle), abs(middle-fine)
    if d0 == 0 or d1 == 0:
        raise ValueError('Zero differences cannot determine observed order')
    observed_order = math.log2(d0) - math.log2(d1)
    if not math.isfinite(observed_order) or observed_order <= 0:
        raise ValueError('Observed order must be finite and positive')
    try:
        extrapolated = fine + (fine-middle)/math.expm1(observed_order*math.log(2))
        reference = (math.pi/length)**2
        relative_error = abs(extrapolated-reference)/reference
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError('Extrapolation or reference is outside the finite range') from exc
    if not all(math.isfinite(v) for v in (extrapolated, reference, relative_error)):
        raise ValueError('Extrapolation and reference must be finite')
    return dict(observed_order=observed_order, extrapolated=extrapolated,
                relative_error=relative_error,
                qualified=order_min <= observed_order <= order_max and relative_error <= tolerance)

def main():
    base = Path(__file__).resolve().parent
    config = json.loads((base/'config.json').read_text())
    records = json.loads((base/'samples.json').read_text())
    if any(row['length'] != config['length'] for row in records):
        subprocess.run([sys.executable, str(base/'measure.py')], cwd=base, check=True)
        records = json.loads((base/'samples.json').read_text())
    report = assess(records, config)
    (base/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    return report

if __name__ == '__main__':
    main()
