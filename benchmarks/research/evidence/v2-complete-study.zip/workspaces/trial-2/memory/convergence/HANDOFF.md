# Cavity convergence

The result meets the current limits. `main()` ran `measure.py` because the stored length was 1.0. All new samples use length 1.7.

The three finest grids have 32, 64, and 128 intervals. Their measured differences give observed order 1.999565454508593. Richardson extrapolation gives 3.415088083149547. Its relative error is 1.6131632663805927e-08. The current tolerance is 1e-6; the permitted order range is 1.8 to 2.2. `qualified` is true.

The analytical value `(pi/length)**2` is used only to assess error. It does not replace the numerical samples or the extrapolated value.

Tests: 5 tests passed. They check second-order extrapolation, record sorting, the three finest grids, first-order rejection, the error limit, invalid inputs, and the current data. Run `/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_study` in this directory.

Limits: the supplied measurement tool calculates a discrete cavity eigenvalue. This result does not validate a different geometry or a full electromagnetic solver. Observed order requires three grids with nonzero differences and a factor of two between adjacent selected grids.

Next action: add a finer grid measurement if a separate check of the asymptotic range is required. Keep the same length and retain the numerical values.
