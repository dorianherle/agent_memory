import math
import unittest
from study import assess, main

CONFIG = dict(length=1.7, tolerance=1e-6, order_min=1.8, order_max=2.2)

def samples(order=2, offset=0):
    exact = (math.pi/CONFIG['length'])**2
    return [dict(intervals=n, length=CONFIG['length'],
                 eigenvalue=exact+offset-1/n**order) for n in (16, 32, 64)]

class AssessmentTests(unittest.TestCase):
    def test_second_order_and_sorting(self):
        result = assess(list(reversed(samples())), CONFIG)
        self.assertAlmostEqual(result['observed_order'], 2)
        self.assertAlmostEqual(result['extrapolated'], (math.pi/1.7)**2)
        self.assertTrue(result['qualified'])

    def test_first_order_cannot_qualify(self):
        result = assess(samples(1), CONFIG)
        self.assertAlmostEqual(result['observed_order'], 1)
        self.assertLess(result['relative_error'], 1e-10)
        self.assertFalse(result['qualified'])

    def test_error_gate_and_finest_three(self):
        self.assertFalse(assess(samples(offset=1e-3), CONFIG)['qualified'])
        coarse = dict(intervals=8, length=1.7, eigenvalue=1)
        self.assertEqual(assess([coarse]+samples(), CONFIG), assess(samples(), CONFIG))

    def test_invalid_inputs(self):
        cases = [samples()[:2]]
        for key, value in [('length', 1.0), ('intervals', 48),
                           ('eigenvalue', float('nan')), ('intervals', 0)]:
            rows = samples()
            rows[0][key] = value
            cases.append(rows)
        constant = samples()
        for row in constant:
            row['eigenvalue'] = 3
        cases.append(constant)
        increasing_error = samples(-1)
        for row in increasing_error:
            row['eigenvalue'] = row['intervals']
        cases.append(increasing_error)
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                assess(rows, CONFIG)

    def test_current_data(self):
        result = main()
        self.assertTrue(result['qualified'])
        self.assertLess(result['relative_error'], CONFIG['tolerance'])

if __name__ == '__main__':
    unittest.main()
