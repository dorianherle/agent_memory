import unittest
from study import summarize, main

POLICY = dict(residual_limit=1e-6)

def row(**updates):
    result = dict(load_ms=2, predict_ms=1, correct_ms=8, verify_ms=4,
                  output_ms=3, training_ms=100000, baseline_ms=10, residual=1e-8)
    result.update(updates)
    return result

class RuntimeTests(unittest.TestCase):
    def test_full_time_and_offline_training(self):
        result = summarize([row()], POLICY)
        self.assertEqual(result['median_attempt_ms'], 18)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10/18)
        self.assertEqual(result['median_inference_speedup'], 10)
        self.assertEqual(result['claim'], 'slower_or_equal')
        self.assertEqual(result['baseline_contract'], 'construction_only')
        self.assertEqual(result, summarize([row(training_ms=0)], POLICY))

    def test_accuracy_gates_and_claims(self):
        result = summarize([row(), row(residual=1e-3, baseline_ms=1000)], POLICY)
        self.assertEqual(result['attempted'], 2)
        self.assertEqual(result['qualified'], 1)
        self.assertEqual(result['claim'], 'accuracy_limited')
        self.assertAlmostEqual(result['median_qualified_speedup'], 10/18)
        none = summarize([row(residual=1e-3)], POLICY)
        self.assertIsNone(none['median_qualified_speedup'])
        self.assertEqual(none['claim'], 'no_qualified_speedup')
        self.assertEqual(summarize([row(baseline_ms=36)], POLICY)['claim'], 'faster')
        self.assertEqual(summarize([row(baseline_ms=18)], POLICY)['claim'], 'slower_or_equal')
        self.assertEqual(summarize([row(residual=1e-6)], POLICY)['qualified'], 1)

    def test_invalid_inputs(self):
        cases = [[], [{}], [row(predict_ms=0)], [row(baseline_ms=0)],
                 [row(load_ms=-1)], [row(residual=float('nan'))],
                 [row(training_ms=float('inf'))]]
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                summarize(rows, POLICY)
        for limit in [0, -1, float('nan'), float('inf')]:
            with self.subTest(limit=limit), self.assertRaises(ValueError):
                summarize([row()], dict(residual_limit=limit))

    def test_current_data(self):
        result = main()
        self.assertEqual(result['attempted'], 4)
        self.assertEqual(result['qualified'], 3)
        self.assertEqual(result['median_attempt_ms'], 21)
        self.assertAlmostEqual(result['median_qualified_speedup'], 11/20)
        self.assertEqual(result['median_inference_speedup'], 4.75)
        self.assertEqual(result['claim'], 'accuracy_limited')

if __name__ == '__main__':
    unittest.main()
