import json
import math
from statistics import median
from pathlib import Path

FIELDS = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms',
          'training_ms', 'baseline_ms', 'residual')

def summarize(rows, policy):
    try:
        limit = float(policy['residual_limit'])
        if not math.isfinite(limit) or limit <= 0:
            raise ValueError('Residual limit must be finite and positive')
        rows = list(rows)
        if not rows:
            raise ValueError('Need at least one timing row')
        attempts, qualified_speedups, inference_speedups = [], [], []
        for row in rows:
            values = {key: float(row[key]) for key in FIELDS}
            if not all(math.isfinite(v) and v >= 0 for v in values.values()):
                raise ValueError('All timing and residual values must be finite and nonnegative')
            full_ms = math.fsum(values[key] for key in FIELDS[:5])
            baseline, predict = values['baseline_ms'], values['predict_ms']
            if full_ms <= 0 or predict <= 0 or baseline <= 0:
                raise ValueError('Full, prediction, and baseline times must be positive')
            full_ratio, inference_ratio = baseline/full_ms, baseline/predict
            if not all(math.isfinite(v) for v in (full_ms, full_ratio, inference_ratio)):
                raise ValueError('Times and speed ratios must be finite')
            attempts.append(full_ms)
            inference_speedups.append(inference_ratio)
            if values['residual'] <= limit:
                qualified_speedups.append(full_ratio)
    except (KeyError, TypeError, OverflowError) as exc:
        raise ValueError('Missing or invalid timing/policy fields') from exc
    qualified_median = median(qualified_speedups) if qualified_speedups else None
    if not qualified_speedups:
        claim = 'no_qualified_speedup'
    elif len(qualified_speedups) < len(rows):
        claim = 'accuracy_limited'
    else:
        claim = 'faster' if qualified_median > 1 else 'slower_or_equal'
    return dict(attempted=len(rows), qualified=len(qualified_speedups),
                median_attempt_ms=median(attempts),
                median_qualified_speedup=qualified_median,
                median_inference_speedup=median(inference_speedups),
                baseline_contract='construction_only', claim=claim)

def main():
    base = Path(__file__).resolve().parent
    rows = json.loads((base/'timings.json').read_text())
    policy = json.loads((base/'policy.json').read_text())
    report = summarize(rows, policy)
    (base/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    return report

if __name__ == '__main__':
    main()
