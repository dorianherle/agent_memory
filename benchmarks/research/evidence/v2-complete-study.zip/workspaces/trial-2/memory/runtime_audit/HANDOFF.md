# Learned-solver runtime

Four attempts were assessed. Three meet the residual limit of 1e-6. One has residual 0.001 and fails. The report claim is `accuracy_limited`.

The full attempt times are 18, 20, 22, and 24 ms. Their median is 21 ms. Each time includes loading, prediction, correction, verification, and output. Offline training is excluded.

The median construction speed ratio for the three qualified rows is 0.55. Thus, the qualified attempts are slower than the baseline under this contract. The median inference-only ratio over all four rows is 4.75. That ratio does not establish a full construction speed increase.

`baseline_contract` is `construction_only`: the supplied baseline times cover reference inverse construction. Failed outputs are excluded from the qualified speed ratio. They remain in the attempt count, full-time median, and inference-only median.

Tests: 4 tests passed. They check full timing, offline training exclusion, accuracy coverage, all four claim labels, the residual boundary, invalid inputs, and the current data. Run `/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -B -m unittest -v test_study` in this directory.

Limits: this audit uses four supplied timing rows. It does not supply repeated measurements, hardware details, uncertainty estimates, or amortized training costs.

Next action: resolve the failed residual. Then repeat the full construction measurements with a matched baseline and repeated trials. Retain both timing contracts and the accuracy count.
