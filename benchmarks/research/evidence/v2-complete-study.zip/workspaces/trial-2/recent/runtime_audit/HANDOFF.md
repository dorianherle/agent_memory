# Learned-solver runtime audit

The audit is complete. `main()` wrote `report.json`.

## Result

- Attempts: 4.
- Accuracy passes: 3. One residual is 0.001, above the 1e-6 limit.
- Median time for all attempts: 21 ms.
- Median speedup for qualified attempts: 0.55.
- Median speedup for prediction alone: 4.75.
- Claim label: `accuracy_limited`.

The qualified attempts are slower than their baselines.
The prediction-only speedup does not show a speedup for the complete calculation.

## Method and limits

The context file contains display updates only. It does not specify a research method.
The method is therefore an explicit assumption.
Each attempt time includes load, prediction, correction, verification, and output.
The resulting times are 18, 20, 22, and 24 ms.
All attempts remain in the time median, including the accuracy failure.
Accuracy requires residual <= residual_limit.
Qualified speedups are per-row baseline_ms divided by complete attempt time.
Prediction-only speedups are per-row baseline_ms divided by predict_ms.
The report uses medians of those ratios.

Training is treated as a prior cost and excluded from online attempt time.
Each supplied row records 100000 ms for training.
The data do not show whether that cost is shared or how many calls amortize it.
No training-inclusive speedup is claimed.

The baseline contract requires the same input, output, and accuracy requirement.
It treats baseline_ms as the full baseline runtime.
The supplied data do not independently verify that contract.
The report states this assumption in `baseline_contract`.
Four timing rows do not establish a general runtime distribution.

The claim rules are: no accuracy passes gives `no_qualified_speedup`;
partial accuracy coverage gives `accuracy_limited`;
complete coverage gives `faster` only if the qualified median exceeds 1.
Otherwise, the label is `slower_or_equal`.

## Tests

Five local tests passed with the required Python interpreter.
They cover the full online cost, failed attempt retention, no accuracy passes,
complete faster coverage, and the residual boundary.
`main()` completed and wrote finite JSON values.

Run in this directory:

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -m unittest -v test_study.py
PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python study.py
```

## Next action

Confirm the baseline contract and training cost ownership.
Then obtain more repeated timings with the same output and accuracy requirements.
