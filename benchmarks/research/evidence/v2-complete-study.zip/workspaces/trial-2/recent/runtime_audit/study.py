import json
import math
from pathlib import Path
from statistics import median

def summarize(rows, policy):
    """Report all online costs and retain attempts that fail the accuracy gate."""
    rows = list(rows)
    if not rows:
        raise ValueError('At least one timing row is required.')
    limit = float(policy['residual_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('The residual limit must be finite and nonnegative.')
    totals, inference_speedups, qualified_speedups = [], [], []
    online_keys = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms')
    for row in rows:
        for key in online_keys + ('training_ms', 'baseline_ms', 'residual'):
            value = float(row[key])
            if not math.isfinite(value) or value < 0:
                raise ValueError(f'{key} must be finite and nonnegative.')
        total = math.fsum(float(row[key]) for key in online_keys)
        baseline = float(row['baseline_ms'])
        inference = float(row['predict_ms'])
        if total <= 0 or baseline <= 0 or inference <= 0:
            raise ValueError('Attempt, baseline, and inference times must be positive.')
        totals.append(total)
        inference_speedups.append(baseline / inference)
        if float(row['residual']) <= limit:
            qualified_speedups.append(baseline / total)
    qualified = len(qualified_speedups)
    qualified_speedup = median(qualified_speedups) if qualified else None
    if qualified == 0:
        claim = 'no_qualified_speedup'
    elif qualified < len(rows):
        claim = 'accuracy_limited'
    elif qualified_speedup > 1:
        claim = 'faster'
    else:
        claim = 'slower_or_equal'
    return {
        'attempted': len(rows),
        'qualified': qualified,
        'median_attempt_ms': median(totals),
        'median_qualified_speedup': qualified_speedup,
        'median_inference_speedup': median(inference_speedups),
        'baseline_contract': 'same_input_output_and_accuracy; baseline_ms_is_end_to_end',
        'claim': claim,
    }

def main():
    root = Path(__file__).resolve().parent
    result = summarize(json.loads((root / 'timings.json').read_text()),
                       json.loads((root / 'policy.json').read_text()))
    (root / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    return result

if __name__ == '__main__':
    main()
