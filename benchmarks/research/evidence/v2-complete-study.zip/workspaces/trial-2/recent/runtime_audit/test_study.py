import unittest
from study import summarize


def row(residual=0, baseline=10):
    return dict(load_ms=2, predict_ms=1, correct_ms=8, verify_ms=4,
                output_ms=3, training_ms=100000, baseline_ms=baseline, residual=residual)


class RuntimeTests(unittest.TestCase):
    policy = {'residual_limit': 1e-6}

    def test_all_online_costs_and_no_training_cost(self):
        result = summarize([row()], self.policy)
        self.assertEqual(result['median_attempt_ms'], 18)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10 / 18)
        self.assertEqual(result['median_inference_speedup'], 10)
        self.assertEqual(result['claim'], 'slower_or_equal')

    def test_failures_remain_in_attempt_count(self):
        result = summarize([row(), row(residual=1e-3)], self.policy)
        self.assertEqual(result['attempted'], 2)
        self.assertEqual(result['qualified'], 1)
        self.assertEqual(result['claim'], 'accuracy_limited')

    def test_no_accuracy_pass(self):
        result = summarize([row(residual=1e-3)], self.policy)
        self.assertIsNone(result['median_qualified_speedup'])
        self.assertEqual(result['claim'], 'no_qualified_speedup')

    def test_faster_with_complete_accuracy_coverage(self):
        self.assertEqual(summarize([row(baseline=36)], self.policy)['claim'], 'faster')

    def test_accuracy_boundary_passes(self):
        self.assertEqual(summarize([row(residual=1e-6)], self.policy)['qualified'], 1)


if __name__ == '__main__':
    unittest.main()
