# Cavity convergence study

The study is complete. `main()` wrote `report.json`.

## Result

The original samples used length 1.0. The config requires length 1.7.
I ran the supplied `measure.py` to replace the samples with data for length 1.7.

- Observed order: 1.999565454508592.
- Extrapolated eigenvalue: 3.415088083149547.
- Relative error: 1.6131632663805927e-08.
- Qualified: true. The error is below 1e-6. The order is between 1.8 and 2.2.

## Method and limits

The context file contains display updates only. It does not specify a research method.
The method is therefore an explicit assumption.
I use the three finest meshes: 32, 64, and 128 intervals.
For refinement ratio r, the observed order is log(abs(d1/d2))/log(r).
Here, d1 and d2 are consecutive eigenvalue changes.
Richardson extrapolation gives lambda_fine + d2/(r**p - 1).
The analytical reference, (pi/length)**2, is used only to calculate the final relative error.
It is not used to produce or alter the numerical extrapolation.

The supplied tool gives the eigenvalue of a discrete cavity operator.
These data are model results, not physical measurements.
The API requires three distinct meshes with equal refinement ratios at the finest levels.
It rejects mixed lengths and nonconvergent sequences.
A mismatch between the data length and config length cannot qualify.

## Tests

Four local tests passed with the required Python interpreter.
They cover a known second-order sequence, a first-order failure,
mixed lengths, and separation of the extrapolation from the config reference.
`main()` completed and wrote finite JSON values.

Run in this directory:

```sh
/Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python measure.py
PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -m unittest -v test_study.py
PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python study.py
```

## Next action

Confirm the method assumption against the missing research record.
For a stronger convergence check, supply finer meshes and compare successive extrapolations.
