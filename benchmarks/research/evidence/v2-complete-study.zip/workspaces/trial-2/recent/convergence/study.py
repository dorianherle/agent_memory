import json
import math
from pathlib import Path

def assess(records, config):
    """Use the three finest meshes for observed-order Richardson analysis."""
    length = float(config['length'])
    if not math.isfinite(length) or length <= 0:
        raise ValueError('The cavity length must be positive and finite.')
    ordered = sorted(records, key=lambda row: row['intervals'])
    if len(ordered) < 3:
        raise ValueError('At least three mesh measurements are required.')
    for row in ordered:
        n = row['intervals']
        if isinstance(n, bool) or int(n) != n or n <= 0:
            raise ValueError('Mesh intervals must be positive integers.')
        if not math.isfinite(float(row['eigenvalue'])):
            raise ValueError('Eigenvalues must be finite.')
        if not math.isfinite(float(row['length'])) or row['length'] <= 0:
            raise ValueError('Measured cavity lengths must be positive and finite.')
    if len({row['intervals'] for row in ordered}) != len(ordered):
        raise ValueError('Mesh sizes must be distinct.')
    if not all(math.isclose(float(row['length']), float(ordered[0]['length']),
                            rel_tol=1e-12, abs_tol=0) for row in ordered):
        raise ValueError('Measurements must use one cavity length.')
    coarse, middle, fine = ordered[-3:]
    ratio = middle['intervals'] / coarse['intervals']
    if not math.isclose(fine['intervals'] / middle['intervals'], ratio,
                        rel_tol=1e-12, abs_tol=0):
        raise ValueError('The three finest meshes must have equal refinement ratios.')
    d1 = float(middle['eigenvalue']) - float(coarse['eigenvalue'])
    d2 = float(fine['eigenvalue']) - float(middle['eigenvalue'])
    if d1 == 0 or d2 == 0 or d1 * d2 <= 0:
        raise ValueError('The mesh sequence must have nonzero monotone changes.')
    order = math.log(abs(d1 / d2)) / math.log(ratio)
    if order <= 0:
        raise ValueError('The mesh changes do not show positive convergence order.')
    extrapolated = float(fine['eigenvalue']) + d2 / math.expm1(order * math.log(ratio))
    # The analytical result is used only after the numerical extrapolation.
    analytical = (math.pi / length) ** 2
    relative_error = abs(extrapolated - analytical) / abs(analytical)
    length_matches = math.isclose(float(fine['length']), length,
                                 rel_tol=1e-12, abs_tol=0)
    return {
        'observed_order': order,
        'extrapolated': extrapolated,
        'relative_error': relative_error,
        'qualified': bool(length_matches and config['order_min'] <= order <= config['order_max']
                          and relative_error <= config['tolerance']),
    }

def main():
    root = Path(__file__).resolve().parent
    result = assess(json.loads((root / 'samples.json').read_text()),
                    json.loads((root / 'config.json').read_text()))
    (root / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    return result

if __name__ == '__main__':
    main()
