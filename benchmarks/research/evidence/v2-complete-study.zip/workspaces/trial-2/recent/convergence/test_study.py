import math
import unittest
from study import assess


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        self.config = dict(length=1.7, tolerance=1e-6, order_min=1.8, order_max=2.2)
        exact = (math.pi / self.config['length']) ** 2
        self.records = [dict(intervals=n, length=1.7, eigenvalue=exact - 3 / n ** 2)
                        for n in (16, 32, 64, 128)]

    def test_known_second_order_sequence(self):
        result = assess(list(reversed(self.records)), self.config)
        self.assertAlmostEqual(result['observed_order'], 2, places=9)
        self.assertAlmostEqual(result['extrapolated'], (math.pi / 1.7) ** 2, places=12)
        self.assertTrue(result['qualified'])

    def test_config_length_does_not_change_numerical_extrapolation(self):
        result = assess(self.records, dict(self.config, length=1.0))
        self.assertFalse(result['qualified'])
        self.assertAlmostEqual(result['extrapolated'], (math.pi / 1.7) ** 2, places=12)

    def test_mixed_lengths_rejected(self):
        self.records[0]['length'] = 1.0
        with self.assertRaises(ValueError):
            assess(self.records, self.config)

    def test_first_order_sequence_fails_order_gate(self):
        exact = (math.pi / 1.7) ** 2
        records = [dict(intervals=n, length=1.7, eigenvalue=exact - 3 / n)
                   for n in (16, 32, 64, 128)]
        self.assertFalse(assess(records, self.config)['qualified'])


if __name__ == '__main__':
    unittest.main()
