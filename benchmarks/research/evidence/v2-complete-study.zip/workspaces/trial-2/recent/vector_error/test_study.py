import math
import unittest
from study import field_error


class FieldTests(unittest.TestCase):
    def test_one_global_phase_is_free(self):
        reference = [1 + 2j, -3 + 4j]
        self.assertLess(field_error([1j * value for value in reference], reference), 1e-14)

    def test_local_phase_error_is_retained(self):
        self.assertAlmostEqual(field_error([1, 1j], [1, 1]),
                               math.sqrt(2 - math.sqrt(2)), places=14)

    def test_amplitude_error_is_retained(self):
        self.assertAlmostEqual(field_error([2, 2j], [1, 1j]), 1)

    def test_zero_prediction(self):
        self.assertEqual(field_error([0, 0], [1, 1j]), 1)

    def test_orthogonal_vectors(self):
        self.assertAlmostEqual(field_error([1, -1], [1, 1]), math.sqrt(2))

    def test_bad_shapes_and_zero_reference(self):
        for predicted, reference in [([1], [1, 1]), ([[1]], [1]), ([1], [0])]:
            with self.assertRaises(ValueError):
                field_error(predicted, reference)


if __name__ == '__main__':
    unittest.main()
