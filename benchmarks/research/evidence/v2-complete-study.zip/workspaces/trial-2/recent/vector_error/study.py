import json
import math
from pathlib import Path

def field_error(predicted, reference):
    """Return relative complex L2 error after one global phase alignment."""
    try:
        predicted = [complex(value) for value in predicted]
        reference = [complex(value) for value in reference]
    except (TypeError, ValueError) as exc:
        raise ValueError('Fields must be one-dimensional complex vectors.') from exc
    if not reference or len(predicted) != len(reference):
        raise ValueError('Fields must be nonempty vectors with equal lengths.')
    if not all(math.isfinite(value.real) and math.isfinite(value.imag)
               for value in predicted + reference):
        raise ValueError('Field entries must be finite.')
    # A common scale reduces overflow. It does not change the relative error.
    scale = max(abs(value) for value in predicted + reference)
    if scale == 0:
        return 0.0
    predicted = [value / scale for value in predicted]
    reference = [value / scale for value in reference]
    reference_norm = math.sqrt(math.fsum(abs(value) ** 2 for value in reference))
    if reference_norm == 0:
        raise ValueError('Relative error requires a nonzero reference field.')
    overlap = sum(value.conjugate() * target
                  for value, target in zip(predicted, reference))
    phase = overlap / abs(overlap) if overlap != 0 else 1 + 0j
    error = math.sqrt(math.fsum(abs(phase * value - target) ** 2
                                for value, target in zip(predicted, reference))) / reference_norm
    if not math.isfinite(error):
        raise ValueError('Relative field error exceeds the finite numerical range.')
    return error

def main():
    root = Path(__file__).resolve().parent
    fields = json.loads((root / 'fields.json').read_text())
    policy = json.loads((root / 'policy.json').read_text())
    error = field_error([complex(*pair) for pair in fields['predicted']],
                        [complex(*pair) for pair in fields['reference']])
    result = {'field_error': error,
              'qualified': bool(error <= policy['field_error_limit'])}
    (root / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    return result

if __name__ == '__main__':
    main()
