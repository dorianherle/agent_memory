# Electromagnetic field study

The study is complete. `main()` wrote `report.json`.

## Result

- Field error: 0.7653668647301793.
- Error limit: 0.15.
- Qualified: false.

The two fields have equal component amplitudes.
The second predicted component has a phase error.
That error remains in the result.

## Method and limits

The context file contains display updates only. It does not specify a research method.
The method is therefore an explicit assumption.
The error is the complex L2 difference divided by the reference L2 norm.
One global phase is selected to minimize the difference.
Each component cannot receive a separate phase correction.
The predicted amplitude is not normalized to the reference amplitude.
This keeps amplitude errors and relative phase errors in the assessment.

The input contains two components only. It has no spatial weights or physical units.
The API uses equal component weights.
It rejects unequal lengths, empty vectors, nonfinite entries, and a nonzero prediction with a zero reference.
Two zero fields give zero error.
This assessment does not establish a device performance result.

## Tests

Six local tests passed with the required Python interpreter.
They cover a common phase shift, a local phase error, an amplitude error,
a zero prediction, orthogonal vectors, and invalid inputs.
`main()` completed and wrote finite JSON values.

Run in this directory:

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -m unittest -v test_study.py
PYTHONDONTWRITEBYTECODE=1 /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python study.py
```

## Next action

Confirm whether one global phase is physically free in the original study.
If absolute phase is required, revise that assumption before use.
Supply spatial weights if the components represent unequal sample volumes.
