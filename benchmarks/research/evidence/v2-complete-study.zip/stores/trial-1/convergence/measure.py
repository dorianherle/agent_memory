import json, math
from pathlib import Path
cfg = json.loads(Path('config.json').read_text())
length = cfg['length']
records = [{'intervals': n, 'length': length,
            'eigenvalue': 4*n*n*math.sin(math.pi/(2*n))**2/length**2}
           for n in (16, 32, 64, 128)]
Path('samples.json').write_text(json.dumps(records, indent=2)+'\n')
