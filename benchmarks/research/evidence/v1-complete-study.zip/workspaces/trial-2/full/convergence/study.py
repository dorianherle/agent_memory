import json
import math
import subprocess
import sys
from pathlib import Path


def _positive(value, name):
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite positive number") from exc
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be a finite positive number")
    return value


def assess(records, config):
    """Assess the three finest measured grids with observed-order extrapolation."""
    try:
        records = list(records)
        length = _positive(config["length"], "length")
        tolerance = _positive(config["tolerance"], "tolerance")
        order_min = _positive(config["order_min"], "order_min")
        order_max = _positive(config["order_max"], "order_max")
        if len(records) < 3 or order_min > order_max:
            raise ValueError("Need three records and an ordered order range")
        checked = [(_positive(r["intervals"], "intervals"),
                    _positive(r["length"], "record length"),
                    _positive(r["eigenvalue"], "eigenvalue")) for r in records]
    except (KeyError, TypeError) as exc:
        raise ValueError("Missing or invalid input fields") from exc
    if any(r[1] != length for r in checked):
        raise ValueError("All measured lengths must equal the current config length")
    checked.sort(key=lambda r: r[0])
    coarse, middle, fine = checked[-3:]
    if middle[0] != 2 * coarse[0] or fine[0] != 2 * middle[0]:
        raise ValueError("The three finest grids must double")
    first = abs(coarse[2] - middle[2])
    second = abs(middle[2] - fine[2])
    if first == 0 or second == 0:
        raise ValueError("Grid differences must be nonzero")
    observed_order = math.log2(first) - math.log2(second)
    if not math.isfinite(observed_order) or observed_order <= 0:
        raise ValueError("Observed order must be finite and positive")
    try:
        denominator = math.expm1(observed_order * math.log(2))
        extrapolated = fine[2] + (fine[2] - middle[2]) / denominator
        analytical = (math.pi / length) ** 2
        relative_error = abs(extrapolated - analytical) / analytical
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError("The extrapolation cannot be represented") from exc
    if not all(math.isfinite(v) for v in (extrapolated, analytical, relative_error)):
        raise ValueError("The extrapolation must be finite")
    return {"observed_order": observed_order, "extrapolated": extrapolated,
            "relative_error": relative_error,
            "qualified": order_min <= observed_order <= order_max
                         and relative_error <= tolerance}


def main():
    directory = Path(__file__).resolve().parent
    config = json.loads((directory / "config.json").read_text())
    records = json.loads((directory / "samples.json").read_text())
    length = _positive(config["length"], "length")
    if any(record.get("length") != length for record in records):
        subprocess.run([sys.executable, str(directory / "measure.py")],
                       cwd=directory, check=True)
        records = json.loads((directory / "samples.json").read_text())
    report = assess(records, config)
    (directory / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
