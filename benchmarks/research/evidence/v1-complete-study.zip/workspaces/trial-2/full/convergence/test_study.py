import json
import math
import unittest
from pathlib import Path
from study import assess, main


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        self.config = {"length": 1.7, "tolerance": 1e-6, "order_min": 1.8, "order_max": 2.2}

    def records(self, order=2):
        exact = (math.pi / self.config["length"]) ** 2
        return [{"intervals": n, "length": self.config["length"], "eigenvalue": exact + 2 / n ** order}
                for n in (8, 16, 32, 64)]

    def test_second_order_and_sorting(self):
        result = assess(list(reversed(self.records())), self.config)
        self.assertAlmostEqual(result["observed_order"], 2)
        self.assertLess(result["relative_error"], 1e-12)
        self.assertTrue(result["qualified"])

    def test_first_order_cannot_qualify(self):
        result = assess(self.records(1), self.config)
        self.assertAlmostEqual(result["observed_order"], 1)
        self.assertFalse(result["qualified"])

    def test_current_tolerance_is_used(self):
        rows = self.records()
        for row in rows:
            row["eigenvalue"] += 0.01
        self.assertFalse(assess(rows, self.config)["qualified"])

    def test_invalid_records(self):
        invalid = [[], self.records()[:2]]
        for field, value in [("length", 1), ("length", float("nan")),
                             ("intervals", 0), ("eigenvalue", float("inf")),
                             ("eigenvalue", -1)]:
            rows = self.records()
            rows[-1][field] = value
            invalid.append(rows)
        rows = self.records()
        rows[-1]["intervals"] = 70
        invalid.append(rows)
        rows = self.records()
        rows[-1]["eigenvalue"] = rows[-2]["eigenvalue"]
        invalid.append(rows)
        rows = self.records()
        rows[-1]["eigenvalue"] = rows[-2]["eigenvalue"] + 1
        invalid.append(rows)
        invalid.append([{}, {}, {}])
        for rows in invalid:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                assess(rows, self.config)

    def test_main_current_geometry(self):
        main()
        directory = Path(__file__).resolve().parent
        rows = json.loads((directory / "samples.json").read_text())
        config = json.loads((directory / "config.json").read_text())
        self.assertTrue(all(r["length"] == config["length"] for r in rows))
        self.assertEqual(json.loads((directory / "report.json").read_text()), assess(rows, config))


if __name__ == "__main__":
    unittest.main()
