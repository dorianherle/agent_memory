import copy
import json
import unittest
from pathlib import Path
from study import summarize, main


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.directory = Path(__file__).resolve().parent
        self.rows = json.loads((self.directory / "timings.json").read_text())
        self.policy = {"residual_limit": 1e-6}

    def test_full_attempt_and_qualified_speed(self):
        report = summarize(self.rows, self.policy)
        self.assertEqual(report["attempted"], 4)
        self.assertEqual(report["qualified"], 3)
        self.assertEqual(report["median_attempt_ms"], 21)
        self.assertAlmostEqual(report["median_qualified_speedup"], 0.55)
        self.assertAlmostEqual(report["median_inference_speedup"], 4.75)
        self.assertEqual(report["baseline_contract"], "construction_only")
        self.assertEqual(report["claim"], "accuracy_limited")

    def test_training_is_excluded(self):
        report = summarize(self.rows, self.policy)
        rows = copy.deepcopy(self.rows)
        for row in rows:
            row["training_ms"] *= 10
        self.assertEqual(summarize(rows, self.policy), report)

    def test_no_qualified(self):
        for row in self.rows:
            row["residual"] = 1
        report = summarize(self.rows, self.policy)
        self.assertIsNone(report["median_qualified_speedup"])
        self.assertEqual(report["claim"], "no_qualified_speedup")

    def test_all_qualified_claims(self):
        for row in self.rows:
            row["residual"] = self.policy["residual_limit"]
        self.assertEqual(summarize(self.rows, self.policy)["claim"], "slower_or_equal")
        for row in self.rows:
            row["baseline_ms"] *= 10
        self.assertEqual(summarize(self.rows, self.policy)["claim"], "faster")

    def test_invalid(self):
        for field in (*self.rows[0].keys(),):
            if field == "matrix_id":
                continue
            for value in (-1, float("nan"), float("inf")):
                rows = copy.deepcopy(self.rows)
                rows[0][field] = value
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    summarize(rows, self.policy)
            rows = copy.deepcopy(self.rows)
            del rows[0][field]
            with self.subTest(missing=field), self.assertRaises(ValueError):
                summarize(rows, self.policy)
        for field in ("predict_ms", "baseline_ms"):
            rows = copy.deepcopy(self.rows)
            rows[0][field] = 0
            with self.assertRaises(ValueError):
                summarize(rows, self.policy)
        with self.assertRaises(ValueError):
            summarize([], self.policy)
        for limit in (0, -1, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                summarize(self.rows, {"residual_limit": limit})

    def test_main(self):
        main()
        self.assertEqual(json.loads((self.directory / "report.json").read_text()),
                         summarize(self.rows, self.policy))


if __name__ == "__main__":
    unittest.main()
