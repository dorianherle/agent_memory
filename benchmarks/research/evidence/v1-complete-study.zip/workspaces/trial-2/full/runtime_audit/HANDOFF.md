Result: Three of four attempts meet the residual limit of 1e-6. The claim is accuracy_limited. The failed case remains in the attempted count and timing statistics.

Median full attempt time: 21 ms. Median qualified construction speed ratio: 0.55. Median pure inference speed ratio: 4.75. A ratio below 1 indicates slower execution than the baseline.

Method: Full attempt time includes loading, prediction, correction, verification, and output. Training is offline and excluded. The baseline contract is construction_only. Qualified speed ratios use only cases that meet the residual limit. Pure inference ratios use all cases and remain separate.

Tests: Six local unittest tests passed. Checks include supplied totals, qualified coverage, excluded training time, all claim branches, invalid inputs, and main. Command: /Users/dorianherle/Documents/Personal/agent_memory/.venv/bin/python -m unittest -v.

Limits: The supplied timing rows are the available evidence. No new benchmark measurements or hidden tests were run. The baseline does not represent reusable solves.

Next action: Improve full construction time and the failed residual case. Then collect new timings for the same workload.
