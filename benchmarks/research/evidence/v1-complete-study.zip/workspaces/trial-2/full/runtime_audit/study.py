import json
import math
import statistics
from pathlib import Path


_TIME_FIELDS = ("load_ms", "predict_ms", "correct_ms", "verify_ms", "output_ms")


def _nonnegative(value, name):
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be finite and nonnegative") from exc
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"{name} must be finite and nonnegative")
    return value


def summarize(rows, policy):
    """Keep full construction timing separate from accuracy and pure inference."""
    try:
        rows = list(rows)
        residual_limit = _nonnegative(policy["residual_limit"], "residual_limit")
        if not rows or residual_limit == 0:
            raise ValueError("Need rows and a positive residual limit")
        attempts = []
        qualified_speedups = []
        inference_speedups = []
        for row in rows:
            values = {name: _nonnegative(row[name], name)
                      for name in (*_TIME_FIELDS, "training_ms", "baseline_ms", "residual")}
            full_ms = math.fsum(values[name] for name in _TIME_FIELDS)
            if full_ms == 0 or values["predict_ms"] == 0 or values["baseline_ms"] == 0:
                raise ValueError("Full, prediction, and baseline times must be positive")
            attempts.append(full_ms)
            inference_speedups.append(values["baseline_ms"] / values["predict_ms"])
            if values["residual"] <= residual_limit:
                qualified_speedups.append(values["baseline_ms"] / full_ms)
    except (KeyError, TypeError, OverflowError) as exc:
        raise ValueError("Missing, invalid, or unrepresentable input fields") from exc
    if not all(math.isfinite(v) for v in (*attempts, *qualified_speedups, *inference_speedups)):
        raise ValueError("Times and speed ratios must be finite")
    qualified = len(qualified_speedups)
    median_speedup = statistics.median(qualified_speedups) if qualified else None
    if not qualified:
        claim = "no_qualified_speedup"
    elif qualified < len(rows):
        claim = "accuracy_limited"
    else:
        claim = "faster" if median_speedup > 1 else "slower_or_equal"
    return {"attempted": len(rows), "qualified": qualified,
            "median_attempt_ms": statistics.median(attempts),
            "median_qualified_speedup": median_speedup,
            "median_inference_speedup": statistics.median(inference_speedups),
            "baseline_contract": "construction_only", "claim": claim}


def main():
    directory = Path(__file__).resolve().parent
    rows = json.loads((directory / "timings.json").read_text())
    policy = json.loads((directory / "policy.json").read_text())
    report = summarize(rows, policy)
    (directory / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
