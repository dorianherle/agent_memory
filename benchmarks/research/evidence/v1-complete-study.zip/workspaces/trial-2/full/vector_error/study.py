import json
import math
from pathlib import Path


def _unit_vector(values):
    if getattr(values, "ndim", 1) != 1:
        raise ValueError("Input must be one-dimensional")
    try:
        vector = [complex(value) for value in values]
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Input must be a one-dimensional complex array") from exc
    if not vector or any(not math.isfinite(z.real) or not math.isfinite(z.imag)
                         for z in vector):
        raise ValueError("Input must be nonempty and finite")
    scale = max(max(abs(z.real), abs(z.imag)) for z in vector)
    if scale == 0:
        raise ValueError("Vector norm must be positive")
    scaled = [complex(z.real / scale, z.imag / scale) for z in vector]
    norm = math.sqrt(math.fsum(z.real * z.real + z.imag * z.imag for z in scaled))
    return [z / norm for z in scaled]


def field_error(predicted, reference):
    """Return unit-L2 vector error after one global complex phase alignment."""
    predicted = _unit_vector(predicted)
    reference = _unit_vector(reference)
    if len(predicted) != len(reference):
        raise ValueError("Vector lengths must be equal")
    terms = [p.conjugate() * r for p, r in zip(predicted, reference)]
    overlap = complex(math.fsum(z.real for z in terms), math.fsum(z.imag for z in terms))
    phase = overlap / abs(overlap) if overlap != 0 else 1 + 0j
    differences = [p * phase - r for p, r in zip(predicted, reference)]
    return math.sqrt(math.fsum(z.real * z.real + z.imag * z.imag for z in differences))


def _decode(pairs):
    try:
        if any(len(pair) != 2 for pair in pairs):
            raise ValueError("Each field element needs a real and imaginary part")
        return [complex(real, imag) for real, imag in pairs]
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Invalid field pairs") from exc


def main():
    directory = Path(__file__).resolve().parent
    fields = json.loads((directory / "fields.json").read_text())
    policy = json.loads((directory / "policy.json").read_text())
    limit = float(policy["field_error_limit"])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError("Field error limit must be finite and nonnegative")
    error = field_error(_decode(fields["predicted"]), _decode(fields["reference"]))
    report = {"field_error": error, "qualified": error <= limit}
    (directory / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
