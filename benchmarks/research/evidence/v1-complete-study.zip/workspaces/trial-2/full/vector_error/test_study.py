import json
import math
import unittest
from pathlib import Path
from study import field_error, main


class FieldTests(unittest.TestCase):
    def test_global_scale_and_phase(self):
        reference = [1 + 2j, -3 + 4j, 2 - 1j]
        for scale in (1j, -4, 1e-280 + 1e-280j, 1e280 + 1e280j):
            self.assertLess(field_error([scale * z for z in reference], reference), 1e-14)

    def test_relative_phase(self):
        self.assertAlmostEqual(field_error([1, 1j], [1, 1]), math.sqrt(2 - math.sqrt(2)))

    def test_relative_amplitude(self):
        self.assertGreater(field_error([1, 0], [1, 1]), 0.7)

    def test_orthogonal(self):
        self.assertAlmostEqual(field_error([1, 0], [0, 1]), math.sqrt(2))

    def test_invalid(self):
        for predicted, reference in [([], []), ([0], [1]), ([1], [0]),
                                     ([1], [1, 2]), ([[1]], [[1]]),
                                     (1, [1]), ([float("nan")], [1]),
                                     ([complex(1, float("inf"))], [1])]:
            with self.subTest(predicted=predicted), self.assertRaises(ValueError):
                field_error(predicted, reference)

    def test_main_policy(self):
        main()
        report = json.loads((Path(__file__).resolve().parent / "report.json").read_text())
        self.assertAlmostEqual(report["field_error"], math.sqrt(2 - math.sqrt(2)))
        self.assertFalse(report["qualified"])


if __name__ == "__main__":
    unittest.main()
