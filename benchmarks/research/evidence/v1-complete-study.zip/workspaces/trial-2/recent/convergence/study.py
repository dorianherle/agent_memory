import json
import math
from pathlib import Path

def assess(records, config):
    length = float(config['length'])
    tolerance = float(config['tolerance'])
    lower, upper = float(config['order_min']), float(config['order_max'])
    if not (math.isfinite(length) and length > 0 and math.isfinite(tolerance) and tolerance >= 0):
        raise ValueError('Length and tolerance must be valid.')
    if not (math.isfinite(lower) and math.isfinite(upper) and lower <= upper):
        raise ValueError('Order bounds must be valid.')
    measurements = []
    for row in records:
        n, sample_length, value = row['intervals'], float(row['length']), float(row['eigenvalue'])
        if isinstance(n, bool) or int(n) != n or n < 2:
            raise ValueError('Each interval count must be an integer of at least two.')
        if not (math.isfinite(sample_length) and sample_length > 0 and math.isfinite(value) and value > 0):
            raise ValueError('Measurements must be finite and positive.')
        measurements.append({'intervals': int(n), 'length': sample_length, 'eigenvalue': value})
    measurements.sort(key=lambda row: row['intervals'])
    if len(measurements) < 3 or len({row['intervals'] for row in measurements}) != len(measurements):
        raise ValueError('At least three distinct meshes are required.')
    reference = (math.pi / length) ** 2
    current = all(math.isclose(row['length'], length, rel_tol=1e-12, abs_tol=0) for row in measurements)
    result = {'analytical_reference': reference, 'measurements': measurements,
              'data_match_config': current, 'tolerance': tolerance,
              'tolerance_metric': 'absolute eigenvalue error', 'qualified': False}
    if not current:
        result['reason'] = 'Sample length does not match the configured length. Regenerate samples.'
        return result
    errors = [abs(row['eigenvalue'] - reference) for row in measurements]
    orders = []
    for i in range(1, len(measurements)):
        orders.append(math.log(errors[i-1]/errors[i]) / math.log(measurements[i]['intervals']/measurements[i-1]['intervals'])
                      if errors[i-1] > 0 and errors[i] > 0 else None)
    order_ok = all(p is not None and lower <= p <= upper for p in orders)
    fine, coarse = measurements[-1], measurements[-2]
    ratio = fine['intervals'] / coarse['intervals']
    # The supplied measurement method has a second-order truncation error.
    extrapolated = fine['eigenvalue'] + (fine['eigenvalue']-coarse['eigenvalue'])/(ratio**2-1)
    result.update({'absolute_errors': errors, 'observed_orders': orders,
                   'estimated_order': orders[-1], 'order_qualified': order_ok,
                   'numerical_eigenvalue': fine['eigenvalue'], 'absolute_error': errors[-1],
                   'relative_error': errors[-1]/reference,
                   'extrapolated_eigenvalue': extrapolated,
                   'extrapolated_absolute_error': abs(extrapolated-reference),
                   'extrapolated_qualified': order_ok and abs(extrapolated-reference) <= tolerance,
                   'qualified': order_ok and errors[-1] <= tolerance})
    return result

def main():
    root = Path(__file__).resolve().parent
    report = assess(json.loads((root/'samples.json').read_text()), json.loads((root/'config.json').read_text()))
    (root/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')

if __name__ == '__main__':
    main()
