import math
import unittest
from study import assess


class AssessmentTests(unittest.TestCase):
    def setUp(self):
        self.config = {'length': 1.7, 'tolerance': 1e-6, 'order_min': 1.8, 'order_max': 2.2}
        self.rows = [{'intervals': n, 'length': 1.7,
                      'eigenvalue': 4*n*n*math.sin(math.pi/(2*n))**2/1.7**2}
                     for n in (16, 32, 64, 128)]

    def test_actual_measurement_and_extrapolation_are_distinct(self):
        report = assess(self.rows, self.config)
        self.assertFalse(report['qualified'])
        self.assertTrue(report['order_qualified'])
        self.assertTrue(report['extrapolated_qualified'])
        self.assertEqual(report['numerical_eigenvalue'], self.rows[-1]['eigenvalue'])
        self.assertNotEqual(report['numerical_eigenvalue'], report['analytical_reference'])

    def test_stale_length_does_not_qualify(self):
        rows = [dict(r, length=1.0) for r in self.rows]
        report = assess(rows, self.config)
        self.assertFalse(report['data_match_config'])
        self.assertFalse(report['qualified'])

    def test_input_order_does_not_change_result(self):
        self.assertEqual(assess(self.rows, self.config), assess(self.rows[::-1], self.config))

    def test_duplicate_mesh_is_invalid(self):
        with self.assertRaises(ValueError):
            assess([self.rows[0]]*3, self.config)


if __name__ == '__main__':
    unittest.main()
