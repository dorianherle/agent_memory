# Runtime assessment

Three of four rows satisfy the residual limit of 0.000001. Accuracy coverage is 75%.
Matrix 2 has residual 0.001 and fails the accuracy limit.

Full online time includes load, prediction, correction, verification, and output.
The four times are 18, 20, 22, and 24 ms. The mean is 21 ms.
The baseline mean is 11.5 ms. The total-time speed ratio is 0.547619.
The learned solver is slower than the baseline. It does not qualify.
The speed ratio for accurate rows only is 0.548387. The report retains the failed row in overall coverage.

Four local unit tests passed. They check full online cost, failed accuracy, separate accuracy and speed results, and invalid inputs.
`study.py` ran without an error and wrote `report.json`. No hidden tests were run.

The task context contains no timing aggregation rule. I used total baseline time divided by total online time.
Training time is separate. The rows each list 100000 ms, but shared training and reuse count are unknown.
No amortized training cost is claimed. The supplied four rows do not establish general solver performance.

Next action: repair the failed accuracy case and repeat matched end-to-end measurements. Specify training reuse before an amortized comparison.
