import unittest
from study import summarize


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.row = {'matrix_id': 'a', 'load_ms': 2, 'predict_ms': 1,
                    'correct_ms': 8, 'verify_ms': 4, 'output_ms': 3,
                    'training_ms': 100000, 'baseline_ms': 10, 'residual': 1e-8}
        self.policy = {'residual_limit': 1e-6}

    def test_online_cost_includes_all_stages(self):
        report = summarize([self.row], self.policy)
        self.assertEqual(report['mean_online_ms'], 18)
        self.assertAlmostEqual(report['speedup'], 10/18)
        self.assertTrue(report['accuracy_qualified'])
        self.assertFalse(report['faster'])

    def test_failed_accuracy_stays_in_coverage(self):
        report = summarize([self.row, dict(self.row, matrix_id='b', residual=1e-3)], self.policy)
        self.assertEqual(report['accuracy_coverage'], 0.5)
        self.assertFalse(report['qualified'])
        self.assertEqual(report['total_count'], 2)

    def test_speed_and_accuracy_are_separate(self):
        report = summarize([dict(self.row, baseline_ms=100, residual=1e-3)], self.policy)
        self.assertTrue(report['faster'])
        self.assertFalse(report['accuracy_qualified'])
        self.assertIsNone(report['accurate_only_speedup'])

    def test_empty_and_invalid_rows(self):
        for rows in [[], [dict(self.row, output_ms=-1)], [dict(self.row, residual=float('nan'))]]:
            with self.assertRaises(ValueError):
                summarize(rows, self.policy)


if __name__ == '__main__':
    unittest.main()
