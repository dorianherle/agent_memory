import json
import math
import statistics
from pathlib import Path

def summarize(rows, policy):
    limit = float(policy['residual_limit'])
    if not math.isfinite(limit) or limit < 0 or not rows:
        raise ValueError('A valid residual limit and at least one row are required.')
    stages = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms')
    results = []
    for row in rows:
        values = {key: float(row[key]) for key in (*stages, 'baseline_ms', 'residual', 'training_ms')}
        if any(not math.isfinite(v) or v < 0 for v in values.values()):
            raise ValueError('Times and residuals must be finite and nonnegative.')
        elapsed = sum(values[key] for key in stages)
        if elapsed <= 0 or values['baseline_ms'] <= 0:
            raise ValueError('Online and baseline times must be positive.')
        results.append({'matrix_id': row['matrix_id'], 'online_ms': elapsed,
                        'baseline_ms': values['baseline_ms'], 'residual': values['residual'],
                        'accurate': values['residual'] <= limit,
                        'speedup': values['baseline_ms']/elapsed,
                        'training_ms': values['training_ms']})
    accurate = [row for row in results if row['accurate']]
    online_total, baseline_total = sum(r['online_ms'] for r in results), sum(r['baseline_ms'] for r in results)
    speedup = baseline_total / online_total
    return {'rows': results, 'total_count': len(results), 'accurate_count': len(accurate),
            'accuracy_coverage': len(accurate)/len(results), 'residual_limit': limit,
            'online_stages': list(stages), 'mean_online_ms': online_total/len(results),
            'median_online_ms': statistics.median(r['online_ms'] for r in results),
            'mean_baseline_ms': baseline_total/len(results), 'speedup': speedup,
            'speedup_metric': 'sum of baseline times divided by sum of full online times',
            'accurate_only_speedup': (sum(r['baseline_ms'] for r in accurate)/sum(r['online_ms'] for r in accurate)) if accurate else None,
            'accuracy_qualified': len(accurate) == len(results), 'faster': speedup > 1,
            'qualified': len(accurate) == len(results) and speedup > 1,
            'training_in_online_time': False,
            'training_note': 'Training is listed per row. Shared training and reuse count are unknown; no amortized total is claimed.'}

def main():
    root = Path(__file__).resolve().parent
    report = summarize(json.loads((root/'timings.json').read_text()), json.loads((root/'policy.json').read_text()))
    (root/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')

if __name__ == '__main__':
    main()
