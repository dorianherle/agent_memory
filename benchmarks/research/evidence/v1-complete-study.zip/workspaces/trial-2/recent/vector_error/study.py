import json
import math
from pathlib import Path

def field_error(predicted, reference):
    predicted, reference = list(predicted), list(reference)
    if not predicted or len(predicted) != len(reference):
        raise ValueError('Fields must have the same nonzero length.')
    try:
        predicted, reference = [complex(v) for v in predicted], [complex(v) for v in reference]
    except (TypeError, ValueError) as exc:
        raise ValueError('Each field must be a one-dimensional complex array.') from exc
    if any(not (math.isfinite(v.real) and math.isfinite(v.imag)) for v in predicted+reference):
        raise ValueError('Fields must be finite.')
    norm = math.hypot(*(abs(v) for v in reference))
    if norm == 0:
        raise ValueError('The reference norm must be nonzero.')
    # A single global phase is free. Relative component phases are retained.
    product = sum(p.conjugate()*r for p, r in zip(predicted, reference))
    phase = product / abs(product) if product else 1.0
    return math.hypot(*(abs(phase*p-r) for p, r in zip(predicted, reference))) / norm

def main():
    root = Path(__file__).resolve().parent
    fields = json.loads((root/'fields.json').read_text())
    policy = json.loads((root/'policy.json').read_text())
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('The error limit must be finite and nonnegative.')
    error = field_error([complex(*v) for v in fields['predicted']], [complex(*v) for v in fields['reference']])
    report = {'field_error': error, 'qualified': error <= limit, 'field_error_limit': limit,
              'metric': 'relative complex L2 error after one global phase alignment'}
    (root/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')

if __name__ == '__main__':
    main()
