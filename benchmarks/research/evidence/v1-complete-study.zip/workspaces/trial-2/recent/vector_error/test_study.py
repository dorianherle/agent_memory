import math
import unittest
from study import field_error


class FieldTests(unittest.TestCase):
    def test_single_global_phase(self):
        self.assertAlmostEqual(field_error([1j, 2j], [1, 2]), 0)

    def test_component_phase_is_not_free(self):
        self.assertAlmostEqual(field_error([1, 1j], [1, 1]), math.sqrt(2-math.sqrt(2)))

    def test_amplitude_error_remains(self):
        self.assertAlmostEqual(field_error([2, 4], [1, 2]), 1)

    def test_zero_prediction(self):
        self.assertAlmostEqual(field_error([0, 0], [1, 2]), 1)

    def test_invalid_inputs(self):
        for predicted, reference in [([], []), ([1], [1, 2]), ([1], [0]),
                                     ([float('nan')], [1]), ([[1]], [[1]])]:
            with self.assertRaises(ValueError):
                field_error(predicted, reference)


if __name__ == '__main__':
    unittest.main()
