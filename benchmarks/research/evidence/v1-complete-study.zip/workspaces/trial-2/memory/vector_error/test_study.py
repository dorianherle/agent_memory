import math
import unittest
from study import field_error


class FieldTests(unittest.TestCase):
    def test_global_scale_and_phase(self):
        reference = [1 + 2j, -3j, 4]
        self.assertLess(field_error([(-2 + 5j) * v for v in reference], reference), 1e-14)

    def test_relative_phase(self):
        self.assertAlmostEqual(field_error([1, 1j], [1, 1]), math.sqrt(2 - math.sqrt(2)))

    def test_missing_component(self):
        self.assertAlmostEqual(field_error([1, 0], [1, 1]), math.sqrt(2 - math.sqrt(2)))

    def test_orthogonal_vectors(self):
        self.assertAlmostEqual(field_error([1, 0], [0, 1]), math.sqrt(2))

    def test_large_and_small_scale(self):
        for scale in (1e-300, 1e300):
            self.assertLess(field_error([scale, scale * 1j], [1, 1j]), 1e-14)

    def test_invalid_arrays(self):
        for p, r in [([], []), ([0], [1]), ([1], [0]), ([1], [1, 2]),
                     ([[1]], [1]), ([1], [[1]]), ([float('nan')], [1]),
                     ([complex(1, float('inf'))], [1])]:
            with self.assertRaises(ValueError):
                field_error(p, r)


if __name__ == '__main__':
    unittest.main()
