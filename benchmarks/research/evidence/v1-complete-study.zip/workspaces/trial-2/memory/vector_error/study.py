import json
import math
from pathlib import Path

def field_error(predicted, reference):
    def unit_vector(values):
        if getattr(values, 'ndim', 1) != 1 or isinstance(values, (str, bytes)):
            raise ValueError('Fields must be one-dimensional complex arrays.')
        try:
            vector = [complex(value) for value in values]
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError('Fields must be one-dimensional complex arrays.') from error
        if not vector or any(not math.isfinite(v.real) or not math.isfinite(v.imag)
                             for v in vector):
            raise ValueError('Fields must be nonempty and finite.')
        scale = max(max(abs(v.real), abs(v.imag)) for v in vector)
        if scale == 0:
            raise ValueError('Field norm must be nonzero.')
        scaled = [v / scale for v in vector]
        norm = math.sqrt(math.fsum(abs(v) ** 2 for v in scaled))
        return [v / norm for v in scaled]

    p, r = unit_vector(predicted), unit_vector(reference)
    if len(p) != len(r):
        raise ValueError('Field lengths must be equal.')
    overlap = sum(rv.conjugate() * pv for pv, rv in zip(p, r))
    phase = overlap.conjugate() / abs(overlap) if overlap != 0 else 1
    return math.sqrt(math.fsum(abs(phase * pv - rv) ** 2 for pv, rv in zip(p, r)))

def main():
    root = Path(__file__).resolve().parent
    fields = json.loads((root / 'fields.json').read_text())
    policy = json.loads((root / 'policy.json').read_text())
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('Field error limit must be finite and nonnegative.')
    try:
        predicted = [complex(*pair) for pair in fields['predicted']]
        reference = [complex(*pair) for pair in fields['reference']]
    except (TypeError, ValueError, KeyError) as error:
        raise ValueError('JSON fields must contain real and imaginary pairs.') from error
    error = field_error(predicted, reference)
    report = {'field_error': error, 'qualified': error <= limit}
    (root / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
