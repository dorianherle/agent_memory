import copy
import json
import unittest
from pathlib import Path
from study import summarize


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.rows = json.loads((Path(__file__).parent / 'timings.json').read_text())
        self.policy = {'residual_limit': 1e-6}

    def test_current_data(self):
        result = summarize(self.rows, self.policy)
        self.assertEqual(result['attempted'], 4)
        self.assertEqual(result['qualified'], 3)
        self.assertEqual(result['median_attempt_ms'], 21)
        self.assertAlmostEqual(result['median_qualified_speedup'], 0.55)
        self.assertAlmostEqual(result['median_inference_speedup'], 4.75)
        self.assertEqual(result['baseline_contract'], 'construction_only')
        self.assertEqual(result['claim'], 'accuracy_limited')

    def test_offline_training_is_excluded(self):
        before = summarize(self.rows, self.policy)
        for row in self.rows:
            row['training_ms'] = 1e12
        self.assertEqual(summarize(self.rows, self.policy), before)

    def test_claims_and_failed_case_exclusion(self):
        for row in self.rows:
            row['residual'] = 1
        result = summarize(self.rows, self.policy)
        self.assertIsNone(result['median_qualified_speedup'])
        self.assertEqual(result['claim'], 'no_qualified_speedup')
        for row in self.rows:
            row['residual'] = self.policy['residual_limit']
        self.assertEqual(summarize(self.rows, self.policy)['claim'], 'slower_or_equal')
        for row in self.rows:
            row['baseline_ms'] = 100
        self.assertEqual(summarize(self.rows, self.policy)['claim'], 'faster')

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            summarize([], self.policy)
        for key, value in [('predict_ms', 0), ('baseline_ms', 0), ('load_ms', -1),
                           ('residual', float('nan')), ('training_ms', float('inf'))]:
            rows = copy.deepcopy(self.rows)
            rows[0][key] = value
            with self.assertRaises(ValueError):
                summarize(rows, self.policy)
        rows = copy.deepcopy(self.rows)
        del rows[0]['output_ms']
        with self.assertRaises(ValueError):
            summarize(rows, self.policy)
        with self.assertRaises(ValueError):
            summarize(self.rows, {'residual_limit': 0})


if __name__ == '__main__':
    unittest.main()
