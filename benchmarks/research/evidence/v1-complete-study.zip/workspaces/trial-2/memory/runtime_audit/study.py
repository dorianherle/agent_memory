import json
import math
from statistics import median
from pathlib import Path

def summarize(rows, policy):
    try:
        limit = float(policy['residual_limit'])
        if not math.isfinite(limit) or limit <= 0 or not rows:
            raise ValueError('Rows must be nonempty and the residual limit must be positive.')
        full_times, qualified_speedups, inference_speedups = [], [], []
        keys = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms',
                'training_ms', 'baseline_ms', 'residual')
        for row in rows:
            values = {key: float(row[key]) for key in keys}
            if not all(math.isfinite(value) and value >= 0 for value in values.values()):
                raise ValueError('Timing and residual values must be finite and nonnegative.')
            full_ms = sum(values[key] for key in keys[:5])
            if not math.isfinite(full_ms) or min(full_ms, values['predict_ms'], values['baseline_ms']) <= 0:
                raise ValueError('Full, prediction, and baseline times must be positive and finite.')
            full_times.append(full_ms)
            inference_speedups.append(values['baseline_ms'] / values['predict_ms'])
            if values['residual'] <= limit:
                qualified_speedups.append(values['baseline_ms'] / full_ms)
    except (KeyError, TypeError, OverflowError) as error:
        raise ValueError('Invalid runtime inputs.') from error
    qualified = len(qualified_speedups)
    speedup = median(qualified_speedups) if qualified else None
    claim = ('no_qualified_speedup' if not qualified else
             'accuracy_limited' if qualified < len(rows) else
             'faster' if speedup > 1 else 'slower_or_equal')
    return {'attempted': len(rows), 'qualified': qualified,
            'median_attempt_ms': median(full_times),
            'median_qualified_speedup': speedup,
            'median_inference_speedup': median(inference_speedups),
            'baseline_contract': 'construction_only', 'claim': claim}

def main():
    root = Path(__file__).resolve().parent
    rows = json.loads((root / 'timings.json').read_text())
    policy = json.loads((root / 'policy.json').read_text())
    report = summarize(rows, policy)
    (root / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
