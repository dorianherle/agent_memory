Three of four attempts meet the residual limit of 1e-6. The median full attempt time is 21 ms. The median speed ratio for accurate results is 0.55. The median inference-only ratio is 4.75. The report claim is `accuracy_limited`.

The full attempt includes loading, prediction, correction, verification, and output. Offline training is excluded. Failed cases remain in the attempt count and median attempt time. Only accurate results enter the full speed comparison. The baseline contract is `construction_only`.

Full saved notes 989ab38c, eba617f2, and 3ddabac2 supplied the workload and reporting rules. The current timing file contains one failed accuracy case. The other three cases are slower than their construction baselines when all attempt costs are included.

Checks: `study.py` completed. All four tests in `test_study.py` passed with the assigned Python runtime. Tests cover the current data, offline training exclusion, all claim states, failed-case handling, and invalid inputs. No hidden tests were run.

Limits: These four supplied attempts do not establish general speed or accuracy. The baseline covers inverse construction only. The inference ratio is a separate timing result and does not establish faster full construction.

Next action: Correct the failed accuracy case and reduce the full construction cost. Collect more timing data under the same workload before a broader speed claim.
