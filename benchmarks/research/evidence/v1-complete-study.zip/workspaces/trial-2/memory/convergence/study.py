import json
import math
import subprocess
import sys
from pathlib import Path

def assess(records, config):
    try:
        length, tolerance = float(config['length']), float(config['tolerance'])
        order_min, order_max = float(config['order_min']), float(config['order_max'])
        if not all(math.isfinite(v) and v > 0 for v in
                   (length, tolerance, order_min, order_max)) or order_min > order_max:
            raise ValueError('Invalid convergence configuration.')
        if len(records) < 3:
            raise ValueError('At least three records are required.')
        values = []
        for record in records:
            n, geometry, value = (float(record[k]) for k in
                                  ('intervals', 'length', 'eigenvalue'))
            if not all(math.isfinite(v) and v > 0 for v in (n, geometry, value)):
                raise ValueError('Record values must be finite and positive.')
            if not n.is_integer() or geometry != length:
                raise ValueError('Records must use integer grids and the current length.')
            values.append((n, value))
    except (KeyError, TypeError, OverflowError) as error:
        raise ValueError('Invalid convergence inputs.') from error
    values.sort()
    coarse, middle, fine = values[-3:]
    if middle[0] != 2 * coarse[0] or fine[0] != 2 * middle[0]:
        raise ValueError('The three finest grids must double.')
    first, second = abs(coarse[1] - middle[1]), abs(middle[1] - fine[1])
    if first == 0 or second == 0:
        raise ValueError('Convergence differences must be nonzero.')
    observed_order = math.log2(first) - math.log2(second)
    if not math.isfinite(observed_order) or observed_order <= 0:
        raise ValueError('Observed order must be finite and positive.')
    try:
        extrapolated = fine[1] + (fine[1] - middle[1]) / math.expm1(observed_order * math.log(2))
        analytical = (math.pi / length) ** 2
        relative_error = abs(extrapolated - analytical) / analytical
    except (OverflowError, ZeroDivisionError) as error:
        raise ValueError('Convergence calculation is not finite.') from error
    if not all(math.isfinite(v) for v in (extrapolated, analytical, relative_error)):
        raise ValueError('Convergence calculation is not finite.')
    return {'observed_order': observed_order, 'extrapolated': extrapolated,
            'relative_error': relative_error,
            'qualified': order_min <= observed_order <= order_max and relative_error <= tolerance}

def main():
    root = Path(__file__).resolve().parent
    config = json.loads((root / 'config.json').read_text())
    records = json.loads((root / 'samples.json').read_text())
    if any(record.get('length') != config['length'] for record in records):
        subprocess.run([sys.executable, str(root / 'measure.py')], cwd=root, check=True)
        records = json.loads((root / 'samples.json').read_text())
    report = assess(records, config)
    (root / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
