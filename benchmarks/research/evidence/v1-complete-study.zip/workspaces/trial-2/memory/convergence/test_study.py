import copy
import json
import math
import unittest
from pathlib import Path
from study import assess


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        self.config = {'length': 1.7, 'tolerance': 1e-6, 'order_min': 1.8, 'order_max': 2.2}
        self.exact = (math.pi / 1.7) ** 2

    def records(self, order):
        return [{'intervals': n, 'length': 1.7, 'eigenvalue': self.exact - 1 / n ** order}
                for n in (16, 32, 64, 128)]

    def test_second_order_and_input_order(self):
        result = assess(list(reversed(self.records(2))), self.config)
        self.assertAlmostEqual(result['observed_order'], 2, places=9)
        self.assertAlmostEqual(result['extrapolated'], self.exact)
        self.assertTrue(result['qualified'])

    def test_first_order_cannot_qualify(self):
        result = assess(self.records(1), self.config)
        self.assertAlmostEqual(result['observed_order'], 1)
        self.assertLess(result['relative_error'], 1e-6)
        self.assertFalse(result['qualified'])

    def test_current_tolerance_controls_result(self):
        records = self.records(2)
        for record in records:
            record['eigenvalue'] += 1e-5
        self.assertFalse(assess(records, self.config)['qualified'])
        config = dict(self.config, tolerance=1e-4)
        self.assertTrue(assess(records, config)['qualified'])

    def test_invalid_records(self):
        mutations = [lambda r: r.pop(), lambda r: r[0].update(length=1),
                     lambda r: r[-1].update(intervals=127),
                     lambda r: r[-1].update(eigenvalue=float('nan')),
                     lambda r: r[-1].update(eigenvalue=r[-2]['eigenvalue']),
                     lambda r: r[-1].update(eigenvalue=r[-2]['eigenvalue'] + 1)]
        for mutate in mutations:
            records = self.records(2)
            mutate(records)
            if len(records) == 3:
                records.pop()
            with self.assertRaises(ValueError):
                assess(records, self.config)

    def test_current_measurements_use_current_geometry(self):
        root = Path(__file__).parent
        records = json.loads((root / 'samples.json').read_text())
        config = json.loads((root / 'config.json').read_text())
        self.assertTrue(all(r['length'] == config['length'] for r in records))
        self.assertTrue(assess(records, config)['qualified'])


if __name__ == '__main__':
    unittest.main()
