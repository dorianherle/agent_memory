The cavity result meets the current limits. The observed order is 1.9995654545. The extrapolated eigenvalue is 3.4150880831. The relative error is 1.61316e-8. The allowed error is 1e-6, and the allowed order is 1.8 to 2.2.

The stored samples used length 1.0. `main()` ran the supplied `measure.py` and replaced those samples with measurements for length 1.7. `assess()` uses the three finest grids and observed-order Richardson extrapolation. It keeps the measurements separate from the analytical reference. It rejects a different geometry.

Full saved notes 48fd3a2a and 1b55b030 supplied the calculation and regeneration rules. Current files confirmed the old sample length and the new configuration.

Checks: `study.py` completed. All five tests in `test_study.py` passed with the assigned Python runtime. Tests cover second-order convergence, first-order rejection, tolerance changes, invalid records, and the current sample geometry. No hidden tests were run.

Limits: The result applies to the supplied numerical cavity model and grid series. It does not establish accuracy for a different model or geometry.

Next action: Add a finer grid measurement if more evidence for the convergence estimate is required.
