The API `summarize(rows, policy)` is complete. `main()` reads the current input files and writes `report.json`. The inputs and policy are unchanged.

Three of four cases meet the residual limit, 0.000001. Accuracy coverage is 0.75. Case 1 has residual 0.001 and fails. Full accuracy qualification is false.

Online time includes load, prediction, correction, verification, and output. The case times are 18, 20, 22, and 24 ms. All attempted cases remain in the speed calculation. Total online time is 84 ms. Total baseline time is 46 ms. The speed ratio is 46/84 = 0.547619. The learned solver takes more online time than the baseline. Median times are 21 ms and 11.5 ms.

Training time is 100000 ms in each record. The report retains these values separately. The inputs do not identify shared training runs or a workload over which to distribute training cost. No training-cost or break-even claim is supported.

Seven local tests passed with the required Python runtime. The tests check complete online cost, failed-case inclusion, independent accuracy and speed, visible training cost, the residual boundary, invalid data, and report output. Command: `python -m unittest -v test_study.py`.

The context contains only display updates. It does not retain the timing protocol. I assumed that stage times can be added. Baseline timing scope, repeated-run variation, and fallback cost are unknown. The speed ratio is a timing comparison for all attempted cases. It is not evidence of equal accuracy.

Next action: obtain equal timing scopes and repeated measurements. Repair the failed solve or measure its fallback cost. Identify the training run and intended workload before a full cost audit. No hidden tests were available.
