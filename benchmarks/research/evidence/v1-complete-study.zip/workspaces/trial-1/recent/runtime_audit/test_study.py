import copy
import json
import unittest
from pathlib import Path

from study import summarize, main


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        base = Path(__file__).resolve().parent
        self.rows = json.loads((base / 'timings.json').read_text())
        self.policy = json.loads((base / 'policy.json').read_text())

    def test_online_cost_and_coverage(self):
        before = copy.deepcopy(self.rows)
        result = summarize(self.rows, self.policy)
        self.assertEqual(self.rows, before)
        self.assertEqual([case['online_ms'] for case in result['cases']], [18, 20, 22, 24])
        self.assertEqual(result['accuracy_coverage'], 0.75)
        self.assertEqual(result['accurate_count'], 3)
        self.assertFalse(result['accuracy_qualified'])
        self.assertAlmostEqual(result['speedup'], 46 / 84)
        self.assertFalse(result['faster_than_baseline'])

    def test_failed_case_remains_in_speed_summary(self):
        changed = copy.deepcopy(self.rows)
        changed[1]['correct_ms'] = 109
        result = summarize(changed, self.policy)
        self.assertEqual(result['online_total_ms'], 184)
        self.assertEqual(result['accuracy_coverage'], 0.75)

    def test_accuracy_and_speed_are_independent(self):
        changed = copy.deepcopy(self.rows)
        for row in changed:
            row['residual'] = 0
        result = summarize(changed, self.policy)
        self.assertTrue(result['accuracy_qualified'])
        self.assertFalse(result['faster_than_baseline'])
        self.assertAlmostEqual(result['speedup'], 46 / 84)

    def test_training_is_visible_but_not_online(self):
        changed = copy.deepcopy(self.rows)
        changed[0]['training_ms'] *= 2
        result = summarize(changed, self.policy)
        self.assertEqual(result['online_total_ms'], 84)
        self.assertEqual(result['training_ms_by_case'][0], 200000)

    def test_residual_limit_is_inclusive(self):
        changed = copy.deepcopy(self.rows)
        changed[1]['residual'] = self.policy['residual_limit']
        self.assertTrue(summarize(changed, self.policy)['accuracy_qualified'])

    def test_invalid_input_is_rejected(self):
        with self.assertRaises(ValueError):
            summarize([], self.policy)
        changed = copy.deepcopy(self.rows)
        changed[0]['load_ms'] = -1
        with self.assertRaises(ValueError):
            summarize(changed, self.policy)

    def test_main_writes_report(self):
        main()
        report = json.loads(Path(__file__).with_name('report.json').read_text())
        self.assertEqual(report['failed_count'], 1)


if __name__ == '__main__':
    unittest.main()
