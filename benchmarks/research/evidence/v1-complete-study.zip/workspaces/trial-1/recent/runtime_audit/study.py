import json
import math
import statistics
from pathlib import Path

def summarize(rows, policy):
    """Keep accuracy coverage separate from speed for all attempted solves."""
    limit = float(policy['residual_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('The residual limit must be finite and nonnegative.')
    rows = list(rows)
    if not rows:
        raise ValueError('At least one timing record is necessary.')
    stages = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms')
    cases = []
    for row in rows:
        values = {key: float(row[key]) for key in (*stages, 'training_ms', 'baseline_ms', 'residual')}
        if any(not math.isfinite(value) or value < 0 for value in values.values()):
            raise ValueError('Times and residuals must be finite and nonnegative.')
        if values['baseline_ms'] == 0 or sum(values[key] for key in stages) == 0:
            raise ValueError('Baseline and online times must be positive.')
        online = sum(values[key] for key in stages)
        cases.append({
            'matrix_id': row['matrix_id'],
            **values,
            'online_ms': online,
            'speedup': values['baseline_ms'] / online,
            'accurate': values['residual'] <= limit,
        })
    passed = sum(case['accurate'] for case in cases)
    online_total = sum(case['online_ms'] for case in cases)
    baseline_total = sum(case['baseline_ms'] for case in cases)
    online_median = statistics.median(case['online_ms'] for case in cases)
    baseline_median = statistics.median(case['baseline_ms'] for case in cases)
    return {
        'case_count': len(cases),
        'accurate_count': passed,
        'failed_count': len(cases) - passed,
        'accuracy_coverage': passed / len(cases),
        'residual_limit': limit,
        'accuracy_qualified': passed == len(cases),
        'online_stages': list(stages),
        'online_total_ms': online_total,
        'baseline_total_ms': baseline_total,
        'online_median_ms': online_median,
        'baseline_median_ms': baseline_median,
        'speedup': baseline_total / online_total,
        'speedup_basis': 'total baseline time / total online time for all attempted cases',
        'median_speedup': baseline_median / online_median,
        'faster_than_baseline': baseline_total > online_total,
        'training_ms_by_case': [case['training_ms'] for case in cases],
        'training_limit': 'Training is excluded from online time. The inputs do not identify shared training runs or an amortization workload.',
        'method_limit': 'The task context does not retain the timing protocol. Stage times are assumed additive and baseline scope is unverified.',
        'cases': cases,
    }

def main():
    base = Path(__file__).resolve().parent
    result = summarize(json.loads((base / 'timings.json').read_text()),
                       json.loads((base / 'policy.json').read_text()))
    (base / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
