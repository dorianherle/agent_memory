import json
import math
from pathlib import Path

def field_error(predicted, reference):
    """Return ||predicted-reference||_2 / ||reference||_2 for complex fields.

    Preserve phase and amplitude. Do not independently align sample phases.
    """
    try:
        predicted = [complex(value) for value in predicted]
        reference = [complex(value) for value in reference]
    except (TypeError, ValueError) as exc:
        raise ValueError('Inputs must be one-dimensional complex arrays.') from exc
    if not reference or len(predicted) != len(reference):
        raise ValueError('Inputs must be nonempty and have equal lengths.')
    if any(not (math.isfinite(x.real) and math.isfinite(x.imag)) for x in predicted + reference):
        raise ValueError('Field components must be finite.')
    reference_norm = math.hypot(*(abs(value) for value in reference))
    if reference_norm == 0:
        raise ValueError('Relative error is undefined for a zero reference field.')
    difference_norm = math.hypot(*(abs(p - r) for p, r in zip(predicted, reference)))
    return difference_norm / reference_norm

def main():
    base = Path(__file__).resolve().parent
    fields = json.loads((base / 'fields.json').read_text())
    policy = json.loads((base / 'policy.json').read_text())
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('The field error limit must be finite and nonnegative.')
    predicted = [complex(*value) for value in fields['predicted']]
    reference = [complex(*value) for value in fields['reference']]
    error = field_error(predicted, reference)
    report = {
        'field_error': error,
        'field_error_limit': limit,
        'qualified': error <= limit,
        'method': 'relative complex L2 norm; phase and amplitude are retained',
        'method_limit': 'The task context does not retain a norm or phase convention. This assessment assumes a common phase reference.',
    }
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
