import json
import math
import unittest
from pathlib import Path

from study import field_error, main


class FieldTests(unittest.TestCase):
    def test_relative_phase_error_is_detected(self):
        self.assertAlmostEqual(field_error([1, -1], [1, 1]), math.sqrt(2))

    def test_complex_components_are_retained(self):
        self.assertAlmostEqual(field_error([1j], [1]), math.sqrt(2))
        self.assertEqual(field_error([1 + 2j, -3j], [1 + 2j, -3j]), 0)

    def test_amplitude_error_is_retained(self):
        self.assertAlmostEqual(field_error([2 + 2j], [1 + 1j]), 1)

    def test_shared_scale_preserves_relative_error(self):
        self.assertAlmostEqual(field_error([20, -20], [20, 20]), math.sqrt(2))

    def test_invalid_arrays_are_rejected(self):
        for predicted, reference in (([], []), ([1], [1, 2]), ([1], [0]),
                                      ([[1]], [[1]]), ([float('nan')], [1])):
            with self.assertRaises(ValueError):
                field_error(predicted, reference)

    def test_main_writes_failed_assessment(self):
        main()
        report = json.loads(Path(__file__).with_name('report.json').read_text())
        self.assertAlmostEqual(report['field_error'], math.sqrt(2))
        self.assertFalse(report['qualified'])


if __name__ == '__main__':
    unittest.main()
