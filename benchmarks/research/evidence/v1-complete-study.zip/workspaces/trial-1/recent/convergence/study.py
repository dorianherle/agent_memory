import json
import math
from pathlib import Path

def assess(records, config):
    """Check uniform refinement and a second-order Richardson estimate.

    Estimate the order from numerical differences only. Use the analytical
    reference only after the numerical estimate is complete.
    """
    length = float(config['length'])
    tolerance = float(config['tolerance'])
    lower, upper = float(config['order_min']), float(config['order_max'])
    if not all(math.isfinite(x) for x in (length, tolerance, lower, upper)):
        raise ValueError('Config values must be finite.')
    if length <= 0 or tolerance < 0 or lower > upper:
        raise ValueError('Invalid length, tolerance, or order bounds.')
    data = sorted((dict(row) for row in records), key=lambda row: row['intervals'])
    if len(data) < 3:
        raise ValueError('At least three measurements are necessary.')
    for row in data:
        n = row['intervals']
        if isinstance(n, bool) or int(n) != n or n <= 0:
            raise ValueError('Intervals must be positive integers.')
        if not math.isclose(float(row['length']), length, rel_tol=1e-12, abs_tol=0):
            raise ValueError('Measurements use a different cavity length. Regenerate samples.')
        if not math.isfinite(float(row['eigenvalue'])):
            raise ValueError('Eigenvalues must be finite.')
    ratios = [b['intervals'] / a['intervals'] for a, b in zip(data, data[1:])]
    if ratios[0] <= 1 or any(not math.isclose(r, ratios[0], rel_tol=1e-12) for r in ratios):
        raise ValueError('A constant refinement ratio greater than one is necessary.')
    ratio = ratios[0]
    differences = [b['eigenvalue'] - a['eigenvalue'] for a, b in zip(data, data[1:])]
    if any(d == 0 for d in differences) or any(a * b <= 0 for a, b in zip(differences, differences[1:])):
        raise ValueError('Differences cannot support an observed convergence order.')
    orders = [math.log(abs(a / b)) / math.log(ratio) for a, b in zip(differences, differences[1:])]
    observed_order = orders[-1]
    # The uniform central-difference measurement has second-order truncation.
    assumed_order = 2.0
    finest = float(data[-1]['eigenvalue'])
    extrapolated = finest + differences[-1] / (ratio ** assumed_order - 1)
    reference = (math.pi / length) ** 2
    raw_error = abs(finest - reference)
    estimate_error = abs(extrapolated - reference)
    order_qualified = all(lower <= order <= upper for order in orders)
    return {
        'length': length,
        'measurements': data,
        'analytical_reference': reference,
        'refinement_ratio': ratio,
        'observed_orders': orders,
        'observed_order': observed_order,
        'assumed_extrapolation_order': assumed_order,
        'finest_eigenvalue': finest,
        'finest_absolute_error': raw_error,
        'finest_qualified': raw_error <= tolerance,
        'extrapolated_eigenvalue': extrapolated,
        'extrapolated_absolute_error': estimate_error,
        'tolerance': tolerance,
        'order_qualified': order_qualified,
        'qualified': order_qualified and estimate_error <= tolerance,
        'qualification_target': 'second-order Richardson extrapolation; absolute eigenvalue error',
        'method_limit': 'The task context does not retain a method. The second-order estimate is an explicit assumption based on measure.py.',
    }

def main():
    base = Path(__file__).resolve().parent
    result = assess(json.loads((base / 'samples.json').read_text()),
                    json.loads((base / 'config.json').read_text()))
    (base / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
