import copy
import json
import math
import unittest
from pathlib import Path

from study import assess, main


class ConvergenceTests(unittest.TestCase):
    def setUp(self):
        base = Path(__file__).resolve().parent
        self.config = json.loads((base / 'config.json').read_text())
        self.records = json.loads((base / 'samples.json').read_text())

    def test_current_measurements_and_reference_remain_separate(self):
        before = copy.deepcopy(self.records)
        result = assess(self.records, self.config)
        self.assertEqual(self.records, before)
        self.assertEqual(result['measurements'], before)
        self.assertTrue(result['qualified'])
        self.assertFalse(result['finest_qualified'])
        self.assertTrue(1.8 <= result['observed_order'] <= 2.2)
        self.assertAlmostEqual(result['analytical_reference'], (math.pi / 1.2) ** 2)

    def test_stale_length_is_rejected(self):
        stale = copy.deepcopy(self.records)
        stale[0]['length'] = 1.0
        with self.assertRaisesRegex(ValueError, 'different cavity length'):
            assess(stale, self.config)

    def test_order_comes_from_measurements(self):
        reference = (math.pi / self.config['length']) ** 2
        first_order = [dict(row, eigenvalue=reference - 1 / row['intervals']) for row in self.records]
        result = assess(first_order, self.config)
        self.assertAlmostEqual(result['observed_order'], 1)
        self.assertFalse(result['qualified'])

    def test_measurement_changes_affect_estimate(self):
        changed = copy.deepcopy(self.records)
        changed[-1]['eigenvalue'] += 1e-4
        self.assertNotEqual(assess(changed, self.config)['extrapolated_eigenvalue'],
                            assess(self.records, self.config)['extrapolated_eigenvalue'])

    def test_invalid_refinement_is_rejected(self):
        changed = copy.deepcopy(self.records)
        changed[-1]['intervals'] = 130
        with self.assertRaises(ValueError):
            assess(changed, self.config)

    def test_main_writes_report(self):
        main()
        result = json.loads(Path(__file__).with_name('report.json').read_text())
        self.assertTrue(result['qualified'])


if __name__ == '__main__':
    unittest.main()
