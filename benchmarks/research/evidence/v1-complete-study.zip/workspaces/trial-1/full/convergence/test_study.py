import copy
import math
import unittest
from study import assess

class AssessmentTests(unittest.TestCase):
    def setUp(self):
        self.config = {'length': 1.2, 'tolerance': 1e-6, 'order_min': 1.8, 'order_max': 2.2}
        exact = (math.pi / 1.2) ** 2
        self.records = [{'intervals': n, 'length': 1.2, 'eigenvalue': exact + 2 / n**2}
                        for n in (16, 32, 64, 128)]

    def test_observed_order_and_finest_records(self):
        self.records[0]['eigenvalue'] += 1
        report = assess(list(reversed(self.records)), self.config)
        self.assertAlmostEqual(report['observed_order'], 2)
        self.assertAlmostEqual(report['extrapolated'], (math.pi / 1.2)**2)
        self.assertTrue(report['qualified'])

    def test_first_order_is_rejected(self):
        for row in self.records:
            row['eigenvalue'] = (math.pi / 1.2)**2 + 1e-5 / row['intervals']
        report = assess(self.records, self.config)
        self.assertLess(report['relative_error'], self.config['tolerance'])
        self.assertFalse(report['qualified'])

    def test_invalid_inputs(self):
        bad_sets = [self.records[:2]]
        for key, value in [('length', 1.0), ('intervals', 30), ('eigenvalue', 0),
                           ('eigenvalue', float('nan')), ('length', -1)]:
            rows = copy.deepcopy(self.records)
            rows[1][key] = value
            bad_sets.append(rows)
        rows = copy.deepcopy(self.records)
        rows[-1]['eigenvalue'] = rows[-2]['eigenvalue']
        bad_sets.append(rows)
        rows = copy.deepcopy(self.records)
        for row, value in zip(rows, (1, 2, 4, 8)):
            row['eigenvalue'] = value
        bad_sets.append(rows)
        for rows in bad_sets:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                assess(rows, self.config)
        for key in self.config:
            config = dict(self.config, **{key: float('inf')})
            with self.subTest(key=key), self.assertRaises(ValueError):
                assess(self.records, config)

if __name__ == '__main__':
    unittest.main()
