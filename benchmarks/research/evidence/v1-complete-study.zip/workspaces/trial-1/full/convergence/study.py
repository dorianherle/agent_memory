import json
import math
import subprocess
import sys
from pathlib import Path

def _positive(value, name):
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be a finite positive number') from exc
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f'{name} must be a finite positive number')
    return result

def assess(records, config):
    if len(records) < 3:
        raise ValueError('At least three records are required')
    try:
        length = _positive(config['length'], 'length')
        tolerance = _positive(config['tolerance'], 'tolerance')
        order_min = _positive(config['order_min'], 'order_min')
        order_max = _positive(config['order_max'], 'order_max')
        values = [(_positive(r['intervals'], 'intervals'),
                   _positive(r['length'], 'sample length'),
                   _positive(r['eigenvalue'], 'eigenvalue')) for r in records]
    except (KeyError, TypeError) as exc:
        raise ValueError('Required numerical inputs are missing') from exc
    if order_min > order_max:
        raise ValueError('The order limits are reversed')
    values.sort(key=lambda r: r[0])
    if any(r[1] != length for r in values):
        raise ValueError('All sample lengths must equal the configuration length')
    if any(b[0] != 2 * a[0] for a, b in zip(values, values[1:])):
        raise ValueError('The grids must double at each refinement')
    coarse, middle, fine = [r[2] for r in values[-3:]]
    first, second = abs(coarse - middle), abs(middle - fine)
    if first == 0 or second == 0:
        raise ValueError('Refinement differences must be nonzero')
    observed_order = math.log2(first) - math.log2(second)
    if not math.isfinite(observed_order) or observed_order <= 0:
        raise ValueError('The observed order must be finite and positive')
    try:
        extrapolated = fine + (fine - middle) / math.expm1(observed_order * math.log(2))
        analytical_reference = (math.pi / length) ** 2
        relative_error = abs(extrapolated - analytical_reference) / analytical_reference
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError('The assessment exceeds the numerical range') from exc
    if not all(math.isfinite(x) for x in (extrapolated, analytical_reference, relative_error)):
        raise ValueError('The assessment must be finite')
    return {'observed_order': observed_order, 'extrapolated': extrapolated,
            'relative_error': relative_error,
            'qualified': order_min <= observed_order <= order_max and relative_error <= tolerance}

def main():
    directory = Path(__file__).resolve().parent
    config = json.loads((directory / 'config.json').read_text())
    records = json.loads((directory / 'samples.json').read_text())
    length = _positive(config['length'], 'length')
    if any(r.get('length') != length for r in records):
        subprocess.run([sys.executable, str(directory / 'measure.py')], cwd=directory, check=True)
        records = json.loads((directory / 'samples.json').read_text())
    report = assess(records, config)
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
