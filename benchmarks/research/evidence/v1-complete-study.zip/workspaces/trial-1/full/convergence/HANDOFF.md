# Cavity study

The study is complete. `main()` found samples for length 1.0 and ran the supplied `measure.py`. All current samples use length 1.2.

The assessment uses the three finest grids: 32, 64, and 128 intervals. Observed order is 1.9995654545089394. The extrapolated eigenvalue is 6.853892055765409. Relative error is 1.6131632366384717e-08. The result meets the current order limits and tolerance of 1e-6.

The analytical reference is used only for the relative error. The study does not replace numerical measurements with that reference.

Checks: three local unit tests passed. They check observed-order extrapolation, selection of the finest grids, first-order rejection, and invalid inputs. `study.py` ran successfully and wrote `report.json`. The regenerated sample file was checked. No hidden tests were run.

Limits: this result applies to the supplied one-dimensional cavity measurements and current configuration. It does not establish convergence for other geometries or solvers. `assess()` requires every sample length to match the configuration.

Next action: use the report for this configuration. Run the study again after a configuration or measurement change.
