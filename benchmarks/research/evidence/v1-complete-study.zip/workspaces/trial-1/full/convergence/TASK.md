Finish the cavity convergence study in study.py. Implement assess(records, config) and main(). main writes report.json. Keep the numerical measurements separate from the analytical reference.

Continue from context.txt. Check the current data. Write a short HANDOFF.md with the result, tests, limits, and next action.
