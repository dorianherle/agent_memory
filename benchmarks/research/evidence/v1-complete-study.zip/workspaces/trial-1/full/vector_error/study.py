import json
import math
from pathlib import Path
import numpy as np

def _unit_vector(values):
    try:
        vector = np.asarray(values, dtype=np.complex128)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('The vector must contain complex numbers') from exc
    if vector.ndim != 1 or vector.size == 0:
        raise ValueError('The vector must be nonempty and one-dimensional')
    if not np.isfinite(vector).all():
        raise ValueError('The vector must be finite')
    # Scale first to avoid overflow or underflow in the L2 norm.
    scale = max(float(np.max(np.abs(vector.real))), float(np.max(np.abs(vector.imag))))
    if scale == 0:
        raise ValueError('The vector norm must be nonzero')
    scaled = vector / scale
    return scaled / np.linalg.norm(scaled)

def field_error(predicted, reference):
    predicted_unit = _unit_vector(predicted)
    reference_unit = _unit_vector(reference)
    if predicted_unit.size != reference_unit.size:
        raise ValueError('The vectors must have equal lengths')
    overlap = np.vdot(predicted_unit, reference_unit)
    phase = overlap / abs(overlap) if abs(overlap) > 0 else 1.0
    return float(np.linalg.norm(phase * predicted_unit - reference_unit))

def main():
    directory = Path(__file__).resolve().parent
    fields = json.loads((directory / 'fields.json').read_text())
    policy = json.loads((directory / 'policy.json').read_text())
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('The field error limit must be finite and nonnegative')
    def decode(pairs):
        if any(not isinstance(pair, list) or len(pair) != 2 for pair in pairs):
            raise ValueError('Each field value must have a real and an imaginary part')
        return [complex(real, imag) for real, imag in pairs]
    error = field_error(decode(fields['predicted']), decode(fields['reference']))
    report = {'field_error': error, 'qualified': error <= limit}
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
