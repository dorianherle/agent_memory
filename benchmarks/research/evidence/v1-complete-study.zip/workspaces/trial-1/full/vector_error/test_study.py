import math
import unittest
import numpy as np
from study import field_error

class FieldTests(unittest.TestCase):
    def test_global_scale_and_phase(self):
        reference = np.array([1 + 2j, -3j, 0.5])
        for scale in (1e-200, 3, 1e200):
            with self.subTest(scale=scale):
                self.assertLess(field_error(reference * scale * np.exp(0.8j), reference), 1e-14)

    def test_relative_phase_and_amplitude(self):
        self.assertAlmostEqual(field_error([1, -1], [1, 1]), math.sqrt(2))
        self.assertGreater(field_error([1, 0], [1, 1]), 0.7)
        self.assertGreater(field_error([1, 2], [1, 1]), 0.3)
        self.assertAlmostEqual(field_error([1, 0], [0, 1]), math.sqrt(2))

    def test_invalid_inputs(self):
        for predicted, reference in [([], []), ([1], [1, 2]), ([[1]], [[1]]),
                                     ([0, 0], [1, 1]), ([1], [0]),
                                     ([float('nan')], [1]), ([1], [complex(0, float('inf'))])]:
            with self.subTest(predicted=predicted, reference=reference), self.assertRaises(ValueError):
                field_error(predicted, reference)

if __name__ == '__main__':
    unittest.main()
