# Runtime audit

The audit is complete. Three of four attempts pass the residual limit of 1e-6. Matrix 1 fails with residual 0.001. The claim is `accuracy_limited`.

Median full attempt time is 21.0 ms across all four rows. Each full attempt includes loading, prediction, correction, verification, and output. Training is offline and excluded.

Median qualified speed ratio is 0.5454545454545454. The qualified attempts are slower than the baseline at this median. Median inference-only speed ratio is 4.75 across all rows. These are separate results. The baseline contract is `construction_only`.

Checks: three local unit tests passed. They check full cost, failed-row retention, qualified speed ratios, inference ratios, offline training exclusion, claim selection, boundary residuals, and invalid inputs. `study.py` ran successfully and wrote `report.json`. The report was checked. No hidden tests were run.

Limits: the audit uses four supplied timing rows. No new timing measurements were made. The study requires the named numerical fields, including `training_ms`, and validates them. It does not change the workload to reusable solves.

Next action: improve accuracy coverage and full construction cost before a new speed claim. Keep the failed attempt in the evidence.
