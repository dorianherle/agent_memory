import json
import math
from pathlib import Path
from statistics import median

def _nonnegative(value, name):
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be a finite nonnegative number') from exc
    if not math.isfinite(result) or result < 0:
        raise ValueError(f'{name} must be a finite nonnegative number')
    return result

def summarize(rows, policy):
    if not rows:
        raise ValueError('At least one timing row is required')
    try:
        limit = _nonnegative(policy['residual_limit'], 'residual_limit')
        if limit == 0:
            raise ValueError('The residual limit must be positive')
        required = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms',
                    'output_ms', 'training_ms', 'baseline_ms', 'residual')
        values = [{key: _nonnegative(row[key], key) for key in required} for row in rows]
    except (KeyError, TypeError) as exc:
        raise ValueError('Required numerical inputs are missing') from exc
    attempts, qualified_speedups, inference_speedups = [], [], []
    for row in values:
        full_ms = sum(row[key] for key in ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms'))
        if not math.isfinite(full_ms) or min(full_ms, row['predict_ms'], row['baseline_ms']) <= 0:
            raise ValueError('Attempt, prediction, and baseline times must be finite and positive')
        attempts.append(full_ms)
        inference_speedups.append(row['baseline_ms'] / row['predict_ms'])
        if row['residual'] <= limit:
            qualified_speedups.append(row['baseline_ms'] / full_ms)
    if not all(math.isfinite(x) for x in inference_speedups + qualified_speedups):
        raise ValueError('Speed ratios must be finite')
    qualified = len(qualified_speedups)
    qualified_median = median(qualified_speedups) if qualified else None
    if qualified == 0:
        claim = 'no_qualified_speedup'
    elif qualified < len(values):
        claim = 'accuracy_limited'
    else:
        claim = 'faster' if qualified_median > 1 else 'slower_or_equal'
    return {'attempted': len(values), 'qualified': qualified,
            'median_attempt_ms': median(attempts),
            'median_qualified_speedup': qualified_median,
            'median_inference_speedup': median(inference_speedups),
            'baseline_contract': 'construction_only', 'claim': claim}

def main():
    directory = Path(__file__).resolve().parent
    rows = json.loads((directory / 'timings.json').read_text())
    policy = json.loads((directory / 'policy.json').read_text())
    report = summarize(rows, policy)
    (directory / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
