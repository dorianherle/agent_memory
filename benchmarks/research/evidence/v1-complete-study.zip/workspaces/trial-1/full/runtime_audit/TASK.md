Finish the learned-solver runtime audit in study.py. Implement summarize(rows, policy) and main(). main reads timings.json and policy.json and writes report.json. Keep accuracy coverage and speed separate.

Continue from context.txt. Check the current data. Write a short HANDOFF.md with the result, tests, limits, and next action.
