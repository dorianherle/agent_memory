import unittest
from study import summarize

class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.row = dict(load_ms=2, predict_ms=1, correct_ms=8, verify_ms=4,
                        output_ms=3, training_ms=100000, baseline_ms=10, residual=1e-8)
        self.policy = {'residual_limit': 1e-6}

    def test_full_cost_and_coverage(self):
        failed = dict(self.row, residual=1e-3, baseline_ms=1000, predict_ms=2)
        report = summarize([self.row, failed], self.policy)
        self.assertEqual(report['attempted'], 2)
        self.assertEqual(report['qualified'], 1)
        self.assertEqual(report['median_attempt_ms'], 18.5)
        self.assertAlmostEqual(report['median_qualified_speedup'], 10 / 18)
        self.assertEqual(report['median_inference_speedup'], 255)
        self.assertEqual(report['baseline_contract'], 'construction_only')
        self.assertEqual(report['claim'], 'accuracy_limited')
        self.assertEqual(summarize([dict(self.row, training_ms=0)], self.policy),
                         summarize([self.row], self.policy))

    def test_claims(self):
        self.assertEqual(summarize([self.row], self.policy)['claim'], 'slower_or_equal')
        self.assertEqual(summarize([dict(self.row, baseline_ms=100)], self.policy)['claim'], 'faster')
        report = summarize([dict(self.row, residual=1)], self.policy)
        self.assertEqual(report['claim'], 'no_qualified_speedup')
        self.assertIsNone(report['median_qualified_speedup'])
        self.assertEqual(summarize([dict(self.row, residual=1e-6)], self.policy)['qualified'], 1)

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            summarize([], self.policy)
        for key in self.row:
            row = dict(self.row)
            del row[key]
            with self.subTest(missing=key), self.assertRaises(ValueError):
                summarize([row], self.policy)
            for value in (-1, float('nan'), float('inf')):
                with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                    summarize([dict(self.row, **{key: value})], self.policy)
        for key in ('predict_ms', 'baseline_ms'):
            with self.subTest(zero=key), self.assertRaises(ValueError):
                summarize([dict(self.row, **{key: 0})], self.policy)
        for limit in (0, -1, float('inf')):
            with self.subTest(limit=limit), self.assertRaises(ValueError):
                summarize([self.row], {'residual_limit': limit})

if __name__ == '__main__':
    unittest.main()
