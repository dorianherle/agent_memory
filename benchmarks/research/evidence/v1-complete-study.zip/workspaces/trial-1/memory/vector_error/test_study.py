import math
import unittest
from study import field_error


class FieldTests(unittest.TestCase):
    def test_global_scale_and_phase(self):
        reference = [1 + 2j, -3j, 0.2]
        for scale in (4j, -2, 0.001 * (1 + 2j), 1e200 * (1 + 2j)):
            self.assertLess(field_error([scale * v for v in reference], reference), 1e-14)

    def test_relative_phase_is_retained(self):
        self.assertAlmostEqual(field_error([1, -1], [1, 1]), math.sqrt(2))
        self.assertAlmostEqual(field_error([1, 1j], [1, 1]), math.sqrt(2 - math.sqrt(2)))

    def test_relative_amplitude_is_retained(self):
        self.assertGreater(field_error([1, 0], [1, 1]), 0.7)
        self.assertGreater(field_error([1, 2], [1, 1]), 0.3)

    def test_invalid_vectors(self):
        cases = [([], []), ([0, 0], [1, 1]), ([1], [1, 1]),
                 ([[1], [2]], [1, 1]), ([math.nan], [1]), ([complex(1, math.inf)], [1]),
                 (1, [1])]
        for predicted, reference in cases:
            with self.subTest(predicted=predicted), self.assertRaises(ValueError):
                field_error(predicted, reference)


if __name__ == '__main__':
    unittest.main()
