# Field assessment

Result: the supplied field fails the current error limit.

`field_error()` normalizes each complete complex vector once. It then applies one phase to the complete predicted vector. Relative component amplitudes and phases remain in the comparison.

Field error: 1.414213562373095. Current limit: 0.15. `qualified` is false. The predicted vector has the same component magnitudes as the reference. Its relative phase differs by pi. Magnitude agreement does not qualify this field.

Full memory notes used: a4b116a3, 3f4b76e9, 5cade6d8. The current fields and policy agree with these rules.

Tests: four local tests passed. They cover global scale and phase, relative phase, relative amplitude, and invalid vectors. `study.py` ran without error and wrote `report.json`.

Limits: this metric permits one global scale and phase change. It does not assess absolute field strength. No hidden tests were run. No required decision remains unknown.

Next action: correct the relative component phase in the predicted field before qualification.
