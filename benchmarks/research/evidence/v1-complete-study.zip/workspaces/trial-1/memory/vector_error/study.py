import json
import math
from pathlib import Path

def _unit_vector(values):
    if getattr(values, 'ndim', 1) != 1:
        raise ValueError('The field must be one-dimensional.')
    try:
        vector = [complex(v) for v in values]
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('The field must contain complex scalars.') from exc
    if not vector or not all(math.isfinite(v.real) and math.isfinite(v.imag) for v in vector):
        raise ValueError('The field must be nonempty and finite.')
    scale = max(max(abs(v.real), abs(v.imag)) for v in vector)
    if scale == 0:
        raise ValueError('The field norm must be nonzero.')
    scaled = [v / scale for v in vector]
    norm = math.sqrt(math.fsum(abs(v) ** 2 for v in scaled))
    return [v / norm for v in scaled]

def field_error(predicted, reference):
    predicted_unit = _unit_vector(predicted)
    reference_unit = _unit_vector(reference)
    if len(predicted_unit) != len(reference_unit):
        raise ValueError('The field lengths must be equal.')
    products = [r.conjugate() * p for p, r in zip(predicted_unit, reference_unit)]
    overlap = complex(math.fsum(v.real for v in products), math.fsum(v.imag for v in products))
    phase = overlap.conjugate() / abs(overlap) if overlap else 1 + 0j
    return math.sqrt(math.fsum(abs(phase * p - r) ** 2
                               for p, r in zip(predicted_unit, reference_unit)))

def main():
    base = Path(__file__).resolve().parent
    fields = json.loads((base / 'fields.json').read_text())
    policy = json.loads((base / 'policy.json').read_text())
    predicted = [complex(real, imag) for real, imag in fields['predicted']]
    reference = [complex(real, imag) for real, imag in fields['reference']]
    error = field_error(predicted, reference)
    limit = float(policy['field_error_limit'])
    if not math.isfinite(limit) or limit < 0:
        raise ValueError('The field error limit must be finite and nonnegative.')
    report = {'field_error': error, 'qualified': error <= limit}
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
