# Runtime audit

Result: three of four attempts meet the current residual limit. The qualified results are slower than the baseline under the full time contract.

Each full time includes loading, prediction, correction, verification, and output. Offline training is excluded. The baseline contract is `construction_only`.

Attempt count: 4. Qualified count: 3. Median time for all attempts: 21.0 ms. Median qualified full speed ratio: 0.5454545454545454. Median inference speed ratio for all attempts: 4.75. `claim` is `accuracy_limited`.

Matrix 1 has residual 0.001 and fails the current limit of 1e-06. Its time remains in the attempt median. Its result does not enter the qualified speed median. The inference speed ratio is a separate timing result. It does not establish a full construction speed gain.

Full memory notes used: 9ec668b3, 30e6f8ce, b4f0631d. A query found b4f0631d; a separate full read supplied its complete rules. The current timings and policy agree with these rules.

Tests: five local tests passed. They cover the full time contract, failed attempts, qualification claims, the median of individual ratios, and invalid input. `study.py` ran without error and wrote `report.json`.

Limits: these conclusions apply to four supplied timing rows. The data do not establish broad accuracy or a full speed gain. The baseline excludes loading and output, as stated in the saved contract. No hidden tests were run. No required decision remains unknown.

Next action: improve accuracy and reduce the full online time. Then collect more measurements under the same time contract.
