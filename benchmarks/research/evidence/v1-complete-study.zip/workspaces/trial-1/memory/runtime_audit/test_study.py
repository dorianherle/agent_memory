import math
import unittest
from study import summarize


class RuntimeTests(unittest.TestCase):
    policy = {'residual_limit': 1e-6}

    def row(self, residual=1e-8, baseline=10):
        return {'load_ms': 2, 'predict_ms': 1, 'correct_ms': 8, 'verify_ms': 4,
                'output_ms': 3, 'training_ms': 100000, 'baseline_ms': baseline,
                'residual': residual}

    def test_full_contract_and_offline_training(self):
        result = summarize([self.row()], self.policy)
        self.assertEqual(result['median_attempt_ms'], 18)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10 / 18)
        self.assertEqual(result['median_inference_speedup'], 10)
        self.assertEqual(result['baseline_contract'], 'construction_only')
        self.assertEqual(result['claim'], 'slower_or_equal')

    def test_failed_attempts_remain_in_coverage_and_time(self):
        fail = {**self.row(residual=1e-3, baseline=1000), 'correct_ms': 100}
        result = summarize([self.row(), fail], self.policy)
        self.assertEqual(result['attempted'], 2)
        self.assertEqual(result['qualified'], 1)
        self.assertEqual(result['median_attempt_ms'], 64)
        self.assertAlmostEqual(result['median_qualified_speedup'], 10 / 18)
        self.assertEqual(result['claim'], 'accuracy_limited')

    def test_claims_and_threshold(self):
        result = summarize([self.row(residual=1e-3)], self.policy)
        self.assertIsNone(result['median_qualified_speedup'])
        self.assertEqual(result['claim'], 'no_qualified_speedup')
        self.assertEqual(summarize([self.row(residual=1e-6, baseline=36)], self.policy)['claim'], 'faster')
        self.assertEqual(summarize([self.row(baseline=18)], self.policy)['claim'], 'slower_or_equal')

    def test_median_of_ratios(self):
        rows = [self.row(baseline=18), {**self.row(baseline=18), 'correct_ms': 26},
                {**self.row(baseline=144), 'correct_ms': 62}]
        self.assertEqual(summarize(rows, self.policy)['median_qualified_speedup'], 1)

    def test_invalid_data(self):
        cases = [[]]
        for key, value in [('predict_ms', 0), ('baseline_ms', 0), ('residual', math.nan),
                           ('training_ms', -1), ('correct_ms', math.inf)]:
            cases.append([{**self.row(), key: value}])
        missing = self.row()
        del missing['output_ms']
        cases.append([missing])
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                summarize(rows, self.policy)
        for limit in (0, -1, math.nan, math.inf):
            with self.subTest(limit=limit), self.assertRaises(ValueError):
                summarize([self.row()], {'residual_limit': limit})


if __name__ == '__main__':
    unittest.main()
