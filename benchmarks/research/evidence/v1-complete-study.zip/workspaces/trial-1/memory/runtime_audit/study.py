import json
import math
from statistics import median
from pathlib import Path

def summarize(rows, policy):
    online_keys = ('load_ms', 'predict_ms', 'correct_ms', 'verify_ms', 'output_ms')
    required_keys = online_keys + ('training_ms', 'baseline_ms', 'residual')
    try:
        limit = float(policy['residual_limit'])
        data = [{key: float(row[key]) for key in required_keys} for row in rows]
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Required runtime fields are missing or invalid.') from exc
    if not math.isfinite(limit) or limit <= 0:
        raise ValueError('The residual limit must be finite and positive.')
    if not data:
        raise ValueError('At least one runtime row is required.')
    attempts = []
    qualified_speedups = []
    inference_speedups = []
    for row in data:
        if not all(math.isfinite(v) and v >= 0 for v in row.values()):
            raise ValueError('Runtime values must be finite and nonnegative.')
        full_ms = sum(row[key] for key in online_keys)
        if not math.isfinite(full_ms) or min(full_ms, row['predict_ms'], row['baseline_ms']) <= 0:
            raise ValueError('Full, inference, and baseline times must be finite and positive.')
        attempts.append(full_ms)
        inference_speedups.append(row['baseline_ms'] / row['predict_ms'])
        if row['residual'] <= limit:
            qualified_speedups.append(row['baseline_ms'] / full_ms)
    qualified_median = median(qualified_speedups) if qualified_speedups else None
    if not qualified_speedups:
        claim = 'no_qualified_speedup'
    elif len(qualified_speedups) < len(data):
        claim = 'accuracy_limited'
    else:
        claim = 'faster' if qualified_median > 1 else 'slower_or_equal'
    return {'attempted': len(data), 'qualified': len(qualified_speedups),
            'median_attempt_ms': median(attempts),
            'median_qualified_speedup': qualified_median,
            'median_inference_speedup': median(inference_speedups),
            'baseline_contract': 'construction_only', 'claim': claim}

def main():
    base = Path(__file__).resolve().parent
    rows = json.loads((base / 'timings.json').read_text())
    policy = json.loads((base / 'policy.json').read_text())
    report = summarize(rows, policy)
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
