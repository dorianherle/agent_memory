import math
import unittest
from study import assess


class ConvergenceTests(unittest.TestCase):
    config = {'length': 1.2, 'tolerance': 1e-6, 'order_min': 1.8, 'order_max': 2.2}

    def records(self, order=2):
        reference = (math.pi / self.config['length']) ** 2
        return [{'intervals': n, 'length': 1.2, 'eigenvalue': reference + n ** (-order)}
                for n in (16, 32, 64, 128)]

    def test_observed_order_and_extrapolation(self):
        result = assess(list(reversed(self.records())), self.config)
        self.assertAlmostEqual(result['observed_order'], 2, places=8)
        self.assertAlmostEqual(result['extrapolated'], (math.pi / 1.2) ** 2, places=10)
        self.assertTrue(result['qualified'])

    def test_first_order_is_rejected(self):
        result = assess(self.records(order=1), self.config)
        self.assertAlmostEqual(result['observed_order'], 1, places=8)
        self.assertFalse(result['qualified'])

    def test_current_tolerance_is_used(self):
        records = self.records()
        for row in records:
            row['eigenvalue'] += 1e-4
        self.assertFalse(assess(records, self.config)['qualified'])
        self.assertTrue(assess(records, {**self.config, 'tolerance': 1e-3})['qualified'])

    def test_invalid_records(self):
        cases = [self.records()[:2]]
        for key, value in [('length', 1), ('intervals', 100), ('eigenvalue', math.nan),
                           ('eigenvalue', 0), ('intervals', -1)]:
            records = self.records()
            records[-1][key] = value
            cases.append(records)
        records = self.records()
        records[-1]['eigenvalue'] = records[-2]['eigenvalue']
        cases.append(records)
        records = self.records()
        records[-1]['eigenvalue'] = records[-2]['eigenvalue'] + 1
        cases.append(records)
        for records in cases:
            with self.subTest(records=records), self.assertRaises(ValueError):
                assess(records, self.config)


if __name__ == '__main__':
    unittest.main()
