import json
import math
import subprocess
import sys
from pathlib import Path

def assess(records, config):
    try:
        length = float(config['length'])
        tolerance = float(config['tolerance'])
        order_min = float(config['order_min'])
        order_max = float(config['order_max'])
        data = [(float(r['intervals']), float(r['length']), float(r['eigenvalue']))
                for r in records]
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        raise ValueError('Invalid records or configuration.') from exc
    if not all(math.isfinite(x) and x > 0 for x in
               (length, tolerance, order_min, order_max)) or order_min > order_max:
        raise ValueError('Configuration values must be finite and positive.')
    if len(data) < 3:
        raise ValueError('At least three records are required.')
    for n, sample_length, value in data:
        if not all(math.isfinite(x) and x > 0 for x in (n, sample_length, value)):
            raise ValueError('Measurements must be finite and positive.')
        if not n.is_integer() or sample_length != length:
            raise ValueError('Use integer intervals and the current geometry length.')
    finest = sorted(data)[-3:]
    if finest[1][0] != 2 * finest[0][0] or finest[2][0] != 2 * finest[1][0]:
        raise ValueError('The three finest grids must double their intervals.')
    coarse, middle, fine = (r[2] for r in finest)
    difference_1 = abs(coarse - middle)
    difference_2 = abs(middle - fine)
    if difference_1 == 0 or difference_2 == 0:
        raise ValueError('Grid differences must be nonzero.')
    observed_order = math.log2(difference_1) - math.log2(difference_2)
    if not math.isfinite(observed_order) or observed_order <= 0:
        raise ValueError('Observed order must be finite and positive.')
    try:
        extrapolated = fine + (fine - middle) / math.expm1(observed_order * math.log(2))
        analytical_reference = (math.pi / length) ** 2
        relative_error = abs(extrapolated - analytical_reference) / analytical_reference
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError('Extrapolation is not finite.') from exc
    if not all(math.isfinite(x) for x in (extrapolated, analytical_reference, relative_error)):
        raise ValueError('Extrapolation is not finite.')
    return {'observed_order': observed_order, 'extrapolated': extrapolated,
            'relative_error': relative_error,
            'qualified': order_min <= observed_order <= order_max and relative_error <= tolerance}

def main():
    base = Path(__file__).resolve().parent
    config = json.loads((base / 'config.json').read_text())
    records = json.loads((base / 'samples.json').read_text())
    if any(r['length'] != config['length'] for r in records):
        subprocess.run([sys.executable, str(base / 'measure.py')], cwd=base, check=True)
        records = json.loads((base / 'samples.json').read_text())
    report = assess(records, config)
    (base / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

if __name__ == '__main__':
    main()
