# Cavity study

Result: the cavity meets the current qualification limits.

The stored samples had length 1.0. `main()` ran the supplied `measure.py` and regenerated them at the current length, 1.2. It then used the three finest grids, with 32, 64, and 128 intervals.

Observed order: 1.9995654545089394. Extrapolated eigenvalue: 6.853892055765409. Relative error: 1.6131632366384717e-08. Current tolerance: 1e-06. `qualified` is true. The analytical value is used only to calculate relative error. It does not replace the samples.

Full memory notes used: 5ada0165, b508bc0e, cef11a20. The current config and regenerated samples agree with these rules.

Tests: four local tests passed. They cover second-order extrapolation, first-order rejection, the current tolerance, and invalid measurements. `study.py` ran without error and wrote `report.json`. The regenerated samples all have length 1.2.

Limits: this result applies to the supplied cavity model and grids. It does not validate a physical device. No hidden tests were run. No required decision remains unknown.

Next action: use more grids or another cavity model if a wider validation is required.
